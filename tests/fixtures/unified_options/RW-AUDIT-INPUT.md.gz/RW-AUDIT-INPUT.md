# Owner-designated frozen RW plateau audit

Selected 2026-10-08T11:13:59.487670+00:00. READ ONLY audit input; no source ownership transfer, live-tree edits, required upgrade, or credit. RW100 source lane will use independent checkout. Apply unified tooling only after its accepted push/install and measured bytes/hour benefit.

Target **func_8027DD48_de**, canonical identity, **US-rev1 only**, target VMA0x8027DD1C, ROM[0x7E91C,0x7F358),2620B. OtherROMs are NOTqualified bythisreceipt.
Frozen best source: /mnt/devstorage/AbuCode/.buildtmp/tmp/claude-1000/-mnt-devstorage-Workspaces/16a2299c-8f51-4270-9c1f-009829f453ab/scratchpad/cycles/rw-compiler-7dd48/sources/continuation-late-store-baseline-entry.c
SHA256:9af0bacdd653fd6eb95d03b16422b989b3380cac35faa77275e9caceeb365621.
Best99.541985, actualELF.text2620B,6positionalentrywords; suffix0x74..end exactlyROM. LinkedSHAce7517c70f1320bc360afd7cf504eb0784dadf96ba7ff4808099d2c89063de20, targetSHA dd6a034fd172d69fb5c435d22da4c116a9a4548447921468d25842267eb79627. No exactwinner/sourcecredit.

Baseline recipe SN64 GCC2.8.1 binarySHA d1ddfe21dfa61840a83f833c8bd45ed7e2f606c3d9c351d2ec732fb6e4f97c89: -G0 -mips3 -O2 -mgas -meb -mcpu=VR4300 -mhard-float -mgp32 -mfp64 -mno-fix4300; no unitflags. Actual compiler/assembler/link argv and sourceCPP/object/placed/ROM assets: /mnt/devstorage/AbuCode/.buildtmp/tmp/claude-1000/-mnt-devstorage-Workspaces/16a2299c-8f51-4270-9c1f-009829f453ab/scratchpad/cycles/rw-compiler-7dd48/probes/continuation-late-store-baseline-entry/ (result.json and retainedfiles). Use receiptactualargv rather than presumeddefaults. ELF emittedlength, not padded comparator slice, is authoritative.

Readonly native project/closure: /mnt/devstorage/AbuCode/.buildtmp/tmp/claude-1000/-mnt-devstorage-Workspaces/16a2299c-8f51-4270-9c1f-009829f453ab/scratchpad/cycles/rw-compiler-7dd48/RageWars; host.toml inlane; separatepublication/RageWars. Copy intoNEWisolatedaudit tree; never mutateoriginal. Exact provider/neighbor/layout/symbol/input closure: INPUT-CLOSURE.json (ifpresent), ARTIFACT-MANIFEST.json, EVERGREENS.json, DRAIN.json and capturedcompiled.i/nativecommands atbaselineprobe. All285 originalintake hashes checked unchanged bysourceowner; preserveversionYAML/ld/symbols/providerfiles/CPP snapshot when copying. Any neighbor claimedexact must come fromitsretainedartifact/remoteproof, never assumealladjacentcode isexact.

Alternate diagnosticparent sources/entry-threshold-zero-scratch.c SHA93a2799022daebcb95cd742f7aa9e6fca77a468627b663cc32778525c07a1c2a:99.389313,4register-onlywords,targetentryorder,suffix0x74exact. ENTRY-WAR-PROOF.json and ENTRY-ALLOCATION-AUDIT.json explainf0/f5 andthresholdf3/f0.

Freshnegativeoptionsearch alreadyran bothparents with-fno-thread-jumps and-fno-rerun-cse-after-loop (3afa/4b normaladmission): unchangednativebytes. PASS-ORDER-CROSS-RESULT.json, ANGLES.jsonl, HANDOFF.md retaincausalpassproof. Do notrepeattheseasnewgains. Targetodd-f21/f23 wide sdc1/ldc1 preservation rules outmfp32; FP-WIDTH-ABI-AUDIT.json includes7actualcallers. No inventeduses/padding/fixedregs/volatilewaiver.

Separate EXACToptionregression: rw-compiler-98368/PUBLICATION-RECEIPT.json +evidence/indexed-search-loop/result.json,2916B SN64 with-fno-thread-jumps/-fno-rerun-cse-after-loop; remoteefc5b507f6e779867631258217766b4cc3b28c13. Readonlyregression,notnewbytecredit.
