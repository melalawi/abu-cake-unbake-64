#include "common/types_1dc8418c21db.h"
#include "span_C76B0/data.h"
#include "span_1000/code_8027A0F4.h"

void func_8026F620_de(f32 *, f32 *, f32 *);
void func_8027027C_de(f32 *, void *);
void func_80271F34_de(Vec3 *, Vec3 *, Vec3 *);
void func_80271F9C_de(Vec3 *, Vec3 *, f32);
void func_80272018_de(Vec3 *, Vec3 *, Vec3 *);
void func_8027207C_de(Vec3 *);
s32 func_8027254C_de(Vec3 *, f32);
void func_802727D8_de(void *);
void func_80272828_de(f32 *);
void func_80272C60_de(void *, f32, f32, f32);
void func_80272E3C_de(f32 *, f32, f32, f32);
void func_80272FBC_de(float *, float *);
void func_802733B4_de(void *, f32, f32, f32);
void func_80273448_de(char *, float, float, float);
void func_8027347C_de(void *, f32, f32, f32);
void func_80273760_de(void *, f32);
void func_802738C0_de(void *, f32);
void func_80273A98_de(void *, f32);
void func_80273D6C_de(void *);
f32 func_8027525C_de(void *, f32, f32);
f32 func_80275DD4_de(void *, f32, f32);
void * func_8027D97C_de(void *, void *);
void func_8027DAD0_de(void *, void *, void *);
void func_8028C6D4_de(void *, s32, void *);
float func_802B7130_de(float);
extern s32 D_8011BDC8;
extern s32 D_800CD72C;














extern f32 D_800C9D74;


extern f32 D_800C9D7C;


extern f32 D_800C9D84;
extern f32 D_800C9D88;
extern f32 D_800C9D8C;




extern f32 D_800C4CD4_de;
extern f32 D_800C9DC8;
extern f32 D_800C4CDC_de;
extern f32 D_800C4CE0_de;
extern f32 D_800C4CE4_de;


extern f32 D_800C9DDC;










extern f32 D_800C9DF4;


extern f32 D_800C9DFC;

static inline void clamp_upper_height_at(Vec3 *position, f32 step) {
    f32 selected;
    if (func_80275DD4_de(0, position->x, position->z) + step < position->y) {
        selected = position->y;
    } else {
        selected = func_80275DD4_de(0, position->x, position->z) + step;
    }
    position->y = selected;
}

/* Shared particle/player records and complete vectors preserve the transform inputs. */
void func_8027DD48_de(Shared_Particle *arg0, void *arg1, SharedPlayer_func_8022A398_de *arg2, f32 arg3) {
    Matrix m10, m50, m90, mD0, m110;
    Vec3 v150;
    Vec3 v160;
    Vec3 v170;
    Vec3 v180;
    Vec3 v190;
    Vec3 v1A0;
    Vec3 v1B0;
    Vec3 v1C0;
    Vec3 v1D0;
    Vec3 v1E0;
    f32 *temp_v0_3;
    f32 *var_a0;
    f32 temp_f0;
    f32 elapsed;
    f32 blend_start; 
    f32 case3_step; 
    f32 case6_step; 
    f32 temp_f0_2;
    f32 temp_f1; 
    f32 temp_f20;
    f32 temp_f20_3;
    f32 temp_f20_4;
    f32 temp_f21;
    f32 temp_f2;
    f32 temp_f2_2;
    f32 var_f0;
    f32 var_f1;
    f32 var_f0_2;
    f32 var_f0_3;
    f32 var_f21;
    f32 var_f22;
    f32 var_f23;
    f32 var_f4;
    s32 temp_v0_2;
    s8 temp_a0;
    s8 temp_v0;
    s32 temp_v1;
    u16 temp_v1_2;
    struct Shared_ParticleDesc *temp_s5;
    struct Shared_ParticleDesc *interpolation;

    
    temp_s5 = arg0->desc;
    
    if (arg2 != 0) {
        interpolation = temp_s5;
        if (temp_s5->flags & 4) {
            var_f4 = arg3; 
            temp_f1 = var_f4 - D_800C4C68_de;
            blend_start = 0.0f;
            var_f0 = 0.0f;
            if (!(temp_f1 < var_f0)) {
                var_f0 = temp_f1 * D_800C4C6C_de;
                temp_f2_2 = D_800C4C70_de; 
                if (var_f0 > temp_f2_2) {
                    var_f0 = temp_f2_2;
                } else {
                    if (temp_f1 < blend_start) {
                        var_f0 = 0.0f;
                    } else {
                        var_f0 = temp_f1 * D_800C4C74_de;
                    }
                }
            }
            temp_f2_2 = interpolation->scaleRange->end; 
            blend_start = interpolation->scaleRange->start;
            temp_f2_2 -= blend_start;
            temp_f2_2 *= var_f0;
            blend_start += temp_f2_2;
            var_f4 *= blend_start;
            var_f4 *= D_800C4C78_de;
        } else {
            var_f4 = D_800C4C7C_de;
        }
        temp_f2 = arg2->views1C.view6C_9.yaw;
        var_f23 = var_f4 * D_800C4C88_de * (temp_f2 + ((D_800C4C80_de - temp_f2) * D_800C9D74));
    } else {
        var_f23 = D_800C9D7C;
    }
    if (temp_s5->flags & 8) {
        var_f22 = arg0->size.y * arg0->size.z * var_f23;
    } else {
        var_f22 = 0.0f;
    }
    func_8027DAD0_de(arg0, &v150, &v170);
    if (!(arg0->flags & 0x30000)) {
        elapsed = arg0->time;
        if (elapsed > 0.0f) {
            temp_v0 = temp_s5->attachment->duration;
            var_f21 = D_800C4C90_de;
            if (temp_v0 != 0) {
                temp_f0 = (f32) temp_v0;
                if (elapsed < temp_f0) {
                    var_f21 = elapsed / temp_f0;
                }
            }
            v1D0 = arg0->unk174;
            if (arg0->unk1AC < 0.0f) {
                v160.x = 0;
                v160.z = 0;
                v160.y = D_800C9D84;
                func_80272018_de(&v1C0, &v160, &v1D0);
                func_80271F9C_de(&v1E0, &v1C0, func_802B7130_de(arg0->unk19C) * -arg0->unk1AC * var_f21);
                func_80271F34_de(&v150, &v150, &v1E0);
            }
            if (arg0->unk1B0 < 0.0f) {
                v160.x = 0;
                v160.z = 0;
                v160.y = D_800C9D88;
                func_80272018_de(&v1B0, &v160, &v1D0);
                func_80272018_de(&v1C0, &v1B0, &v1D0);
                func_80271F9C_de(&v1E0, &v1C0, func_802B7130_de(arg0->unk1A0) * -arg0->unk1B0 * var_f21);
                func_80271F34_de(&v150, &v150, &v1E0);
            }
        }
    }
    if (arg0->desc->renderKind != 0) {
        if (arg0->unk1D0 == -7) {
            func_80272E3C_de(m10.m, arg0->rot.x + D_800C9D8C, arg0->rot.y, arg0->rot.z);
            if ((v170.x == 0.0f) && (v170.y == 0.0f) && (v170.z == 0.0f)) {
                v1A0 = arg0->unk174;
            } else {
                v1A0 = v170;
            }
            func_8027207C_de(&v1A0);
            v160.x = 0;
            v160.z = 0;
            v160.y = D_800C4CA0_de;
            func_80272018_de(&v180, &v160, &v1A0);
            func_80272018_de(&v190, &v180, &v1A0);
            func_802727D8_de(m50.m);
            func_8027207C_de(&v180);
            func_8027207C_de(&v190);
            func_8027207C_de(&v1A0);
            m50.m[0] = v180.x;
            m50.m[1] = v180.y;
            m50.m[2] = v180.z;
            m50.m[4] = v190.x;
            m50.m[5] = v190.y;
            m50.m[6] = v190.z;
            m50.m[8] = v1A0.x;
            m50.m[9] = v1A0.y;
            m50.m[10] = v1A0.z;
            func_8026F620_de(m90.m, m10.m, m50.m);
        } else {
            func_80272E3C_de(m90.m, arg0->rot.x, arg0->rot.y + D_800C4CA4_de, arg0->rot.z);
        }
        func_8028C6D4_de(&D_8011BDC8, (s32) &arg0->inst.pos, &arg0->drawState[D_800CD72C]);
    } else if ((arg0->rot.x == 0.0f) && (arg0->rot.y == 0.0f)) {
        func_80273760_de(m90.m, arg0->rot.z);
    } else {
        func_80273760_de(m90.m, arg0->rot.z);
        temp_v0_2 = arg0->desc->renderKind;
        var_f0_2 = 0.0f;
        if (temp_v0_2 == 0) {
            var_f0_2 = arg0->rot.x;
        }
        var_f0_2 = -var_f0_2;
        var_f1 = 0.0f;
        if (temp_v0_2 == 0) {
            var_f1 = arg0->rot.y;
        }
        func_802733B4_de(m90.m, var_f0_2, -var_f1, 0.0f);
    }
    if (var_f22 != 0.0f) {
        func_802733B4_de(m90.m, 0.0f, var_f22, 0.0f);
        func_80273448_de((char *)m90.m, 0.0f, -var_f22, 0.0f);
    }
    temp_v1 = (s8) ((u8) arg0->unk1D0 + 8);
    arg0->flags = (s32) (arg0->flags & 0xFF7FFFFF);
    switch (temp_v1) {
        case 0: goto sw_0;
        case 2: case 4: case 7: goto sw_2;
        case 3: goto sw_3;
        case 5: goto sw_5;
        case 6: goto sw_6;
        case 8: case 9: case 10: goto sw_done;
        default: goto sw_done;
    }
    do {
    sw_0:
        v150.x += arg0->unk174.x * D_800C4CD4_de;
        v150.y += arg0->unk174.y * D_800C4CD4_de;
        v150.z += arg0->unk174.z * D_800C4CD4_de;
        goto sw_done;
    sw_3:
        if (temp_s5->heightMode != 0) {
            case3_step = D_800C9DC8;
            clamp_upper_height_at(&v150, case3_step);
        }
        goto sw_done;
    sw_5:
        temp_f2_2 = func_80275DD4_de(0, v150.x, v150.z);
        if (temp_s5->flags & 0x400) {
            if (v150.y < (temp_f2_2 + D_800C4CDC_de)) {
                v150.y = temp_f2_2;
                arg0->flags = (s32) (arg0->flags | 0x800000);
            }
        } else {
            temp_f0_2 = temp_f2_2 + D_800C4CE0_de;
            temp_f1 = v150.y; 
            if (!(temp_f1 <= temp_f0_2)) {
                temp_f0_2 = temp_f1;
            }
            v150.y = temp_f0_2;
        }
        goto sw_done;
    sw_6:
        if (temp_s5->heightMode != 0) {
            case6_step = D_800C4CE4_de;
            v150.y = ({
                f32 selected_height;
                if (v150.y < (func_8027525C_de(0, v150.x, v150.z) - case6_step)) {
                    selected_height = v150.y;
                } else {
                    selected_height = func_8027525C_de(0, v150.x, v150.z) - case6_step;
                }
                selected_height;
            });
        }
        goto sw_done;
    sw_2:
    sw_4:
    sw_7:
        v150.y = v150.y + var_f22;
        goto sw_done;
    } while (0);
    goto sw_done;
sw_done:
    func_8027254C_de(&v150, 20000.0f);
    if ((temp_s5->flags & 0x80000) && (temp_s5->animMode == 1)) {
        var_f23 = var_f23 * D_800C4CE8_de * (f32) arg0->opacity;
    }
    if (arg0->desc->renderKind != 0) {
        temp_v1_2 = arg0->inst.type;
        temp_f20 = var_f23 * arg0->size.z * D_800C9DDC;
        if ((temp_v1_2 == 0x40B) || (temp_v1_2 == 0x40F) || (temp_v1_2 == 0x41E) || (temp_v1_2 == 0x40B) || (temp_v1_2 == 0x436)) {
            func_8027347C_de(m90.m, D_800C4CF0_de, D_800C4CF0_de, D_800C4CF0_de);
        }
        func_8027347C_de(m90.m, arg0->size.x * temp_f20, arg0->size.y * temp_f20, temp_f20 * D_800C4CF4_de);
        func_80273D6C_de(m90.m);
    } else {
        temp_f20 = var_f23 * arg0->size.z;
        func_8027347C_de(m90.m, arg0->size.x * temp_f20, arg0->size.y * temp_f20, temp_f20 * D_800C4CF8_de);
    }
    temp_v0_3 = func_8027D97C_de(arg0, arg2);
    if (temp_v0_3 != 0) {
        func_8026F620_de(mD0.m, m90.m, temp_v0_3);
    } else {
        func_80272FBC_de(mD0.m, m90.m);
    }
    func_80273448_de((char *)mD0.m, v150.x, v150.y, v150.z);
    if (arg0->flags & 0x20000) {
        temp_a0 = arg0->unk1D1;
        if (temp_a0 != 0) {
            temp_f20_3 = (f32) temp_a0 * D_800C4CFC_de;
            temp_f20_4 = temp_f20_3 * temp_f20_3;
            temp_f21 = temp_f20_4 * D_800C4D00_de;
            func_80272C60_de(m110.m, 0.0f, 0.0f, -66.56f);
            func_80273A98_de(m110.m, temp_f21 * (func_802B7130_de(temp_f20_4 * D_800C9DF4) * D_800C4D08_de));
            func_802738C0_de(m110.m, temp_f21 * func_802B7130_de(temp_f20_4 * D_800C9DFC));
            func_80273448_de((char *)m110.m, 0.0f, 0.0f, 66.56f);
            func_8026F620_de(m10.m, m110.m, mD0.m);
            func_80272828_de(m10.m);
            var_a0 = m10.m;
        } else {
            goto block_81;
        }
    } else {
block_81:
        func_80272828_de(mD0.m);
        var_a0 = mD0.m;
    }
    func_8027027C_de(var_a0, arg1);
}

