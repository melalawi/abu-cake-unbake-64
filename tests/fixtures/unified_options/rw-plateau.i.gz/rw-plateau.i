typedef struct {
    unsigned int w0;
    unsigned int w1;
} Awords;
typedef union {
    Awords words;
    long long int force_union_align;
} Acmd;
typedef Acmd *(*ALCmdHandler)(void *, short *, int, int, Acmd *);
typedef int (*ALDMAproc)(int addr, int len, void *state);
typedef int (*ALVoiceHandler)(void *);
typedef int (*ALSetParam)(void *, int, void *);
typedef signed char s8;
typedef unsigned char u8;
typedef signed short s16;
typedef unsigned short u16;
typedef signed int s32;
typedef unsigned int u32;
typedef signed long long s64;
typedef unsigned long long u64;
typedef float f32;
typedef double f64;
struct Box;
typedef struct Box Box;
struct Vec3;
typedef struct Vec3 Vec3;
struct Vec3;
struct Vec3 {
    f32 x;
    f32 y;
    f32 z;
};
struct Box;
struct Box {
    Vec3 min;
    Vec3 max;
};
struct Owner8020F150;
typedef struct Owner8020F150 Owner8020F150;
struct Shared_Input;
typedef struct Shared_Input Shared_Input;
struct Shape_func_8021A2D4_de_2;
struct Shape_func_8021A2D4_de_2 {
    int field_0;
};
struct Triple;
struct Triple {
    s32 x;
    s32 y;
    s32 z;
};
struct Triple;
typedef struct Triple Triple;
struct Settings;
struct Settings {
    char pad0[0x78];
    s32 flag78;
    s32 pad7C;
    s32 flag80;
};
struct Held;
struct Held {
    u8 type;
    char pad1[0x100 - 0x1];
    s32 flags;
    char pad104[0x122C - 0x104];
    s32 options;
};
struct Model;
struct Model {
    char pad0[0x4C];
    s32 slots[8];
};
struct Shared_Quad;
struct Shared_Quad {
    s32 w[4];
};
struct Rider;
struct Rider {
    char pad0[0x37];
    s8 direction;
    char pad38[0x1C];
    char frame[0x10];
    f32 throttle;
    char pad68[0x38];
    Vec3 base;
    char padAC[0x7C];
    f32 change;
};
struct Shared_Effect;
typedef struct Shared_Effect Shared_Effect;
struct Shared_Slot;
typedef struct Shared_Slot Shared_Slot;
struct Matrix;
typedef struct Matrix Matrix;
struct Profile;
struct Profile {
    u8 bonus2;
    u8 bonus0;
    u8 bonus1;
    char pad[0x18D];
};
struct Shared_Emitter;
typedef struct Shared_Emitter Shared_Emitter;
struct Matrix;
struct Matrix {
    f32 m[16];
};
struct Controls;
struct Controls {
    char pad0[0x80];
    s8 mode;
    char pad81[0x94 - 0x81];
    u8 team;
    u8 active;
};
struct Shared_Quad;
typedef struct Shared_Quad Shared_Quad;
struct Shared_Emitter;
struct Shared_Model;
struct Shared_Emitter {
    char pad0[0x8];
    Vec3 pos;
    struct Shared_Model * model;
    char pad18[0x28];
    f32 unk40;
    char pad44[0x18];
    Shared_Quad unk5C;
    f32 unk6C;
};
struct Shared_Effect;
struct Shared_Effect {
    char pad0[0xB4];
    s32 state;
};
struct Record;
struct Record {
    char pad0[0x92];
    u8 team;
};
struct View;
struct View {
    char pad0[0x29C];
    f32 viewport[4];
    char pad2AC[0x340 - 0x2AC];
    Vec3 normal;
    f32 distance;
};
struct Shared_Body;
struct Shared_Body {
    char pad0[0xC];
    s16 kind;
    char padE[0xE6];
    f32 ceiling;
};
struct Shared_Input;
struct Shared_Shadow;
struct Shared_Input {
    char pad0[0x10];
    struct Shared_Shadow * shadow;
    char pad14[0x10];
    s32 held;
    s32 pressed;
    s32 unk2C;
    s32 unk30;
    s32 unk34;
};
struct Shared_Slot;
struct Shared_Slot {
    s8 owned;
    s8 pad1;
};
struct Body;
struct Body {
    u8 pad[0x24];
    f32 speed;
};
struct Actor_func_80214DD4_de;
struct Controller;
struct Actor_func_80214DD4_de {
    u8 type;
    u8 pad1[7];
    Vec3 pos;
    s32 room;
    s32 *kind;
    u8 pad1C[0x54];
    f32 height;
    u8 pad74[0x70];
    u16 id;
    u8 padE6[0x1A];
    s32 flags100;
    u8 pad104[0xD4];
    struct Controller *controller;
    u8 pad1DC[0x104];
    s32 flags2E0;
};
struct Controller {
    u8 pad0[0x788];
    s32 state;
    u8 pad78C[8];
    struct Actor_func_80214DD4_de *owner;
};
struct Ctrl;
struct Ctrl {
    u8 pad[0x8F];
    u8 flag;
};
struct func_80212828_S7;
typedef struct func_80212828_S7 func_80212828_S7;
struct func_80212828_S7;
struct func_80212828_S7 {
    char pad0[0x8];
    f32 unk8;
};
struct Mode;
struct Mode {
    char pad0[8];
    func_80212828_S7 *physics;
    char padC[12];
};
struct StateInfo;
struct StateInfo {
    void (*enter)(void *, void *);
    s32 pad4;
    s32 pad8;
    s32 timer;
    s32 parameter;
    s32 pad14;
};
struct Body;
struct Character;
struct Controller;
struct Controls;
struct Ctrl;
struct Held;
struct Mode;
struct Model;
struct Mount;
struct Profile;
struct Record;
struct Rider;
struct Settings;
struct SharedPlayer_func_8022A398_de;
struct Shared_Body;
struct Shared_Hud;
struct Shared_Model;
struct Shared_Profile;
struct Shared_StateInfo;
struct Shared_Voice;
struct StateInfo;
struct TeamInfo;
struct View;
struct SharedPlayer_func_8022A398_de {
    union {
        struct {
            u8 unk0[24];
        } view0_0;
        struct {
            u8 pad0[24];
        } view0_1;
        struct {
            char pad[0x3];
            u8 team;
        } view3_2;
        struct {
            char pad[0x8];
            Vec3 unk8;
        } view8_2;
        struct {
            char pad[0x8];
            Vec3 pos;
        } view8_3;
        struct {
            char pad[0x8];
            Vec3 position;
        } view8_4;
        struct {
            char pad[0x14];
            struct Shared_Model * model;
        } view14_6;
        struct { char pad[8]; s32 positionWords[3]; } positionBits;
    } views0;
    union {
        struct {
            char * unk18;
        } view18_0;
        struct {
            char * track;
        } view18_1;
        struct {
            struct Model * model;
        } view18_2;
        struct {
            struct Body * body;
        } view18_3;
        struct {
            struct Character * character;
        } view18_4;
        struct {
            struct Shared_Body * body;
        } view18_5;
    } views18;
    union {
        struct {
            u8 unk1C[344];
        } view1C_0;
        struct {
            u8 pad1[344];
        } view1C_1;
        struct {
            char pad[0x4];
            f32 velY;
        } view20_2;
        struct {
            char pad[0x1C];
            s32 unk38;
        } view38_2;
        struct {
            char pad[0x1C];
            s32 flags;
        } view38_3;
        struct {
            char pad[0x24];
            f32 unk40;
        } view40_5;
        struct {
            char pad[0x40];
            Shared_Quad unk5C;
        } view5C_6;
        struct {
            char pad[0x50];
            f32 unk6C;
        } view6C_4;
        struct {
            char pad[0x50];
            f32 heading;
        } view6C_5;
        struct {
            char pad[0x50];
            f32 yaw;
        } view6C_9;
        struct {
            char pad[0xC8];
            u16 unkE4;
        } viewE4_6;
        struct {
            char pad[0xC8];
            u16 kind;
        } viewE4_7;
        struct {
            char pad[0xE4];
            s32 unk100;
        } view100_8;
        struct {
            char pad[0xE4];
            s32 flags;
        } view100_9;
        struct {
            char pad[0xE8];
            f32 unk104;
        } view104_10;
        struct {
            char pad[0xE8];
            f32 idleTime;
        } view104_11;
        struct {
            char pad[0xEC];
            s16 anim;
        } view108_16;
        struct {
            char pad[0xF2];
            s8 unk10E;
        } view10E_12;
        struct {
            char pad[0xF2];
            s8 idle;
        } view10E_13;
        struct {
            char pad[0xF2];
            s8 replaying;
        } view10E_14;
        struct {
            char pad[0xF2];
            s8 animPending;
        } view10E_20;
        struct {
            char pad[0x154];
            char unk170[100];
        } view170_15;
        struct {
            char pad[0x154];
            char body[100];
        } view170_16;
        struct {
            char pad[0x154];
            s32 unk170;
        } view170_23;
        struct {
            char pad[0x158];
            s32 unk174;
        } view174_17;
        struct {
            char pad[0x15C];
            u8 unk178[740];
        } view178_18;
        struct {
            char pad[0x15C];
            u8 pad2[740];
        } view178_19;
        struct {
            char pad[0x1B8];
            f32 unk1D4;
        } view1D4_20;
        struct {
            char pad[0x1B8];
            f32 holdTime;
        } view1D4_21;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_8022A398_de * unk1D8;
        } view1D8_22;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_8022A398_de * self;
        } view1D8_23;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_8022A398_de * f1D8;
        } view1D8_24;
        struct {
            char pad[0x1BC];
            void * unk1D8;
        } view1D8_32;
        struct {
            char pad[0x244];
            Vec3 unk260;
        } view260_25;
        struct {
            char pad[0x244];
            Vec3 muzzle;
        } view260_26;
        struct {
            char pad[0x2CC];
            char unk2E8[368];
        } view2E8_27;
        struct {
            char pad[0x2CC];
            char weapon[368];
        } view2E8_28;
        struct {
            char pad[0x2CC];
            Shared_Emitter emitter;
        } view2E8_37;
        struct {
            char pad[0x43C];
            char unk458[384];
        } view458_29;
        struct {
            char pad[0x43C];
            char ammo[384];
        } view458_30;
        struct {
            char pad[0x43C];
            s32 unk458;
        } view458_40;
        struct {
            char pad[0x440];
            s32 unk45C;
        } view45C_31;
        struct {
            char pad[0x444];
            u8 unk460[376];
        } view460_32;
        struct {
            char pad[0x444];
            u8 pad3[376];
        } view460_33;
        struct {
            char pad[0x468];
            struct Shared_Voice * voice;
        } view484_44;
        struct {
            char pad[0x470];
            s8 unk48C;
        } view48C_34;
        struct {
            char pad[0x470];
            s8 state;
        } view48C_35;
        struct {
            char pad[0x4A4];
            void * unk4C0;
        } view4C0_47;
        struct {
            char pad[0x507];
            s8 unk523;
        } view523_36;
        struct {
            char pad[0x507];
            s8 busy;
        } view523_37;
        struct {
            char pad[0x578];
            s32 unk594;
        } view594_38;
        struct {
            char pad[0x578];
            s32 gear;
        } view594_39;
        struct {
            char pad[0x578];
            s32 mode;
        } view594_40;
        struct {
            char pad[0x584];
            f32 unk5A0;
        } view5A0_41;
        struct {
            char pad[0x584];
            f32 charge;
        } view5A0_42;
        struct {
            char pad[0x5B4];
            s32 unk5D0;
        } view5D0_43;
        struct {
            char pad[0x5B4];
            s32 f5D0;
        } view5D0_44;
        struct {
            char pad[0x5B8];
            s32 unk5D4;
        } view5D4_45;
        struct {
            char pad[0x5B8];
            s32 slot;
        } view5D4_46;
        struct {
            char pad[0x5B8];
            s32 profile;
        } view5D4_47;
        struct {
            char pad[0x5B8];
            s32 f5D4;
        } view5D4_48;
    } views1C;
    union {
        struct {
            struct Record * unk5D8;
        } view5D8_0;
        struct {
            struct Record * record;
        } view5D8_1;
        struct {
            struct Controls * controls;
        } view5D8_2;
        struct {
            struct TeamInfo * teamInfo;
        } view5D8_3;
        struct {
            struct Ctrl * ctrl;
        } view5D8_4;
        struct {
            unsigned char * info;
        } view5D8_5;
        struct {
            struct Profile * profile;
        } view5D8_6;
        struct {
            struct Settings * settings;
        } view5D8_7;
        struct {
            s32 f5D8;
        } view5D8_8;
        struct {
            struct Shared_Profile * profile;
        } view5D8_9;
    } views5D8;
    union {
        struct {
            void * unk5DC;
        } view5DC_0;
        struct {
            void * view;
        } view5DC_1;
        struct {
            struct View * view;
        } view5DC_2;
        struct {
            u8 pad4[8];
        } view5DC_3;
        struct {
            void * entity;
        } view5DC_4;
        struct {
            struct Rider * rider;
        } view5DC_5;
        struct {
            char * storage;
        } view5DC_6;
        struct {
            char * messages;
        } view5DC_7;
        struct {
            struct Shared_Hud * hud;
        } view5DC_8;
        struct {
            char pad[0x4];
            s32 unk5E0;
        } view5E0_8;
        struct {
            char pad[0x4];
            s32 state;
        } view5E0_9;
        struct {
            char pad[0x4];
            s32 slot;
        } view5E0_10;
    } views5DC;
    union {
        struct {
            s32 unk5E4;
        } view5E4_0;
        struct {
            s32 active;
        } view5E4_1;
        struct {
            s32 health;
        } view5E4_2;
        struct {
            s32 alive;
        } view5E4_3;
        struct {
            s32 holding;
        } view5E4_4;
    } views5E4;
    union {
        struct {
            u8 unk5E8[3140];
        } view5E8_0;
        struct {
            u8 pad5[3140];
        } view5E8_1;
        struct {
            char pad[0x2];
            s16 unk5EA;
        } view5EA_2;
        struct {
            char pad[0x2];
            s16 respawns;
        } view5EA_3;
        struct {
            char pad[0x2];
            s16 runType;
        } view5EA_4;
        struct {
            char pad[0x4];
            s32 unk5EC;
        } view5EC_5;
        struct {
            char pad[0x4];
            s32 model;
        } view5EC_6;
        struct {
            char pad[0x4];
            s32 spawnPoint;
        } view5EC_7;
        struct {
            char pad[0x4];
            s32 f5EC;
        } view5EC_8;
        struct {
            char pad[0x8];
            s32 unk5F0;
        } view5F0_9;
        struct {
            char pad[0x8];
            s32 f5F0;
        } view5F0_10;
        struct {
            char pad[0xC];
            s16 unk5F4[4];
        } view5F4_11;
        struct {
            char pad[0xC];
            s16 ammo[4];
        } view5F4_12;
        struct {
            char pad[0xC];
            s16 ammo[3];
        } view5F4_13;
        struct {
            char pad[0x1A];
            Shared_Slot slots[22];
        } view602_14;
        struct {
            char pad[0x46];
            s16 unk62E;
        } view62E_13;
        struct {
            char pad[0x46];
            s16 weapon;
        } view62E_14;
        struct {
            char pad[0x46];
            s16 character;
        } view62E_17;
        struct {
            char pad[0x68];
            s16 unk650;
        } view650_15;
        struct {
            char pad[0x68];
            s16 state;
        } view650_16;
        struct {
            char pad[0x68];
            s16 action;
        } view650_17;
        struct {
            char pad[0x68];
            s16 mode;
        } view650_18;
        struct {
            char pad[0x6A];
            s16 unk652;
        } view652_19;
        struct {
            char pad[0x6A];
            s16 previous;
        } view652_20;
        struct {
            char pad[0x6A];
            s16 pad652;
        } view652_24;
        struct {
            char pad[0x6C];
            s16 prevState;
        } view654_25;
        struct {
            char pad[0x6E];
            s16 pad656;
        } view656_26;
        struct {
            char pad[0x70];
            f32 unk658;
        } view658_21;
        struct {
            char pad[0x70];
            f32 counter;
        } view658_22;
        struct {
            char pad[0x70];
            f32 stride;
        } view658_23;
        struct {
            char pad[0x70];
            f32 swimTime;
        } view658_24;
        struct {
            char pad[0x70];
            f32 stateTime;
        } view658_31;
        struct {
            char pad[0x74];
            s32 unk65C;
        } view65C_32;
        struct {
            char pad[0x78];
            s32 unk660;
        } view660_25;
        struct {
            char pad[0x78];
            s32 previousTimer;
        } view660_26;
        struct {
            char pad[0x7C];
            s32 unk664;
        } view664_27;
        struct {
            char pad[0x7C];
            s32 timer;
        } view664_28;
        struct {
            char pad[0x84];
            f32 unk66C;
        } view66C_29;
        struct {
            char pad[0x88];
            f32 unk670;
        } view670_30;
        struct {
            char pad[0x88];
            f32 shield;
        } view670_31;
        struct {
            char pad[0x90];
            f32 unk678;
        } view678_40;
        struct {
            char pad[0xA0];
            char unk688[16];
        } view688_32;
        struct {
            char pad[0xA0];
            char body[16];
        } view688_33;
        struct {
            char pad[0xA0];
            Shared_Input input;
        } view688_43;
        struct {
            char pad[0xB0];
            struct Controller * unk698;
        } view698_34;
        struct {
            char pad[0xB0];
            struct Controller * controller;
        } view698_35;
        struct {
            char pad[0xB0];
            void * controller;
        } view698_36;
        struct {
            char pad[0xB0];
            char * emitter;
        } view698_37;
        struct {
            char pad[0xB0];
            char * title;
        } view698_38;
        struct {
            char pad[0xB4];
            f32 unk69C;
        } view69C_39;
        struct {
            char pad[0xB4];
            f32 stick;
        } view69C_40;
        struct {
            char pad[0xBC];
            f32 unk6A4;
        } view6A4_41;
        struct {
            char pad[0xBC];
            f32 strafe;
        } view6A4_42;
        struct {
            char pad[0xC0];
            f32 unk6A8;
        } view6A8_43;
        struct {
            char pad[0xC0];
            f32 lift;
        } view6A8_44;
        struct {
            char pad[0xC4];
            s32 unk6AC;
        } view6AC_45;
        struct {
            char pad[0xC8];
            s32 unk6B0;
        } view6B0_46;
        struct {
            char pad[0xC8];
            s32 input;
        } view6B0_47;
        struct {
            char pad[0xC8];
            s32 state;
        } view6B0_48;
        struct {
            char pad[0xD0];
            s32 unk6B8;
        } view6B8_49;
        struct {
            char pad[0xD0];
            s32 input;
        } view6B8_50;
        struct {
            char pad[0xD8];
            f32 unk6C0;
        } view6C0_51;
        struct {
            char pad[0xD8];
            f32 climb;
        } view6C0_52;
        struct {
            char pad[0xD8];
            f32 speed;
        } view6C0_53;
        struct {
            char pad[0xD8];
            f32 velX;
        } view6C0_64;
        struct {
            char pad[0xDC];
            f32 unk6C4;
        } view6C4_54;
        struct {
            char pad[0xDC];
            f32 side;
        } view6C4_55;
        struct {
            char pad[0xDC];
            f32 velZ;
        } view6C4_67;
        struct {
            char pad[0xE0];
            f32 unk6C8;
        } view6C8_56;
        struct {
            char pad[0xE0];
            f32 speed;
        } view6C8_57;
        struct {
            char pad[0xE4];
            f32 lastVelY;
        } view6CC_70;
        struct {
            char pad[0xE8];
            s32 onGround;
        } view6D0_71;
        struct {
            char pad[0xEC];
            f32 unk6D4;
        } view6D4_58;
        struct {
            char pad[0xF0];
            f32 unk6D8;
        } view6D8_59;
        struct {
            char pad[0xF4];
            f32 unk6DC;
        } view6DC_60;
        struct {
            char pad[0xFC];
            f32 unk6E4;
        } view6E4_61;
        struct {
            char pad[0xFC];
            f32 depth;
        } view6E4_62;
        struct {
            char pad[0xFC];
            f32 airTime;
        } view6E4_77;
        struct {
            char pad[0x100];
            f32 unk6E8;
        } view6E8_63;
        struct {
            char pad[0x100];
            Vec3 unk6E8;
        } view6E8_79;
        struct {
            char pad[0x104];
            f32 unk6EC;
        } view6EC_64;
        struct {
            char pad[0x104];
            f32 height;
        } view6EC_65;
        struct {
            char pad[0x108];
            f32 unk6F0;
        } view6F0_66;
        struct {
            char pad[0x10C];
            f32 unk6F4;
        } view6F4_83;
        struct {
            char pad[0x110];
            Vec3 unk6F8;
        } view6F8_84;
        struct {
            char pad[0x11C];
            f32 unk704;
        } view704_67;
        struct {
            char pad[0x11C];
            f32 lift;
        } view704_68;
        struct {
            char pad[0x130];
            f32 unk718;
        } view718_69;
        struct {
            char pad[0x130];
            f32 crouch;
        } view718_70;
        struct {
            char pad[0x134];
            s32 unk71C;
        } view71C_89;
        struct {
            char pad[0x138];
            f32 swim;
        } view720_90;
        struct {
            char pad[0x13C];
            f32 unk724;
        } view724_71;
        struct {
            char pad[0x13C];
            f32 pitch;
        } view724_72;
        struct {
            char pad[0x140];
            f32 unk728;
        } view728_73;
        struct {
            char pad[0x140];
            f32 kickPitch;
        } view728_74;
        struct {
            char pad[0x144];
            f32 unk72C;
        } view72C_75;
        struct {
            char pad[0x144];
            f32 kickRoll;
        } view72C_76;
        struct {
            char pad[0x144];
            f32 lean;
        } view72C_77;
        struct {
            char pad[0x148];
            f32 unk730[3];
        } view730_78;
        struct {
            char pad[0x148];
            f32 sway[3];
        } view730_79;
        struct {
            char pad[0x154];
            f32 unk73C;
        } view73C_80;
        struct {
            char pad[0x154];
            f32 side;
        } view73C_81;
        struct {
            char pad[0x154];
            Vec3 weapon;
        } view73C_82;
        struct {
            char pad[0x158];
            f32 unk740;
        } view740_83;
        struct {
            char pad[0x158];
            f32 height;
        } view740_84;
        struct {
            char pad[0x15C];
            f32 unk744;
        } view744_85;
        struct {
            char pad[0x15C];
            f32 forward;
        } view744_86;
        struct {
            char pad[0x170];
            f32 unk758;
        } view758_87;
        struct {
            char pad[0x170];
            f32 bobStrength;
        } view758_88;
        struct {
            char pad[0x174];
            f32 unk75C;
        } view75C_89;
        struct {
            char pad[0x174];
            f32 bobSpeed;
        } view75C_90;
        struct {
            char pad[0x188];
            s16 unk770;
        } view770_91;
        struct {
            char pad[0x188];
            s16 nextWeapon;
        } view770_92;
        struct {
            char pad[0x188];
            s16 weapon;
        } view770_113;
        struct {
            char pad[0x18A];
            s16 pad772;
        } view772_114;
        struct {
            char pad[0x18C];
            Vec3 unk774;
        } view774_115;
        struct {
            char pad[0x198];
            f32 unk780;
        } view780_116;
        struct {
            char pad[0x19C];
            f32 unk784;
        } view784_117;
        struct {
            char pad[0x1A0];
            s32 unk788;
        } view788_93;
        struct {
            char pad[0x1A0];
            s32 icons;
        } view788_94;
        struct {
            char pad[0x1B0];
            s32 unk798;
        } view798_95;
        struct {
            char pad[0x1B0];
            s32 carried;
        } view798_96;
        struct {
            char pad[0x1B4];
            Vec3 unk79C;
        } view79C_97;
        struct {
            char pad[0x1B4];
            Vec3 carriedPosition;
        } view79C_98;
        struct {
            char pad[0x1D0];
            s32 unk7B8;
        } view7B8_99;
        struct {
            char pad[0x1D0];
            s32 target;
        } view7B8_100;
        struct {
            char pad[0x1D4];
            f32 unk7BC;
        } view7BC_101;
        struct {
            char pad[0x1D4];
            f32 timer;
        } view7BC_102;
        struct {
            char pad[0x1D8];
            Vec3 unk7C0;
        } view7C0_103;
        struct {
            char pad[0x1D8];
            Vec3 targetPosition;
        } view7C0_104;
        struct {
            char pad[0x200];
            s32 unk7E8;
        } view7E8_105;
        struct {
            char pad[0x200];
            s32 zoomed;
        } view7E8_106;
        struct {
            char pad[0x204];
            f32 unk7EC;
        } view7EC_132;
        struct {
            char pad[0x208];
            f32 unk7F0;
        } view7F0_133;
        struct {
            char pad[0x224];
            struct Mount * unk80C;
        } view80C_107;
        struct {
            char pad[0x224];
            struct Mount * mount;
        } view80C_108;
        struct {
            char pad[0x228];
            s32 unk810;
        } view810_109;
        struct {
            char pad[0x228];
            s32 kind;
        } view810_110;
        struct {
            char pad[0x22C];
            Triple unk814;
        } view814_111;
        struct {
            char pad[0x22C];
            Triple offset;
        } view814_112;
        struct {
            char pad[0x250];
            f32 unk838;
        } view838_113;
        struct {
            char pad[0x250];
            f32 rideTime;
        } view838_114;
        struct {
            char pad[0x254];
            f32 unk83C;
        } view83C_115;
        struct {
            char pad[0x254];
            f32 bump;
        } view83C_116;
        struct {
            char pad[0x258];
            s32 unk840;
        } view840_117;
        struct {
            char pad[0x258];
            s32 surfaced;
        } view840_118;
        struct {
            char pad[0x264];
            s32 unk84C;
        } view84C_149;
        struct {
            char pad[0x26C];
            f32 unk854;
        } view854_147;
        struct {
            char pad[0x274];
            s32 unk85C;
        } view85C_119;
        struct {
            char pad[0x274];
            s32 w85C;
        } view85C_120;
        struct {
            char pad[0x27C];
            s32 unk864;
        } view864_121;
        struct {
            char pad[0x27C];
            s32 f864;
        } view864_122;
        struct {
            char pad[0x280];
            s32 unk868;
        } view868_123;
        struct {
            char pad[0x280];
            s32 f868;
        } view868_124;
        struct {
            char pad[0x284];
            s32 unk86C;
        } view86C_125;
        struct {
            char pad[0x284];
            s32 parameter;
        } view86C_126;
        struct {
            char pad[0x284];
            s32 animation;
        } view86C_127;
        struct {
            char pad[0x288];
            s32 unk870;
        } view870_157;
        struct {
            char pad[0x290];
            Shared_Effect effect;
        } view878_158;
        struct {
            char pad[0x350];
            char unk938[2188];
        } view938_128;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_129;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_130;
        struct {
            char pad[0x350];
            s32 unk938;
        } view938_162;
        struct {
            char pad[0x6D0];
            s32 unkCB8;
        } viewCB8_163;
        struct {
            char pad[0x6E4];
            s32 unkCCC;
        } viewCCC_164;
        struct {
            char pad[0x758];
            s32 unkD40;
        } viewD40_165;
        struct {
            char pad[0x96C];
            s32 unkF54;
        } viewF54_131;
        struct {
            char pad[0x96C];
            s32 selection;
        } viewF54_132;
        struct {
            char pad[0x9A8];
            s32 unkF90;
        } viewF90_133;
        struct {
            char pad[0x9A8];
            s32 choice;
        } viewF90_134;
        struct {
            char pad[0xBCC];
            s32 unk11B4;
        } view11B4_135;
        struct {
            char pad[0xBCC];
            s32 locked;
        } view11B4_136;
        struct {
            char pad[0xBD0];
            s32 unk11B8;
        } view11B8_137;
        struct {
            char pad[0xBD0];
            s32 frozen;
        } view11B8_138;
        struct {
            char pad[0xBD4];
            s32 unk11BC;
        } view11BC_139;
        struct {
            char pad[0xBD4];
            s32 f11BC;
        } view11BC_140;
        struct {
            char pad[0xBD8];
            s32 unk11C0;
        } view11C0_141;
        struct {
            char pad[0xBD8];
            s32 f11C0;
        } view11C0_142;
        struct {
            char pad[0xBDC];
            f32 unk11C4;
        } view11C4_143;
        struct {
            char pad[0xBDC];
            f32 soundTime;
        } view11C4_144;
        struct {
            char pad[0xBE4];
            s32 unk11CC;
        } view11CC_145;
        struct {
            char pad[0xBE4];
            s32 f11CC;
        } view11CC_146;
        struct {
            char pad[0xBF0];
            f32 unk11D8;
        } view11D8_147;
        struct {
            char pad[0xBF0];
            f32 recoil;
        } view11D8_148;
        struct {
            char pad[0xBF0];
            f32 stun;
        } view11D8_149;
        struct {
            char pad[0xBF4];
            f32 unk11DC;
        } view11DC_185;
        struct {
            char pad[0xBF8];
            f32 unk11E0;
        } view11E0_186;
        struct {
            char pad[0xC00];
            s32 unk11E8;
        } view11E8_150;
        struct {
            char pad[0xC00];
            s32 f11E8;
        } view11E8_151;
        struct {
            char pad[0xC04];
            f32 unk11EC;
        } view11EC_189;
        struct {
            char pad[0xC28];
            s32 unk1210;
        } view1210_152;
        struct {
            char pad[0xC28];
            s32 marker;
        } view1210_153;
        struct {
            char pad[0xC2C];
            s32 unk1214;
        } view1214_154;
        struct {
            char pad[0xC2C];
            s32 marker;
        } view1214_155;
        struct {
            char pad[0xC2C];
            s32 markerShown;
        } view1214_156;
        struct {
            char pad[0xC30];
            s32 unk1218;
        } view1218_157;
        struct {
            char pad[0xC30];
            s32 f1218;
        } view1218_158;
        struct {
            char pad[0xC34];
            s32 unk121C;
        } view121C_159;
        struct {
            char pad[0xC34];
            s32 f121C;
        } view121C_160;
        struct {
            char pad[0xC38];
            s32 unk1220;
        } view1220_161;
        struct {
            char pad[0xC38];
            s32 f1220;
        } view1220_162;
        struct { char pad[0xE]; s16 charge; } chargeView;
        struct { char pad[0x11F4 - 0x5E8]; f32 spin; s32 frame; } rapidFireView;
    } views5E8;
    union {
        struct {
            u32 unk122C;
        } view122C_0;
        struct {
            u32 flags;
        } view122C_1;
        struct {
            s32 options;
        } view122C_2;
        struct {
            s32 f122C;
        } view122C_3;
        struct {
            s32 fxFlags;
        } view122C_4;
    } views122C;
    f32 fxTime;
    f32 fxSpeed;
    s32 fxStage;
    char pad123C[0x4];
    f32 unk1240;
    f32 unk1244;
    char pad1248[0x7C];
    union {
        struct {
            s32 unk12C4;
        } view12C4_0;
        struct {
            s32 f12C4;
        } view12C4_1;
    } views12C4;
    union {
        struct {
            s32 unk12C8;
        } view12C8_0;
        struct {
            s32 f12C8;
        } view12C8_1;
    } views12C8;
    union {
        struct {
            s32 unk12CC[8];
        } view12CC_0;
        struct {
            s32 splitsA[8];
        } view12CC_1;
    } views12CC;
    s32 unk12EC;
    char pad12F0[0x4];
    union {
        struct {
            s32 unk12F4[8];
        } view12F4_0;
        struct {
            s32 splitsB[8];
        } view12F4_1;
    } views12F4;
    char pad1314[0x20];
    union {
        struct {
            s32 unk1334;
        } view1334_0;
        struct {
            s32 f1334;
        } view1334_1;
    } views1334;
    union {
        struct {
            s32 unk1338;
        } view1338_0;
        struct {
            s32 f1338;
        } view1338_1;
    } views1338;
    union {
        struct {
            s32 unk133C;
        } view133C_0;
        struct {
            s32 laps;
        } view133C_1;
        struct {
            s32 lives;
        } view133C_2;
    } views133C;
    union {
        struct {
            s32 unk1340;
        } view1340_0;
        struct {
            s32 stalls;
        } view1340_1;
        struct {
            s32 timer;
        } view1340_2;
        struct {
            s32 respawnTimer;
        } view1340_3;
    } views1340;
    char pad1344[0x70];
    union {
        struct {
            struct StateInfo * unk13B4;
        } view13B4_0;
        struct {
            struct StateInfo * states;
        } view13B4_1;
        struct {
            struct Mode * unk13B4;
        } view13B4_2;
        struct {
            void * character;
        } view13B4_3;
        struct {
            s32 f13B4;
        } view13B4_4;
        struct {
            struct Shared_StateInfo * states;
        } view13B4_5;
    } views13B4;
    char pad13B8[0x10];
    union {
        struct {
            s32 unk13C8;
        } view13C8_0;
        struct {
            s32 w13C8;
        } view13C8_1;
        struct {
            s32 f13C8;
        } view13C8_2;
    } views13C8;
    char pad13CC[0x8];
    s32 unk13D4;
    union {
        struct {
            struct Held * unk13D8;
        } view13D8_0;
        struct {
            struct Held * held;
        } view13D8_1;
    } views13D8;
    char pad13DC[0xC];
    s32 messageIndex;
    char pad13EC[0x64];
    union {
        struct {
            s32 unk1450;
        } view1450_0;
        struct {
            s32 computer;
        } view1450_1;
        struct {
            s32 infinite;
        } view1450_2;
        struct {
            s32 unlimited;
        } view1450_3;
        struct {
            s32 uncounted;
        } view1450_4;
        struct {
            s32 f1450;
        } view1450_5;
    } views1450;
    union {
        struct {
            s32 unk1454;
        } view1454_0;
        struct {
            s32 f1454;
        } view1454_1;
    } views1454;
    char pad1458[0xC];
    union {
        struct {
            Vec3 unk1464;
        } view1464_0;
        struct {
            Vec3 aim;
        } view1464_1;
    } views1464;
    char pad1470[0x10];
    union {
        struct {
            Matrix unk1480[2];
        } view1480_0;
        struct {
            Matrix beams[2];
        } view1480_1;
    } views1480;
    union {
        struct {
            Matrix unk1500[2];
        } view1500_0;
        struct {
            Matrix lasers[2];
        } view1500_1;
    } views1500;
    union {
        struct {
            Matrix unk1580[2];
        } view1580_0;
        struct {
            Matrix dots[2];
        } view1580_1;
    } views1580;
    char pad1600[0xD4];
    union {
        struct {
            s32 unk16D4;
        } view16D4_0;
        struct {
            s32 f16D4;
        } view16D4_1;
    } views16D4;
    u16 unk16D8;
    char pad16DA[0x6];
    union {
        struct {
            struct SharedPlayer_func_8022A398_de * unk16E0;
        } view16E0_0;
        struct {
            struct SharedPlayer_func_8022A398_de * next;
        } view16E0_1;
        struct {
            struct SharedPlayer_func_8022A398_de * next;
        } view16E0_2;
    } views16E0;
};
struct func_8024795C_S2;
typedef struct func_8024795C_S2 func_8024795C_S2;
struct SharedPlayer_func_8022A398_de;
typedef struct SharedPlayer_func_8022A398_de SharedPlayer_func_8022A398_de;
struct Profile_func_80408C4C_de;
struct Profile_func_80408C4C_de {
    u16 words[4];
    char pad8[0x78];
    u8 flags;
    char pad81[3];
    u8 name[8];
};
struct Player_func_802676EC_de;
struct Player_func_802676EC_de {
    char pad0[0x122C];
    s32 flags;
};
struct func_8028414C_S1;
typedef struct func_8028414C_S1 func_8028414C_S1;
struct func_8022BC04_S2;
struct func_8022BC04_S2 {
    char pad0[0x4];
    u16 unk4;
};
struct func_8024E8F0_S1;
struct func_8024E8F0_S1 {
    u8 unk0;
    char pad0[0x100 - 0x0 - sizeof(u8)];
    s32 unk100;
};
struct func_8024E8F0_S1;
typedef struct func_8024E8F0_S1 func_8024E8F0_S1;
struct Shape_typemap_165;
struct Shape_typemap_165 {
    int field_0;
    int field_4;
    int field_8;
    int field_C;
};
struct func_802066A4_S3;
typedef struct func_802066A4_S3 func_802066A4_S3;
struct func_8020EA10_S3;
typedef struct func_8020EA10_S3 func_8020EA10_S3;
struct func_80204468_S3;
typedef struct func_80204468_S3 func_80204468_S3;
struct func_80204468_S3;
struct func_80204468_S3 {
    char pad0[0x14];
    int unk14;
};
struct HeadRecord;
typedef struct HeadRecord HeadRecord;
struct func_80242278_S1;
struct func_80242278_S1 {
    char pad0[0x4];
    s8 unk4;
};
struct func_8024795C_S2;
struct func_8024795C_S2 {
    char pad0[0x5DC];
    char * unk5DC;
};
struct func_80242278_S1;
typedef struct func_80242278_S1 func_80242278_S1;
struct Owner8020F150;
struct Owner8020F150 {
    char pad[0x294];
    s32 active;
};
struct HeadRecord;
struct HeadRecord {
    void *head;
    char rest[0x10];
};
struct func_8020EA10_S3;
struct func_8020EA10_S3 {
    char pad0[0x8F];
    u8 unk8F;
};
extern float D_800CD740_de;
struct func_80283038_S1;
struct func_80283038_S1 {
    char pad0[0x5C];
    s32 unk5C;
    char pad5C[0x118 - 0x5C - sizeof(s32)];
    s32 * unk118;
};
struct func_8022BC04_S2;
typedef struct func_8022BC04_S2 func_8022BC04_S2;
struct func_8028414C_S1;
struct func_8028414C_S1 {
    char pad0[0x220];
    char unk220;
};
struct func_802066A4_S3;
struct func_802066A4_S3 {
    char pad0[0x18];
    s32 unk18;
};
struct func_80228774_S5;
typedef struct func_80228774_S5 func_80228774_S5;
struct func_80228774_S5;
struct func_80228774_S5 {
    char pad0[0x5DC];
    void * unk5DC;
};
struct func_80283038_S1;
typedef struct func_80283038_S1 func_80283038_S1;
struct Saved;
struct Saved {
    u16 values[4];
    u8 flag;
    u8 pad[3];
    u8 bytes[8];
};
struct Player_func_802676EC_de;
typedef struct Player_func_802676EC_de Player_func_802676EC_de;
struct func_8027C324_S3;
typedef struct func_8027C324_S3 func_8027C324_S3;
struct Owner_func_804099EC_de;
struct Profile_func_80408C4C_de;
struct Owner_func_804099EC_de {
    char pad[0x5D8];
    struct Profile_func_80408C4C_de *settings;
};
struct func_8027C324_S3;
struct func_8027C324_S3 {
    char pad0[0x70];
    u16 unk70;
    char pad70[0x8C - 0x70 - sizeof(u16)];
    u16 unk8C;
    char pad8C[0xA8 - 0x8C - sizeof(u16)];
    u16 unkA8;
};
struct Shape_typemap_3;
struct Shape_typemap_3 {
    int field_0;
};
extern int D_800DE87C_de;
struct Profile_func_80408C4C_de;
typedef struct Profile_func_80408C4C_de Profile_func_80408C4C_de;
struct func_80203C40_S1;
struct func_80203C40_S1 {
    char pad0[0x100];
    s32 unk100;
};
struct Vector4f;
typedef struct Vector4f Vector4f;
struct Vector4f;
struct Vector4f {
    float x;
    float y;
    float z;
    float w;
};
struct func_8022C6D4_S1;
struct func_8022C6D4_S1 {
    char pad0[0x650];
    s16 unk650;
};
struct func_80205628_S3;
struct func_80205628_S3 {
    char pad0[0xC];
    s32 unkC;
};
struct Hook;
struct Hook {
    char pad[8];
    void (*fn)(void *, void *);
};
struct Hook;
typedef struct Hook Hook;
struct func_8022FD9C_S1;
typedef struct func_8022FD9C_S1 func_8022FD9C_S1;
struct AudioState;
typedef struct AudioState AudioState;
struct func_80203B60_S1;
typedef struct func_80203B60_S1 func_80203B60_S1;
struct Actor_func_8028CC34_de;
struct Actor_func_8028CC34_de {
    char pad[0x1D8];
    int link;
};
struct Actor_func_8028CC34_de;
typedef struct Actor_func_8028CC34_de Actor_func_8028CC34_de;
struct Shape_func_8020AF9C_de_2;
struct Shape_func_8020AF9C_de_2 {
    int field_0;
};
union func_80230BB8_S2_U1D8;
union func_80230BB8_S2_U1D8 {
    char * v0;
    void * v1;
};
union func_80230BB8_S2_U1D8;
typedef union func_80230BB8_S2_U1D8 func_80230BB8_S2_U1D8;
struct func_80232C78_S4;
typedef struct func_80232C78_S4 func_80232C78_S4;
struct SharedPlayer;
typedef struct SharedPlayer SharedPlayer;
struct Body;
struct Character;
struct Controller;
struct Controls;
struct Ctrl;
struct Held;
struct Mode;
struct Model;
struct Mount;
struct Profile;
struct Record;
struct Rider_func_80203278_de;
struct Settings;
struct SharedPlayer;
struct Shared_Body;
struct Shared_Hud;
struct Shared_Model;
struct Shared_Profile;
struct Shared_StateInfo;
struct Shared_Voice;
struct StateInfo;
struct TeamInfo;
struct View;
struct SharedPlayer {
    union {
        struct {
            u8 unk0[24];
        } view0_0;
        struct {
            u8 pad0[24];
        } view0_1;
        struct {
            char pad[0x3];
            u8 team;
        } view3_2;
        struct {
            char pad[0x8];
            Vec3 unk8;
        } view8_2;
        struct {
            char pad[0x8];
            Vec3 pos;
        } view8_3;
        struct {
            char pad[0x8];
            Vec3 position;
        } view8_4;
        struct {
            char pad[0x14];
            struct Shared_Model * model;
        } view14_6;
        struct { char pad[8]; s32 positionWords[3]; } positionBits;
    } views0;
    union {
        struct {
            char * unk18;
        } view18_0;
        struct {
            char * track;
        } view18_1;
        struct {
            struct Model * model;
        } view18_2;
        struct {
            struct Body * body;
        } view18_3;
        struct {
            struct Character * character;
        } view18_4;
        struct {
            struct Shared_Body * body;
        } view18_5;
    } views18;
    union {
        struct {
            u8 unk1C[344];
        } view1C_0;
        struct {
            u8 pad1[344];
        } view1C_1;
        struct {
            char pad[0x4];
            f32 velY;
        } view20_2;
        struct {
            char pad[0x1C];
            s32 unk38;
        } view38_2;
        struct {
            char pad[0x1C];
            s32 flags;
        } view38_3;
        struct {
            char pad[0x24];
            f32 unk40;
        } view40_5;
        struct {
            char pad[0x40];
            Shared_Quad unk5C;
        } view5C_6;
        struct {
            char pad[0x50];
            f32 unk6C;
        } view6C_4;
        struct {
            char pad[0x50];
            f32 heading;
        } view6C_5;
        struct {
            char pad[0x50];
            f32 yaw;
        } view6C_9;
        struct {
            char pad[0xC8];
            u16 unkE4;
        } viewE4_6;
        struct {
            char pad[0xC8];
            u16 kind;
        } viewE4_7;
        struct {
            char pad[0xE4];
            s32 unk100;
        } view100_8;
        struct {
            char pad[0xE4];
            s32 flags;
        } view100_9;
        struct {
            char pad[0xE8];
            f32 unk104;
        } view104_10;
        struct {
            char pad[0xE8];
            f32 idleTime;
        } view104_11;
        struct {
            char pad[0xEC];
            s16 anim;
        } view108_16;
        struct {
            char pad[0xF2];
            s8 unk10E;
        } view10E_12;
        struct {
            char pad[0xF2];
            s8 idle;
        } view10E_13;
        struct {
            char pad[0xF2];
            s8 replaying;
        } view10E_14;
        struct {
            char pad[0xF2];
            s8 animPending;
        } view10E_20;
        struct {
            char pad[0x154];
            char unk170[100];
        } view170_15;
        struct {
            char pad[0x154];
            char body[100];
        } view170_16;
        struct {
            char pad[0x154];
            s32 unk170;
        } view170_23;
        struct {
            char pad[0x158];
            s32 unk174;
        } view174_17;
        struct {
            char pad[0x15C];
            u8 unk178[740];
        } view178_18;
        struct {
            char pad[0x15C];
            u8 pad2[740];
        } view178_19;
        struct {
            char pad[0x1B8];
            f32 unk1D4;
        } view1D4_20;
        struct {
            char pad[0x1B8];
            f32 holdTime;
        } view1D4_21;
        struct {
            char pad[0x1BC];
            struct SharedPlayer * unk1D8;
        } view1D8_22;
        struct {
            char pad[0x1BC];
            struct SharedPlayer * self;
        } view1D8_23;
        struct {
            char pad[0x1BC];
            struct SharedPlayer * f1D8;
        } view1D8_24;
        struct {
            char pad[0x1BC];
            void * unk1D8;
        } view1D8_32;
        struct {
            char pad[0x244];
            Vec3 unk260;
        } view260_25;
        struct {
            char pad[0x244];
            Vec3 muzzle;
        } view260_26;
        struct {
            char pad[0x2CC];
            char unk2E8[368];
        } view2E8_27;
        struct {
            char pad[0x2CC];
            char weapon[368];
        } view2E8_28;
        struct {
            char pad[0x2CC];
            Shared_Emitter emitter;
        } view2E8_37;
        struct {
            char pad[0x43C];
            char unk458[384];
        } view458_29;
        struct {
            char pad[0x43C];
            char ammo[384];
        } view458_30;
        struct {
            char pad[0x43C];
            s32 unk458;
        } view458_40;
        struct {
            char pad[0x440];
            s32 unk45C;
        } view45C_31;
        struct {
            char pad[0x444];
            u8 unk460[376];
        } view460_32;
        struct {
            char pad[0x444];
            u8 pad3[376];
        } view460_33;
        struct {
            char pad[0x468];
            struct Shared_Voice * voice;
        } view484_44;
        struct {
            char pad[0x470];
            s8 unk48C;
        } view48C_34;
        struct {
            char pad[0x470];
            s8 state;
        } view48C_35;
        struct {
            char pad[0x4A4];
            void * unk4C0;
        } view4C0_47;
        struct {
            char pad[0x507];
            s8 unk523;
        } view523_36;
        struct {
            char pad[0x507];
            s8 busy;
        } view523_37;
        struct {
            char pad[0x578];
            s32 unk594;
        } view594_38;
        struct {
            char pad[0x578];
            s32 gear;
        } view594_39;
        struct {
            char pad[0x578];
            s32 mode;
        } view594_40;
        struct {
            char pad[0x584];
            f32 unk5A0;
        } view5A0_41;
        struct {
            char pad[0x584];
            f32 charge;
        } view5A0_42;
        struct {
            char pad[0x5B4];
            s32 unk5D0;
        } view5D0_43;
        struct {
            char pad[0x5B4];
            s32 f5D0;
        } view5D0_44;
        struct {
            char pad[0x5B8];
            s32 unk5D4;
        } view5D4_45;
        struct {
            char pad[0x5B8];
            s32 slot;
        } view5D4_46;
        struct {
            char pad[0x5B8];
            s32 profile;
        } view5D4_47;
        struct {
            char pad[0x5B8];
            s32 f5D4;
        } view5D4_48;
    } views1C;
    union {
        struct {
            struct Record * unk5D8;
        } view5D8_0;
        struct {
            struct Record * record;
        } view5D8_1;
        struct {
            struct Controls * controls;
        } view5D8_2;
        struct {
            struct TeamInfo * teamInfo;
        } view5D8_3;
        struct {
            struct Ctrl * ctrl;
        } view5D8_4;
        struct {
            unsigned char * info;
        } view5D8_5;
        struct {
            struct Profile * profile;
        } view5D8_6;
        struct {
            struct Settings * settings;
        } view5D8_7;
        struct {
            s32 f5D8;
        } view5D8_8;
        struct {
            struct Shared_Profile * profile;
        } view5D8_9;
    } views5D8;
    union {
        struct {
            void * unk5DC;
        } view5DC_0;
        struct {
            void * view;
        } view5DC_1;
        struct {
            struct View * view;
        } view5DC_2;
        struct {
            u8 pad4[8];
        } view5DC_3;
        struct {
            void * entity;
        } view5DC_4;
        struct {
            struct Rider_func_80203278_de * rider;
        } view5DC_5;
        struct {
            char * storage;
        } view5DC_6;
        struct {
            char * messages;
        } view5DC_7;
        struct {
            struct Shared_Hud * hud;
        } view5DC_8;
        struct {
            char pad[0x4];
            s32 unk5E0;
        } view5E0_8;
        struct {
            char pad[0x4];
            s32 state;
        } view5E0_9;
        struct {
            char pad[0x4];
            s32 slot;
        } view5E0_10;
    } views5DC;
    union {
        struct {
            s32 unk5E4;
        } view5E4_0;
        struct {
            s32 active;
        } view5E4_1;
        struct {
            s32 health;
        } view5E4_2;
        struct {
            s32 alive;
        } view5E4_3;
        struct {
            s32 holding;
        } view5E4_4;
    } views5E4;
    union {
        struct {
            u8 unk5E8[3140];
        } view5E8_0;
        struct {
            u8 pad5[3140];
        } view5E8_1;
        struct {
            char pad[0x2];
            s16 unk5EA;
        } view5EA_2;
        struct {
            char pad[0x2];
            s16 respawns;
        } view5EA_3;
        struct {
            char pad[0x2];
            s16 runType;
        } view5EA_4;
        struct {
            char pad[0x4];
            s32 unk5EC;
        } view5EC_5;
        struct {
            char pad[0x4];
            s32 model;
        } view5EC_6;
        struct {
            char pad[0x4];
            s32 spawnPoint;
        } view5EC_7;
        struct {
            char pad[0x4];
            s32 f5EC;
        } view5EC_8;
        struct {
            char pad[0x8];
            s32 unk5F0;
        } view5F0_9;
        struct {
            char pad[0x8];
            s32 f5F0;
        } view5F0_10;
        struct {
            char pad[0xC];
            s16 unk5F4[4];
        } view5F4_11;
        struct {
            char pad[0xC];
            s16 ammo[4];
        } view5F4_12;
        struct {
            char pad[0xC];
            s16 ammo[3];
        } view5F4_13;
        struct {
            char pad[0x1A];
            Shared_Slot slots[22];
        } view602_14;
        struct {
            char pad[0x46];
            s16 unk62E;
        } view62E_13;
        struct {
            char pad[0x46];
            s16 weapon;
        } view62E_14;
        struct {
            char pad[0x46];
            s16 character;
        } view62E_17;
        struct {
            char pad[0x68];
            s16 unk650;
        } view650_15;
        struct {
            char pad[0x68];
            s16 state;
        } view650_16;
        struct {
            char pad[0x68];
            s16 action;
        } view650_17;
        struct {
            char pad[0x68];
            s16 mode;
        } view650_18;
        struct {
            char pad[0x6A];
            s16 unk652;
        } view652_19;
        struct {
            char pad[0x6A];
            s16 previous;
        } view652_20;
        struct {
            char pad[0x6A];
            s16 pad652;
        } view652_24;
        struct {
            char pad[0x6C];
            s16 prevState;
        } view654_25;
        struct {
            char pad[0x6E];
            s16 pad656;
        } view656_26;
        struct {
            char pad[0x70];
            f32 unk658;
        } view658_21;
        struct {
            char pad[0x70];
            f32 counter;
        } view658_22;
        struct {
            char pad[0x70];
            f32 stride;
        } view658_23;
        struct {
            char pad[0x70];
            f32 swimTime;
        } view658_24;
        struct {
            char pad[0x70];
            f32 stateTime;
        } view658_31;
        struct {
            char pad[0x74];
            s32 unk65C;
        } view65C_32;
        struct {
            char pad[0x78];
            s32 unk660;
        } view660_25;
        struct {
            char pad[0x78];
            s32 previousTimer;
        } view660_26;
        struct {
            char pad[0x7C];
            s32 unk664;
        } view664_27;
        struct {
            char pad[0x7C];
            s32 timer;
        } view664_28;
        struct {
            char pad[0x84];
            f32 unk66C;
        } view66C_29;
        struct {
            char pad[0x88];
            f32 unk670;
        } view670_30;
        struct {
            char pad[0x88];
            f32 shield;
        } view670_31;
        struct {
            char pad[0x90];
            f32 unk678;
        } view678_40;
        struct {
            char pad[0xA0];
            char unk688[16];
        } view688_32;
        struct {
            char pad[0xA0];
            char body[16];
        } view688_33;
        struct {
            char pad[0xA0];
            Shared_Input input;
        } view688_43;
        struct {
            char pad[0xB0];
            struct Controller * unk698;
        } view698_34;
        struct {
            char pad[0xB0];
            struct Controller * controller;
        } view698_35;
        struct {
            char pad[0xB0];
            void * controller;
        } view698_36;
        struct {
            char pad[0xB0];
            char * emitter;
        } view698_37;
        struct {
            char pad[0xB0];
            char * title;
        } view698_38;
        struct {
            char pad[0xB4];
            f32 unk69C;
        } view69C_39;
        struct {
            char pad[0xB4];
            f32 stick;
        } view69C_40;
        struct {
            char pad[0xBC];
            f32 unk6A4;
        } view6A4_41;
        struct {
            char pad[0xBC];
            f32 strafe;
        } view6A4_42;
        struct {
            char pad[0xC0];
            f32 unk6A8;
        } view6A8_43;
        struct {
            char pad[0xC0];
            f32 lift;
        } view6A8_44;
        struct {
            char pad[0xC4];
            s32 unk6AC;
        } view6AC_45;
        struct {
            char pad[0xC8];
            s32 unk6B0;
        } view6B0_46;
        struct {
            char pad[0xC8];
            s32 input;
        } view6B0_47;
        struct {
            char pad[0xC8];
            s32 state;
        } view6B0_48;
        struct {
            char pad[0xD0];
            s32 unk6B8;
        } view6B8_49;
        struct {
            char pad[0xD0];
            s32 input;
        } view6B8_50;
        struct {
            char pad[0xD8];
            f32 unk6C0;
        } view6C0_51;
        struct {
            char pad[0xD8];
            f32 climb;
        } view6C0_52;
        struct {
            char pad[0xD8];
            f32 speed;
        } view6C0_53;
        struct {
            char pad[0xD8];
            f32 velX;
        } view6C0_64;
        struct {
            char pad[0xDC];
            f32 unk6C4;
        } view6C4_54;
        struct {
            char pad[0xDC];
            f32 side;
        } view6C4_55;
        struct {
            char pad[0xDC];
            f32 velZ;
        } view6C4_67;
        struct {
            char pad[0xE0];
            f32 unk6C8;
        } view6C8_56;
        struct {
            char pad[0xE0];
            f32 speed;
        } view6C8_57;
        struct {
            char pad[0xE4];
            f32 lastVelY;
        } view6CC_70;
        struct {
            char pad[0xE8];
            s32 onGround;
        } view6D0_71;
        struct {
            char pad[0xEC];
            f32 unk6D4;
        } view6D4_58;
        struct {
            char pad[0xF0];
            f32 unk6D8;
        } view6D8_59;
        struct {
            char pad[0xF4];
            f32 unk6DC;
        } view6DC_60;
        struct {
            char pad[0xFC];
            f32 unk6E4;
        } view6E4_61;
        struct {
            char pad[0xFC];
            f32 depth;
        } view6E4_62;
        struct {
            char pad[0xFC];
            f32 airTime;
        } view6E4_77;
        struct {
            char pad[0x100];
            f32 unk6E8;
        } view6E8_63;
        struct {
            char pad[0x100];
            Vec3 unk6E8;
        } view6E8_79;
        struct {
            char pad[0x104];
            f32 unk6EC;
        } view6EC_64;
        struct {
            char pad[0x104];
            f32 height;
        } view6EC_65;
        struct {
            char pad[0x108];
            f32 unk6F0;
        } view6F0_66;
        struct {
            char pad[0x10C];
            f32 unk6F4;
        } view6F4_83;
        struct {
            char pad[0x110];
            Vec3 unk6F8;
        } view6F8_84;
        struct {
            char pad[0x11C];
            f32 unk704;
        } view704_67;
        struct {
            char pad[0x11C];
            f32 lift;
        } view704_68;
        struct {
            char pad[0x130];
            f32 unk718;
        } view718_69;
        struct {
            char pad[0x130];
            f32 crouch;
        } view718_70;
        struct {
            char pad[0x134];
            s32 unk71C;
        } view71C_89;
        struct {
            char pad[0x138];
            f32 swim;
        } view720_90;
        struct {
            char pad[0x13C];
            f32 unk724;
        } view724_71;
        struct {
            char pad[0x13C];
            f32 pitch;
        } view724_72;
        struct {
            char pad[0x140];
            f32 unk728;
        } view728_73;
        struct {
            char pad[0x140];
            f32 kickPitch;
        } view728_74;
        struct {
            char pad[0x144];
            f32 unk72C;
        } view72C_75;
        struct {
            char pad[0x144];
            f32 kickRoll;
        } view72C_76;
        struct {
            char pad[0x144];
            f32 lean;
        } view72C_77;
        struct {
            char pad[0x148];
            f32 unk730[3];
        } view730_78;
        struct {
            char pad[0x148];
            f32 sway[3];
        } view730_79;
        struct {
            char pad[0x154];
            f32 unk73C;
        } view73C_80;
        struct {
            char pad[0x154];
            f32 side;
        } view73C_81;
        struct {
            char pad[0x154];
            Vec3 weapon;
        } view73C_82;
        struct {
            char pad[0x158];
            f32 unk740;
        } view740_83;
        struct {
            char pad[0x158];
            f32 height;
        } view740_84;
        struct {
            char pad[0x15C];
            f32 unk744;
        } view744_85;
        struct {
            char pad[0x15C];
            f32 forward;
        } view744_86;
        struct {
            char pad[0x170];
            f32 unk758;
        } view758_87;
        struct {
            char pad[0x170];
            f32 bobStrength;
        } view758_88;
        struct {
            char pad[0x174];
            f32 unk75C;
        } view75C_89;
        struct {
            char pad[0x174];
            f32 bobSpeed;
        } view75C_90;
        struct {
            char pad[0x188];
            s16 unk770;
        } view770_91;
        struct {
            char pad[0x188];
            s16 nextWeapon;
        } view770_92;
        struct {
            char pad[0x188];
            s16 weapon;
        } view770_113;
        struct {
            char pad[0x18A];
            s16 pad772;
        } view772_114;
        struct {
            char pad[0x18C];
            Vec3 unk774;
        } view774_115;
        struct {
            char pad[0x198];
            f32 unk780;
        } view780_116;
        struct {
            char pad[0x19C];
            f32 unk784;
        } view784_117;
        struct {
            char pad[0x1A0];
            s32 unk788;
        } view788_93;
        struct {
            char pad[0x1A0];
            s32 icons;
        } view788_94;
        struct {
            char pad[0x1B0];
            s32 unk798;
        } view798_95;
        struct {
            char pad[0x1B0];
            s32 carried;
        } view798_96;
        struct {
            char pad[0x1B4];
            Vec3 unk79C;
        } view79C_97;
        struct {
            char pad[0x1B4];
            Vec3 carriedPosition;
        } view79C_98;
        struct {
            char pad[0x1D0];
            s32 unk7B8;
        } view7B8_99;
        struct {
            char pad[0x1D0];
            s32 target;
        } view7B8_100;
        struct {
            char pad[0x1D4];
            f32 unk7BC;
        } view7BC_101;
        struct {
            char pad[0x1D4];
            f32 timer;
        } view7BC_102;
        struct {
            char pad[0x1D8];
            Vec3 unk7C0;
        } view7C0_103;
        struct {
            char pad[0x1D8];
            Vec3 targetPosition;
        } view7C0_104;
        struct {
            char pad[0x200];
            s32 unk7E8;
        } view7E8_105;
        struct {
            char pad[0x200];
            s32 zoomed;
        } view7E8_106;
        struct {
            char pad[0x204];
            f32 unk7EC;
        } view7EC_132;
        struct {
            char pad[0x208];
            f32 unk7F0;
        } view7F0_133;
        struct {
            char pad[0x224];
            struct Mount * unk80C;
        } view80C_107;
        struct {
            char pad[0x224];
            struct Mount * mount;
        } view80C_108;
        struct {
            char pad[0x228];
            s32 unk810;
        } view810_109;
        struct {
            char pad[0x228];
            s32 kind;
        } view810_110;
        struct {
            char pad[0x22C];
            Triple unk814;
        } view814_111;
        struct {
            char pad[0x22C];
            Triple offset;
        } view814_112;
        struct {
            char pad[0x250];
            f32 unk838;
        } view838_113;
        struct {
            char pad[0x250];
            f32 rideTime;
        } view838_114;
        struct {
            char pad[0x254];
            f32 unk83C;
        } view83C_115;
        struct {
            char pad[0x254];
            f32 bump;
        } view83C_116;
        struct {
            char pad[0x258];
            s32 unk840;
        } view840_117;
        struct {
            char pad[0x258];
            s32 surfaced;
        } view840_118;
        struct {
            char pad[0x264];
            s32 unk84C;
        } view84C_149;
        struct {
            char pad[0x26C];
            f32 unk854;
        } view854_147;
        struct {
            char pad[0x274];
            s32 unk85C;
        } view85C_119;
        struct {
            char pad[0x274];
            s32 w85C;
        } view85C_120;
        struct {
            char pad[0x27C];
            s32 unk864;
        } view864_121;
        struct {
            char pad[0x27C];
            s32 f864;
        } view864_122;
        struct {
            char pad[0x280];
            s32 unk868;
        } view868_123;
        struct {
            char pad[0x280];
            s32 f868;
        } view868_124;
        struct {
            char pad[0x284];
            s32 unk86C;
        } view86C_125;
        struct {
            char pad[0x284];
            s32 parameter;
        } view86C_126;
        struct {
            char pad[0x284];
            s32 animation;
        } view86C_127;
        struct {
            char pad[0x288];
            s32 unk870;
        } view870_157;
        struct {
            char pad[0x290];
            Shared_Effect effect;
        } view878_158;
        struct {
            char pad[0x350];
            char unk938[2188];
        } view938_128;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_129;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_130;
        struct {
            char pad[0x350];
            s32 unk938;
        } view938_162;
        struct {
            char pad[0x6D0];
            s32 unkCB8;
        } viewCB8_163;
        struct {
            char pad[0x6E4];
            s32 unkCCC;
        } viewCCC_164;
        struct {
            char pad[0x758];
            s32 unkD40;
        } viewD40_165;
        struct {
            char pad[0x96C];
            s32 unkF54;
        } viewF54_131;
        struct {
            char pad[0x96C];
            s32 selection;
        } viewF54_132;
        struct {
            char pad[0x9A8];
            s32 unkF90;
        } viewF90_133;
        struct {
            char pad[0x9A8];
            s32 choice;
        } viewF90_134;
        struct {
            char pad[0xBCC];
            s32 unk11B4;
        } view11B4_135;
        struct {
            char pad[0xBCC];
            s32 locked;
        } view11B4_136;
        struct {
            char pad[0xBD0];
            s32 unk11B8;
        } view11B8_137;
        struct {
            char pad[0xBD0];
            s32 frozen;
        } view11B8_138;
        struct {
            char pad[0xBD4];
            s32 unk11BC;
        } view11BC_139;
        struct {
            char pad[0xBD4];
            s32 f11BC;
        } view11BC_140;
        struct {
            char pad[0xBD8];
            s32 unk11C0;
        } view11C0_141;
        struct {
            char pad[0xBD8];
            s32 f11C0;
        } view11C0_142;
        struct {
            char pad[0xBDC];
            f32 unk11C4;
        } view11C4_143;
        struct {
            char pad[0xBDC];
            f32 soundTime;
        } view11C4_144;
        struct {
            char pad[0xBE4];
            s32 unk11CC;
        } view11CC_145;
        struct {
            char pad[0xBE4];
            s32 f11CC;
        } view11CC_146;
        struct {
            char pad[0xBF0];
            f32 unk11D8;
        } view11D8_147;
        struct {
            char pad[0xBF0];
            f32 recoil;
        } view11D8_148;
        struct {
            char pad[0xBF0];
            f32 stun;
        } view11D8_149;
        struct {
            char pad[0xBF4];
            f32 unk11DC;
        } view11DC_185;
        struct {
            char pad[0xBF8];
            f32 unk11E0;
        } view11E0_186;
        struct {
            char pad[0xC00];
            s32 unk11E8;
        } view11E8_150;
        struct {
            char pad[0xC00];
            s32 f11E8;
        } view11E8_151;
        struct {
            char pad[0xC04];
            f32 unk11EC;
        } view11EC_189;
        struct {
            char pad[0xC28];
            s32 unk1210;
        } view1210_152;
        struct {
            char pad[0xC28];
            s32 marker;
        } view1210_153;
        struct {
            char pad[0xC2C];
            s32 unk1214;
        } view1214_154;
        struct {
            char pad[0xC2C];
            s32 marker;
        } view1214_155;
        struct {
            char pad[0xC2C];
            s32 markerShown;
        } view1214_156;
        struct {
            char pad[0xC30];
            s32 unk1218;
        } view1218_157;
        struct {
            char pad[0xC30];
            s32 f1218;
        } view1218_158;
        struct {
            char pad[0xC34];
            s32 unk121C;
        } view121C_159;
        struct {
            char pad[0xC34];
            s32 f121C;
        } view121C_160;
        struct {
            char pad[0xC38];
            s32 unk1220;
        } view1220_161;
        struct {
            char pad[0xC38];
            s32 f1220;
        } view1220_162;
        struct { char pad[0xE]; s16 charge; } chargeView;
        struct { char pad[0x11F4 - 0x5E8]; f32 spin; s32 frame; } rapidFireView;
    } views5E8;
    union {
        struct {
            u32 unk122C;
        } view122C_0;
        struct {
            u32 flags;
        } view122C_1;
        struct {
            s32 options;
        } view122C_2;
        struct {
            s32 f122C;
        } view122C_3;
        struct {
            s32 fxFlags;
        } view122C_4;
    } views122C;
    f32 fxTime;
    f32 fxSpeed;
    s32 fxStage;
    char pad123C[0x4];
    f32 unk1240;
    f32 unk1244;
    char pad1248[0x7C];
    union {
        struct {
            s32 unk12C4;
        } view12C4_0;
        struct {
            s32 f12C4;
        } view12C4_1;
    } views12C4;
    union {
        struct {
            s32 unk12C8;
        } view12C8_0;
        struct {
            s32 f12C8;
        } view12C8_1;
    } views12C8;
    union {
        struct {
            s32 unk12CC[8];
        } view12CC_0;
        struct {
            s32 splitsA[8];
        } view12CC_1;
    } views12CC;
    s32 unk12EC;
    char pad12F0[0x4];
    union {
        struct {
            s32 unk12F4[8];
        } view12F4_0;
        struct {
            s32 splitsB[8];
        } view12F4_1;
    } views12F4;
    char pad1314[0x20];
    union {
        struct {
            s32 unk1334;
        } view1334_0;
        struct {
            s32 f1334;
        } view1334_1;
    } views1334;
    union {
        struct {
            s32 unk1338;
        } view1338_0;
        struct {
            s32 f1338;
        } view1338_1;
    } views1338;
    union {
        struct {
            s32 unk133C;
        } view133C_0;
        struct {
            s32 laps;
        } view133C_1;
        struct {
            s32 lives;
        } view133C_2;
    } views133C;
    union {
        struct {
            s32 unk1340;
        } view1340_0;
        struct {
            s32 stalls;
        } view1340_1;
        struct {
            s32 timer;
        } view1340_2;
        struct {
            s32 respawnTimer;
        } view1340_3;
    } views1340;
    char pad1344[0x70];
    union {
        struct {
            struct StateInfo * unk13B4;
        } view13B4_0;
        struct {
            struct StateInfo * states;
        } view13B4_1;
        struct {
            struct Mode * unk13B4;
        } view13B4_2;
        struct {
            void * character;
        } view13B4_3;
        struct {
            s32 f13B4;
        } view13B4_4;
        struct {
            struct Shared_StateInfo * states;
        } view13B4_5;
    } views13B4;
    char pad13B8[0x10];
    union {
        struct {
            s32 unk13C8;
        } view13C8_0;
        struct {
            s32 w13C8;
        } view13C8_1;
        struct {
            s32 f13C8;
        } view13C8_2;
    } views13C8;
    char pad13CC[0x8];
    s32 unk13D4;
    union {
        struct {
            struct Held * unk13D8;
        } view13D8_0;
        struct {
            struct Held * held;
        } view13D8_1;
    } views13D8;
    char pad13DC[0xC];
    s32 messageIndex;
    char pad13EC[0x64];
    union {
        struct {
            s32 unk1450;
        } view1450_0;
        struct {
            s32 computer;
        } view1450_1;
        struct {
            s32 infinite;
        } view1450_2;
        struct {
            s32 unlimited;
        } view1450_3;
        struct {
            s32 uncounted;
        } view1450_4;
        struct {
            s32 f1450;
        } view1450_5;
    } views1450;
    union {
        struct {
            s32 unk1454;
        } view1454_0;
        struct {
            s32 f1454;
        } view1454_1;
    } views1454;
    char pad1458[0xC];
    union {
        struct {
            Vec3 unk1464;
        } view1464_0;
        struct {
            Vec3 aim;
        } view1464_1;
    } views1464;
    char pad1470[0x10];
    union {
        struct {
            Matrix unk1480[2];
        } view1480_0;
        struct {
            Matrix beams[2];
        } view1480_1;
    } views1480;
    union {
        struct {
            Matrix unk1500[2];
        } view1500_0;
        struct {
            Matrix lasers[2];
        } view1500_1;
    } views1500;
    union {
        struct {
            Matrix unk1580[2];
        } view1580_0;
        struct {
            Matrix dots[2];
        } view1580_1;
    } views1580;
    char pad1600[0xD4];
    union {
        struct {
            s32 unk16D4;
        } view16D4_0;
        struct {
            s32 f16D4;
        } view16D4_1;
    } views16D4;
    u16 unk16D8;
    char pad16DA[0x6];
    union {
        struct {
            struct SharedPlayer * unk16E0;
        } view16E0_0;
        struct {
            struct SharedPlayer * next;
        } view16E0_1;
        struct {
            struct SharedPlayer * next;
        } view16E0_2;
    } views16E0;
};
struct Rider_func_80203278_de {
    char pad0[0x80];
    SharedPlayer *target;
    char pad84[0xAC];
    Vec3 aim;
};
struct WeaponFireState;
struct WeaponFireState {
    char pad0[0x34];
    s8 variant;
    char pad35[0x124 - 0x35];
    union { f32 spinStep; s32 reset; };
    f32 spin;
    char pad12C[0x13C - 0x12C];
    s32 mode;
    char pad140[4];
    s32 rounds;
    char pad148[4];
    s32 triggered;
    s32 alternate;
};
union func_80203908_S3_U124;
typedef union func_80203908_S3_U124 func_80203908_S3_U124;
union func_80203908_S3_U124;
union func_80203908_S3_U124 {
    f32 v0;
    s32 v1;
};
struct func_80232FE8_S1;
struct func_80232FE8_S1 {
    char pad0[0x100];
    s32 unk100;
    char pad100[0x1D8 - 0x100 - sizeof(s32)];
    void * unk1D8;
};
struct Shared_Actor;
typedef struct Shared_Actor Shared_Actor;
struct func_80230BB8_S3;
typedef struct func_80230BB8_S3 func_80230BB8_S3;
union func_8022FD9C_S2_U770;
union func_8022FD9C_S2_U770 {
    s16 v0;
    u16 v1;
};
struct func_8022E3B4_S1;
struct func_8022E3B4_S1 {
    char pad0[0x1450];
    s32 unk1450;
};
struct func_802063EC_S2;
struct func_802063EC_S2 {
    char pad0[0x128];
    s32 unk128;
};
struct func_80230BB8_S3;
struct func_80230BB8_S3 {
    char pad0[0x23C];
    s32 unk23C;
};
struct func_8020A028_S3;
typedef struct func_8020A028_S3 func_8020A028_S3;
struct func_8022FD9C_S4;
typedef struct func_8022FD9C_S4 func_8022FD9C_S4;
struct SettingsE;
struct SettingsE {
    char pad0[0xD];
    u8 players;
};
struct func_8022FD9C_S3;
typedef struct func_8022FD9C_S3 func_8022FD9C_S3;
union func_8022FD9C_S2_U770;
typedef union func_8022FD9C_S2_U770 func_8022FD9C_S2_U770;
struct func_8022FD9C_S2;
struct func_8022FD9C_S2 {
    char pad0[0x5DC];
    void * unk5DC;
    char pad5DC[0x62E - 0x5DC - sizeof(void*)];
    s16 unk62E;
    char pad62E[0x770 - 0x62E - sizeof(s16)];
    func_8022FD9C_S2_U770 unk770;
    char pad770[0x13B8 - 0x770 - sizeof(func_8022FD9C_S2_U770)];
    s32 unk13B8;
    char pad13B8[0x13BC - 0x13B8 - sizeof(s32)];
    s32 unk13BC;
    char pad13BC[0x13C0 - 0x13BC - sizeof(s32)];
    s32 unk13C0;
};
struct IntegerState11C4;
typedef struct IntegerState11C4 IntegerState11C4;
struct func_80203DF0_S3;
typedef struct func_80203DF0_S3 func_80203DF0_S3;
struct func_80203908_S1;
struct func_80203908_S1 {
    char pad0[0x18];
    void * unk18;
    char pad18[0xE4 - 0x18 - sizeof(void*)];
    u16 unkE4;
    char padE4[0x100 - 0xE4 - sizeof(u16)];
    s32 unk100;
};
struct func_80205494_S2;
typedef struct func_80205494_S2 func_80205494_S2;
struct func_80232C78_S4;
struct func_80232C78_S4 {
    char pad0[0x18];
    f32 unk18;
};
struct func_8022FD9C_Record;
struct func_8022FD9C_Record {
    char pad0[0x54];
    s32 unk54;
};
struct WeaponActionRecord;
typedef struct WeaponActionRecord WeaponActionRecord;
struct Info;
typedef struct Info Info;
struct Info;
struct Info {
    unsigned char raw[0x18];
};
struct Shared_Actor;
struct Shared_Entity;
struct Shared_Variant;
struct Shared_Actor {
    u8 pad0;
    u8 color;
    u8 pad1;
    s8 subtype;
    u8 pad2[20];
    struct Shared_Variant * variant;
    u8 pad3[152];
    s32 action;
    u8 pad4[0x100 - 0xB8];
    s32 weaponFlags;
    u8 pad104[0x140 - 0x104];
    Info effects[6];
    u8 pad5[8];
    struct Shared_Entity * entity;
};
struct WeaponFireState;
typedef struct WeaponFireState WeaponFireState;
struct func_802077F4_S2;
typedef struct func_802077F4_S2 func_802077F4_S2;
struct func_802077F4_S2;
struct func_802077F4_S2 {
    char pad0[0x4];
    f32 unk4;
};
struct func_8024BE70_S1;
struct func_8024BE70_S1 {
    char pad0[0x1];
    s8 unk1;
};
struct func_80203908_S2;
typedef struct func_80203908_S2 func_80203908_S2;
struct func_80203B60_S2;
typedef struct func_80203B60_S2 func_80203B60_S2;
struct func_8022FD9C_Record;
typedef struct func_8022FD9C_Record func_8022FD9C_Record;
struct WeaponActionRecord;
struct WeaponActionRecord {
    s16 action;
    char pad2[0x16];
};
struct func_802063EC_S2;
typedef struct func_802063EC_S2 func_802063EC_S2;
struct Owner_func_8020388C_de;
struct Owner_func_8020388C_de {
    char pad[0xE4];
    u16 id;
};
struct func_80232FE8_S1;
typedef struct func_80232FE8_S1 func_80232FE8_S1;
struct func_80203908_S1;
typedef struct func_80203908_S1 func_80203908_S1;
struct AudioState;
struct AudioState {
    char pad0[0x54];
    s32 active;
    char pad58[0x18];
    s32 mode;
};
struct func_8022E3B4_S1;
typedef struct func_8022E3B4_S1 func_8022E3B4_S1;
struct func_80203908_S2;
struct func_80203908_S2 {
    char pad0[0x14];
    char unk14;
};
struct func_8022FD9C_S1;
struct func_8022FD9C_S1 {
    char pad0[0x1];
    s8 unk1;
    char pad1[0x1D8 - 0x1 - sizeof(s8)];
    void * unk1D8;
};
struct func_80203C40_S1;
typedef struct func_80203C40_S1 func_80203C40_S1;
struct func_80203C84_S1;
typedef struct func_80203C84_S1 func_80203C84_S1;
struct func_80203B60_S1;
struct func_80203B60_S1 {
    char pad0[0x18];
    char * unk18;
    char pad18[0x100 - 0x18 - sizeof(char*)];
    s32 unk100;
};
struct func_80203DF0_S3;
struct func_80203DF0_S3 {
    char pad0[0x3C];
    s32 unk3C;
    char pad3C[0x40 - 0x3C - sizeof(s32)];
    s32 unk40;
};
struct func_80203C84_S1;
struct func_80203C84_S1 {
    char pad0[0x34];
    s8 unk34;
};
struct func_80203DF0_S1;
struct func_80203DF0_S1 {
    char pad0[0x4];
    s32 unk4;
    char pad4[0x8 - 0x4 - sizeof(s32)];
    void * unk8;
};
struct func_8022FD9C_S3;
struct func_8022FD9C_S3 {
    char pad0[0x2C];
    s32 unk2C;
    char pad2C[0x120 - 0x2C - sizeof(s32)];
    s32 unk120;
    char pad120[0x124 - 0x120 - sizeof(s32)];
    s32 unk124;
    char pad124[0x128 - 0x124 - sizeof(s32)];
    s32 unk128;
    char pad128[0x130 - 0x128 - sizeof(s32)];
    s32 unk130;
};
struct IntegerState11C4;
struct IntegerState11C4 {
    unsigned char padding_0[4544];
    s32 unk_11C0;
};
struct func_80205494_S2;
struct func_80205494_S2 {
    char pad0[0xCB];
    signed char unkCB;
};
struct func_80232FE8_S3;
typedef struct func_80232FE8_S3 func_80232FE8_S3;
struct func_8022BECC_S1;
typedef struct func_8022BECC_S1 func_8022BECC_S1;
struct func_80232FE8_S3;
struct func_80232FE8_S3 {
    char pad0[0x13C];
    s32 unk13C;
};
struct func_80203AB0_S1;
struct func_80203AB0_S1 {
    char pad0[0xCB];
    char unkCB;
};
struct func_80203DF0_S1;
typedef struct func_80203DF0_S1 func_80203DF0_S1;
struct func_8020A028_S3;
struct func_8020A028_S3 {
    char pad0[0x1D8];
    void * unk1D8;
};
struct func_8022FD9C_S4;
struct func_8022FD9C_S4 {
    char pad0[0x58];
    s32 unk58;
};
struct func_8022C6D4_S1;
typedef struct func_8022C6D4_S1 func_8022C6D4_S1;
struct SettingsE;
typedef struct SettingsE SettingsE;
struct func_8022BECC_S1;
struct func_8022BECC_S1 {
    char pad0[0x62E];
    short unk62E;
};
struct func_80203AB0_S1;
typedef struct func_80203AB0_S1 func_80203AB0_S1;
struct func_80203B60_S3;
typedef struct func_80203B60_S3 func_80203B60_S3;
struct Owner;
struct Owner {
    char pad0[0x18];
    char *track;
};
struct func_80205628_S3;
typedef struct func_80205628_S3 func_80205628_S3;
struct func_8024BE70_S1;
typedef struct func_8024BE70_S1 func_8024BE70_S1;
struct func_80203B60_S3;
struct func_80203B60_S3 {
    char pad0[0x110];
    s32 unk110;
};
struct func_80203B60_S2;
struct func_80203B60_S2 {
    char pad0[0xC];
    s32 unkC;
    char padC[0x10 - 0xC - sizeof(s32)];
    s32 unk10;
};
struct func_8022FD9C_S2;
typedef struct func_8022FD9C_S2 func_8022FD9C_S2;
struct Item_func_8043C9AC_de;
struct Item_func_8043C9AC_de {
    char pad0[0x14];
    s32 x;
    char pad18[8];
    s32 y;
};
struct func_802B67B0_S2;
struct func_802B67B0_S2 {
    char pad0[0xE];
    s16 unkE;
};
struct func_802B67B0_S2;
typedef struct func_802B67B0_S2 func_802B67B0_S2;
struct func_80212828_S2;
struct func_80212828_S2 {
    char pad0[0x1454];
    void * unk1454;
};
struct Pool;
struct Pool {
    s32 count;
    char pad[0x40];
    s32 field44;
};
struct Actor_func_8024A1D0_de;
typedef struct Actor_func_8024A1D0_de Actor_func_8024A1D0_de;
struct Table_func_8028CE94_de;
struct Table_func_8028CE94_de {
    s32 stride;
    s32 count;
    char data[1];
};
struct FftTables;
typedef struct FftTables FftTables;
struct FftTables;
struct FftTables {
    f32 *sines;
    f32 *cosines;
    s32 *order;
    s32 size;
};
struct func_80205314_S2;
struct func_80205314_S2 {
    char pad0[0x2C];
    int unk2C;
};
extern int D_80142CA8;
struct func_8025C598_S1;
typedef struct func_8025C598_S1 func_8025C598_S1;
struct func_8020C9CC_S1;
struct func_8020C9CC_S1 {
    char pad0[0x4];
    u8 unk4;
};
struct ObjectState1E;
struct ObjectState1E {
    unsigned char padding_0[29];
    s8 unk_1D;
};
struct func_8021CD70_S3;
struct func_8021CD70_S3 {
    s32 unk0;
    char pad0[0x10];
    s32 unk14;
};
struct Frame_func_804217D4_de;
struct Frame_func_804217D4_de {
    char a[0x16];
    s16 unk16;
    char b[2];
    s16 unk1A;
};
struct Frame_func_804217D4_de;
struct Menu_func_804241BC_de;
struct Menu_func_804241BC_de {
    char pad[0x44];
    struct Frame_func_804217D4_de *list;
};
struct FieldRow;
struct FieldRow {
    s32 value;
    char pad[8];
};
struct FieldRow;
typedef struct FieldRow FieldRow;
struct Menu_func_8043E494_de;
typedef struct Menu_func_8043E494_de Menu_func_8043E494_de;
struct Clip;
struct Clip {
    s16 mode;
    s16 frames;
};
struct Clip;
typedef struct Clip Clip;
struct Node_func_80285B64_de;
struct Node_func_80285B64_de {
    char pad0[8];
    Clip *key;
    Vec3 position;
    f32 value0;
    f32 value1;
    char pad20[0x18];
    struct Node_func_80285B64_de **owner;
};
struct Element_func_8041200C_de;
struct Element_func_8041200C_de {
    char unk_0[1180];
};
struct func_8029A73C_S1;
typedef struct func_8029A73C_S1 func_8029A73C_S1;
struct Block70;
struct Block70 {
    s32 w[28];
};
struct Block70;
typedef struct Block70 Block70;
struct func_8025E5B0_S1;
struct func_8025E5B0_S1 {
    char pad0[0x14];
    short unk14;
};
struct Entry_func_80441EB0_de;
struct Entry_func_80441EB0_de {
    s16 type;
    char pad[0x22];
};
union func_8020E674_S1_U8;
typedef union func_8020E674_S1_U8 func_8020E674_S1_U8;
union func_8020E674_S1_U8;
union func_8020E674_S1_U8 {
    f32 v0;
    Vec3 v1;
};
struct ALPlayer_s14;
struct ALPlayer_s14 {
    struct ALPlayer_s14 *next;
    void *clientData;
    ALVoiceHandler handler;
    s32 callTime;
    s32 samplesLeft;
};
struct ALPlayer_s14;
typedef struct ALPlayer_s14 ALPlayer_s14;
struct ALEventQueue;
typedef struct ALEventQueue ALEventQueue;
struct Message_func_802AF150_de;
struct Message_func_802AF150_de {
    s16 type;
    char pad[14];
};
struct Link_func_802596B4_de;
struct Link_func_802596B4_de {
    struct Link_func_802596B4_de *next;
    struct Link_func_802596B4_de *prev;
};
struct Link_func_802596B4_de;
typedef struct Link_func_802596B4_de Link_func_802596B4_de;
struct ALEventQueue;
struct ALEventQueue {
    Link_func_802596B4_de freeList;
    Link_func_802596B4_de allocList;
    s32 eventCount;
};
struct Message_func_802AF150_de;
typedef struct Message_func_802AF150_de Message_func_802AF150_de;
struct Node802A697C;
struct Node802A697C {
    u32 unk0;
    f32 value;
};
struct func_802062E0_S2;
struct func_802062E0_S2 {
    char pad0[0x1C];
    Triple unk1C;
};
struct Shape_typemap_6;
struct Shape_typemap_6 {
    int field_0;
    int field_4;
    int field_8;
    int field_C;
};
struct func_8024C5C4_S2;
typedef struct func_8024C5C4_S2 func_8024C5C4_S2;
struct Brain_func_80212D78_eu_x;
struct Brain_func_80212D78_eu_x {
    char pad0[0x220];
    s32 unk220;
    char pad224[0xD8];
    s32 unk2FC;
};
struct Output80216D3C;
struct Output80216D3C {
    s32 type;
    s32 unk4;
    s32 unk8;
    Triple first;
    Triple second;
    s32 unk24;
    Triple third;
    Triple fourth;
    s32 unk40;
};
struct Output80216D3C;
typedef struct Output80216D3C Output80216D3C;
struct func_8022ED94_S1;
typedef struct func_8022ED94_S1 func_8022ED94_S1;
struct Matrix_func_80213CF8_de;
struct Matrix_func_80213CF8_de {
    f32 m[4][4];
};
struct Record_func_80433914_de;
typedef struct Record_func_80433914_de Record_func_80433914_de;
struct Record_func_80433914_de;
struct Record_func_80433914_de {
    union {
        struct {
    u8 name[8];
    s32 time;
    s8 owner;
    s8 player;
    char padE[1];
    u8 slot;
    char pad10[7];
    u8 count;
    char pad18[0x25 - 0x18];
    u8 rank;
    char pad26[0x4A - 0x26];
    u8 achievementFlags[0x189 - 0x4A];
    u8 setting[5];
    char pad18E[0x190 - 0x18E];
        };
        struct { char pad0[0x6C]; s32 wins, kills, deaths; } statistics;
    };
};
struct MenuWidget;
struct MenuWidget {
    char pad0[12];
    s16 resource;
    char padE[2];
    u8 alpha;
    char pad11[3];
    s16 x;
    s16 y;
    s16 width;
    s16 height;
    char pad1C[0x2C - 0x1C];
    s32 value;
    struct MenuWidget *next;
    s32 field34;
    union { void *text; s32 image; s32 word38; };
};
struct MenuWidget;
typedef struct MenuWidget MenuWidget;
struct func_8020CA10_G1;
typedef struct func_8020CA10_G1 func_8020CA10_G1;
struct func_8020CA10_G1;
struct func_8020CA10_G1 {
    f32 unk0;
};
struct func_8020EA10_S1;
typedef struct func_8020EA10_S1 func_8020EA10_S1;
struct ALVoice_s;
typedef struct ALVoice_s ALVoice_s;
struct ALVoice_s;
struct ALVoice_s {
    Link_func_802596B4_de node;
    void *pvoice;
    void *table;
    void *clientPrivate;
    s16 state;
    s16 priority;
    s16 fxBus;
    s16 unityPitch;
};
struct ALSynth_func_802B3000_de;
typedef struct ALSynth_func_802B3000_de ALSynth_func_802B3000_de;
struct func_80275120_S1;
struct func_80275120_S1 {
    float unk0;
    char pad0[0x8 - 0x0 - sizeof(float)];
    float unk8;
    char pad8[0xC - 0x8 - sizeof(float)];
    float unkC;
};
struct Queue_func_802517B4_de;
struct Queue_func_802517B4_de {
    void **head;
    s32 unk04;
    s32 count;
    s32 index;
    s32 capacity;
    void **entries;
};
typedef signed int ( *Handler802A2B50)(void *, signed int, signed int, signed int, signed int);
struct Field_f32_10;
typedef struct Field_f32_10 Field_f32_10;
struct Actor_func_8024A1D0_de;
struct Actor_func_8024A1D0_de {
    u32 pad0[2];
    Vec3 position0;
    u32 pad14[2];
    Vec3 position1;
    u32 pad28[13];
    Vector4f rotation;
};
struct Resource_func_80419E54_de;
struct Resource_func_80419E54_de {
    char pad[0x10];
    unsigned char value;
};
struct Field_s32_2E0;
struct Field_s32_2E0 {
    char pad[0x2E0];
    s32 value;
};
struct Entry802AB8DC;
typedef struct Entry802AB8DC Entry802AB8DC;
struct Entry802AB8DC;
struct Entry802AB8DC {
    s32 offset;
    u8 pad4[4];
};
struct Inner8043E56C;
struct Inner8043E56C {
    u8 pad0[4];
    s8 unk4;
};
struct Inner8043E56C;
struct Outer8043E56C;
struct Outer8043E56C {
    u8 pad0[0x20];
    struct Inner8043E56C *unk20;
};
struct Outer8043E56C;
typedef struct Outer8043E56C Outer8043E56C;
struct func_80254930_S1;
typedef struct func_80254930_S1 func_80254930_S1;
struct Owner_func_8043E1F8_de;
struct Owner_func_8043E1F8_de {
    char pad0[0x85C];
    s32 unk85C;
};
struct ALVoice_s_func_802B3000_de;
typedef struct ALVoice_s_func_802B3000_de ALVoice_s_func_802B3000_de;
struct UnitMtx;
typedef struct UnitMtx UnitMtx;
struct UnitMtx;
struct UnitMtx {
    s32 m[16];
};
struct func_8024C864_S1;
typedef struct func_8024C864_S1 func_8024C864_S1;
struct __OSInode;
typedef struct __OSInode __OSInode;
union __OSInodeUnit;
union __OSInodeUnit {
    struct {
        u8 bank;
        u8 page;
    } inode_t;
    u16 ipage;
};
union __OSInodeUnit;
typedef union __OSInodeUnit __OSInodeUnit;
struct __OSInode;
struct __OSInode {
    __OSInodeUnit inode_page[128];
};
struct TextLayerRect;
typedef struct TextLayerRect TextLayerRect;
struct func_8025E52C_S1;
typedef struct func_8025E52C_S1 func_8025E52C_S1;
struct func_802044C8_S1;
struct func_802044C8_S1 {
    char pad0[0xE4];
    u16 unkE4;
    char padE4[0x100 - 0xE4 - sizeof(u16)];
    s32 unk100;
};
struct Node75;
typedef struct Node75 Node75;
struct func_8020CC0C_S1;
struct func_8020CC0C_S1 {
    char pad0[0x8];
    char unk8;
};
struct ALMIDIEvent;
typedef struct ALMIDIEvent ALMIDIEvent;
struct func_80229BE0_S2;
struct func_80229BE0_S2 {
    char pad0[0x80];
    s8 unk80;
};
struct ResourceManagerState;
struct ResourceManagerState {
    s32 active;
    s32 count;
};
struct Arg1Struct;
typedef struct Arg1Struct Arg1Struct;
struct Arg1Struct;
struct Arg1Struct {
    char pad0[0x1C];
    s32 unk1C;
    char pad1[0x20 - 0x1C - 4];
    s32 unk20;
};
struct func_80206930_S3;
typedef struct func_80206930_S3 func_80206930_S3;
union ObjectLinks4_3;
typedef union ObjectLinks4_3 ObjectLinks4_3;
union ObjectLinks4_3;
union ObjectLinks4_3 {
    void * v0;
    char * v1;
};
struct ObjectStateC_2;
struct ObjectStateC_2 {
    char pad0[0x8];
    ObjectLinks4_3 unk_8;
};
struct ALHeap;
typedef struct ALHeap ALHeap;
struct func_8021846C_S3;
struct func_8021846C_S3 {
    char pad0[0xB0];
    s32 unkB0;
};
struct NodeEvent;
struct NodeEvent {
    s32 words[10];
};
struct Resource_func_80419E54_de;
typedef struct Resource_func_80419E54_de Resource_func_80419E54_de;
struct Shape_func_802764D4_de_2;
struct Shape_func_802764D4_de_2 {
    int field_0;
    int field_4;
};
struct func_80228774_S7;
struct func_80228774_S7 {
    char pad0[0x130];
    f32 unk130;
};
union func_802626BC_S1_U10;
union func_802626BC_S1_U10 {
    s32 v0;
    void * v1;
};
union func_802626BC_S1_U10;
typedef union func_802626BC_S1_U10 func_802626BC_S1_U10;
struct Handler;
struct Handler {
    char pad0[4];
    s16 id;
    char pad6[6];
    union {
        s32 (*targeted)(void *actor, struct Handler *entry, s32 target);
        s32 (*plain)(void *actor, struct Handler *entry);
    } handleC;
    s32 (*handle10)(void *actor, struct Handler *entry);
    s32 (*handle14)(void *actor, struct Handler *entry);
};
struct Shape_typemap_110;
struct Shape_typemap_110 {
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
};
struct func_80258BB4_S1;
struct func_80258BB4_S1 {
    char pad0[0x2BA4];
    float unk2BA4;
};
struct ALFilter_s14;
typedef struct ALFilter_s14 ALFilter_s14;
struct ALFilter_s14;
struct ALFilter_s14 {
    struct ALFilter_s14 *source;
    void *handler;
    void *setParam;
    s16 inp;
    s16 outp;
    s32 type;
};
struct func_8025BD20_S1;
struct func_8025BD20_S1 {
    char pad0[0x4];
    char unk4;
};
extern int D_801005A8;
struct Key;
struct Key {
    char pad0[0x14];
};
struct Key;
struct Owner_func_8041AD10_de;
struct Owner_func_8041AD10_de {
    char pad[0x38];
    struct Key *selected;
};
struct OSPfs_func_80445F80_de;
typedef struct OSPfs_func_80445F80_de OSPfs_func_80445F80_de;
struct Entry_func_8023B9C0_eu;
struct Entry_func_8023B9C0_eu {
    u16 id;
    u8 team;
    u8 slot;
};
struct Entry_func_8023B9C0_eu;
typedef struct Entry_func_8023B9C0_eu Entry_func_8023B9C0_eu;
struct Shape_typemap_21;
struct Shape_typemap_21 {
    unsigned char padding_0[16];
    unsigned char field_10;
};
struct Profile_func_80229554_de;
struct Profile_func_80229554_de {
    char pad0[0x14];
    u8 bonus2;
    u8 bonus0;
    u8 bonus1;
    char pad17[0x190 - 0x17];
};
struct func_80212828_S2;
typedef struct func_80212828_S2 func_80212828_S2;
struct func_8029A73C_S1;
struct func_8029A73C_S1 {
    char pad0[0x520];
    int unk520;
};
struct Field_u16_14;
struct Field_u16_14 {
    char pad[0x14];
    u16 value;
};
struct func_8028469C_S2;
struct func_8028469C_S2 {
    char pad0[0x38];
    void * unk38;
};
struct Block24;
typedef struct Block24 Block24;
struct func_8028B3C0_S1;
typedef struct func_8028B3C0_S1 func_8028B3C0_S1;
struct Plane_func_802965B0_de;
struct Plane_func_802965B0_de {
    Vec3 normal;
    f32 distance;
};
struct Plane_func_802965B0_de;
typedef struct Plane_func_802965B0_de Plane_func_802965B0_de;
struct Extra;
struct Extra {
    s32 id;
    f32 scale;
};
struct Block;
struct Block {
    u8 pad000[0x100];
    s32 flags;
    u8 pad104[0x1DC];
    s32 value;
};
struct Block;
typedef struct Block Block;
struct func_80250BD4_S1;
struct func_80250BD4_S1 {
    char pad0[0x20];
    s32 * unk20;
};
struct Vec3Words;
struct Vec3Words {
    s32 w[3];
};
struct func_8022D418_S1;
struct func_8022D418_S1 {
    char pad0[0x658];
    f32 unk658;
    char pad658[0x664 - 0x658 - sizeof(f32)];
    s32 unk664;
    char pad664[0x72C - 0x664 - sizeof(s32)];
    f32 unk72C;
    char pad72C[0x850 - 0x72C - sizeof(f32)];
    s32 unk850;
};
struct func_80293268_S2;
typedef struct func_80293268_S2 func_80293268_S2;
struct func_80207B5C_S2;
typedef struct func_80207B5C_S2 func_80207B5C_S2;
extern int D_8010115C;
struct Player_func_804356BC_de;
struct Player_func_804356BC_de {
    char pad0[0x18];
    char slots[4][400];
    char pad658[0xB68 - 0x658];
};
struct StateFlags;
typedef struct StateFlags StateFlags;
struct StateFlags;
struct StateFlags {
    u16 value;
    u16 flags;
};
struct func_8024C864_S1;
struct func_8024C864_S1 {
    f32 unk0;
    char pad0[0x4 - 0x0 - sizeof(f32)];
    f32 unk4;
    char pad4[0x8 - 0x4 - sizeof(f32)];
    f32 unk8;
};
struct Queue_func_802517B4_de;
typedef struct Queue_func_802517B4_de Queue_func_802517B4_de;
struct Desc;
struct Desc {
    char pad[0x108];
    s32 caps[4];
};
struct Owner_func_804441F4_de;
struct Owner_func_804441F4_de {
    char pad[0x5D8];
    char *name;
};
struct func_8025CA44_S1;
typedef struct func_8025CA44_S1 func_8025CA44_S1;
struct func_802B4ECC_S1;
typedef struct func_802B4ECC_S1 func_802B4ECC_S1;
struct func_80207BB8_S4;
typedef struct func_80207BB8_S4 func_80207BB8_S4;
struct func_8022BC04_S3;
typedef struct func_8022BC04_S3 func_8022BC04_S3;
struct Rec_func_8024C92C_de;
typedef struct Rec_func_8024C92C_de Rec_func_8024C92C_de;
struct Rec_func_8024C92C_de;
struct Rec_func_8024C92C_de {
    s32 x;
    s32 y;
    s32 z;
    s32 pad0;
    s32 pad1;
};
struct func_80204468_S2;
struct func_80204468_S2 {
    char pad0[0x18];
    void * unk18;
    char pad18[0x100 - 0x18 - sizeof(void*)];
    int unk100;
};
struct State_func_804232AC_de;
struct State_func_804232AC_de {
    void *menu;
    char pad4[0x20 - 4];
    s32 value;
};
struct HudStatusShared_MatchRules;
typedef struct HudStatusShared_MatchRules HudStatusShared_MatchRules;
struct func_8022CA04_S3;
struct func_8022CA04_S3 {
    char pad0[0x20];
    f32 unk20;
};
struct Params_func_802B2F10_de;
typedef struct Params_func_802B2F10_de Params_func_802B2F10_de;
struct Node75;
struct Node75 {
    s32 pad0;
    Vec3 *prev;
    Vec3 *cur;
    Vec3 *next;
};
struct Field_s32_2E0;
typedef struct Field_s32_2E0 Field_s32_2E0;
extern int D_8014287C;
struct func_8028DA50_S1;
struct func_8028DA50_S1 {
    char pad0[0x14];
    s32 unk14;
    char pad14[0x18 - 0x14 - sizeof(s32)];
    s32 unk18;
};
struct InventorySlot;
struct InventorySlot {
    u8 available;
    u8 slot;
};
struct InventorySlot;
typedef struct InventorySlot InventorySlot;
struct func_8024DED0_S2;
typedef struct func_8024DED0_S2 func_8024DED0_S2;
struct func_8024DED0_S2;
struct func_8024DED0_S2 {
    char pad0[0x4C];
    int unk4C;
};
struct Obj_func_80297DBC_de;
typedef struct Obj_func_80297DBC_de Obj_func_80297DBC_de;
struct func_80242278_S2;
struct func_80242278_S2 {
    char pad0[0x8];
    u8 unk8;
};
struct func_8023945C_S1;
struct func_8023945C_S1 {
    char pad0[0x128];
    Vec3 unk128;
};
struct func_80272848_S1;
struct func_80272848_S1 {
    f32 unk0;
    char pad0[0x4 - 0x0 - sizeof(f32)];
    f32 unk4;
    char pad4[0x8 - 0x4 - sizeof(f32)];
    f32 unk8;
    char pad8[0xC - 0x8 - sizeof(f32)];
    f32 unkC;
    char padC[0x10 - 0xC - sizeof(f32)];
    f32 unk10;
    char pad10[0x14 - 0x10 - sizeof(f32)];
    f32 unk14;
    char pad14[0x18 - 0x14 - sizeof(f32)];
    f32 unk18;
    char pad18[0x1C - 0x18 - sizeof(f32)];
    f32 unk1C;
    char pad1C[0x20 - 0x1C - sizeof(f32)];
    f32 unk20;
    char pad20[0x24 - 0x20 - sizeof(f32)];
    f32 unk24;
    char pad24[0x28 - 0x24 - sizeof(f32)];
    f32 unk28;
    char pad28[0x2C - 0x28 - sizeof(f32)];
    f32 unk2C;
    char pad2C[0x30 - 0x2C - sizeof(f32)];
    f32 unk30;
    char pad30[0x34 - 0x30 - sizeof(f32)];
    f32 unk34;
    char pad34[0x38 - 0x34 - sizeof(f32)];
    f32 unk38;
    char pad38[0x3C - 0x38 - sizeof(f32)];
    f32 unk3C;
};
struct ListScreenRecord;
typedef struct ListScreenRecord ListScreenRecord;
struct ListScreenRecord;
struct ListScreenRecord {
    char pad0[0x78];
    u8 active;
    char pad79[0x18];
    u8 out;
    char pad92[0x4];
};
struct Pool;
typedef struct Pool Pool;
struct func_80254D70_S1;
typedef struct func_80254D70_S1 func_80254D70_S1;
struct func_80204EA8_S1;
struct func_80204EA8_S1 {
    char pad0[0x8];
    Triple unk8;
};
extern int D_80137064;
struct func_802A68A0_S3;
typedef struct func_802A68A0_S3 func_802A68A0_S3;
extern float D_8010AC7C;
struct func_80258D60_S1;
struct func_80258D60_S1 {
    char pad0[0x84];
    char unk84;
};
struct func_80239CD0_S1;
struct func_80239CD0_S1 {
    char pad0[0x14];
    int unk14;
    char pad14[0x1C - 0x14 - sizeof(int)];
    int unk1C;
};
struct ObjectState14;
struct ObjectState14 {
    char pad0[0xC];
    s16 unk_C;
    char padC[0xE - 0xC - sizeof(s16)];
    s16 unk_E;
    char padE[0x10 - 0xE - sizeof(s16)];
    s16 unk_10;
    char pad10[0x12 - 0x10 - sizeof(s16)];
    s16 unk_12;
};
struct func_8020CA10_S2;
struct func_8020CA10_S2 {
    char pad0[0xC];
    u16 unkC;
};
struct ALEvent_func_802B21A8_de;
struct ALEvent_func_802B21A8_de {
    s16 type;
    union {
        struct {
            s32 ticks;
            u8 status;
            u8 byte1;
            u8 byte2;
            u32 duration;
        } midi;
    } msg;
};
struct Object6C;
struct Object6C {
    char pad[0x6C];
    s32 value;
};
struct func_8021CD70_S4;
struct func_8021CD70_S4 {
    char pad0[0x564];
    s32 unk564;
};
struct Body;
struct Character;
struct Controller;
struct Controls;
struct Ctrl;
struct Held;
struct Mode;
struct Model;
struct Mount;
struct Profile;
struct Record;
struct Rider;
struct Settings;
struct SharedPlayer_func_80226A34_de;
struct Shared_Body;
struct Shared_Hud;
struct Shared_Model;
struct Shared_Profile;
struct Shared_StateInfo;
struct Shared_Voice;
struct StateInfo;
struct TeamInfo;
struct func_8021CD70_S4;
struct SharedPlayer_func_80226A34_de {
    union {
        struct {
            u8 unk0[24];
        } view0_0;
        struct {
            u8 pad0[24];
        } view0_1;
        struct {
            char pad[0x3];
            u8 team;
        } view3_2;
        struct {
            char pad[0x8];
            Vec3 unk8;
        } view8_2;
        struct {
            char pad[0x8];
            Vec3 pos;
        } view8_3;
        struct {
            char pad[0x8];
            Vec3 position;
        } view8_4;
        struct {
            char pad[0x14];
            struct Shared_Model * model;
        } view14_6;
        struct { char pad[8]; s32 positionWords[3]; } positionBits;
    } views0;
    union {
        struct {
            char * unk18;
        } view18_0;
        struct {
            char * track;
        } view18_1;
        struct {
            struct Model * model;
        } view18_2;
        struct {
            struct Body * body;
        } view18_3;
        struct {
            struct Character * character;
        } view18_4;
        struct {
            struct Shared_Body * body;
        } view18_5;
    } views18;
    union {
        struct {
            u8 unk1C[344];
        } view1C_0;
        struct {
            u8 pad1[344];
        } view1C_1;
        struct {
            char pad[0x4];
            f32 velY;
        } view20_2;
        struct {
            char pad[0x1C];
            s32 unk38;
        } view38_2;
        struct {
            char pad[0x1C];
            s32 flags;
        } view38_3;
        struct {
            char pad[0x24];
            f32 unk40;
        } view40_5;
        struct {
            char pad[0x40];
            Shared_Quad unk5C;
        } view5C_6;
        struct {
            char pad[0x50];
            f32 unk6C;
        } view6C_4;
        struct {
            char pad[0x50];
            f32 heading;
        } view6C_5;
        struct {
            char pad[0x50];
            f32 yaw;
        } view6C_9;
        struct {
            char pad[0xC8];
            u16 unkE4;
        } viewE4_6;
        struct {
            char pad[0xC8];
            u16 kind;
        } viewE4_7;
        struct {
            char pad[0xE4];
            s32 unk100;
        } view100_8;
        struct {
            char pad[0xE4];
            s32 flags;
        } view100_9;
        struct {
            char pad[0xE8];
            f32 unk104;
        } view104_10;
        struct {
            char pad[0xE8];
            f32 idleTime;
        } view104_11;
        struct {
            char pad[0xEC];
            s16 anim;
        } view108_16;
        struct {
            char pad[0xF2];
            s8 unk10E;
        } view10E_12;
        struct {
            char pad[0xF2];
            s8 idle;
        } view10E_13;
        struct {
            char pad[0xF2];
            s8 replaying;
        } view10E_14;
        struct {
            char pad[0xF2];
            s8 animPending;
        } view10E_20;
        struct {
            char pad[0x154];
            char unk170[100];
        } view170_15;
        struct {
            char pad[0x154];
            char body[100];
        } view170_16;
        struct {
            char pad[0x154];
            s32 unk170;
        } view170_23;
        struct {
            char pad[0x158];
            s32 unk174;
        } view174_17;
        struct {
            char pad[0x15C];
            u8 unk178[740];
        } view178_18;
        struct {
            char pad[0x15C];
            u8 pad2[740];
        } view178_19;
        struct {
            char pad[0x1B8];
            f32 unk1D4;
        } view1D4_20;
        struct {
            char pad[0x1B8];
            f32 holdTime;
        } view1D4_21;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80226A34_de * unk1D8;
        } view1D8_22;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80226A34_de * self;
        } view1D8_23;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80226A34_de * f1D8;
        } view1D8_24;
        struct {
            char pad[0x1BC];
            void * unk1D8;
        } view1D8_32;
        struct {
            char pad[0x244];
            Vec3 unk260;
        } view260_25;
        struct {
            char pad[0x244];
            Vec3 muzzle;
        } view260_26;
        struct {
            char pad[0x2CC];
            char unk2E8[368];
        } view2E8_27;
        struct {
            char pad[0x2CC];
            char weapon[368];
        } view2E8_28;
        struct {
            char pad[0x2CC];
            Shared_Emitter emitter;
        } view2E8_37;
        struct {
            char pad[0x43C];
            char unk458[384];
        } view458_29;
        struct {
            char pad[0x43C];
            char ammo[384];
        } view458_30;
        struct {
            char pad[0x43C];
            s32 unk458;
        } view458_40;
        struct {
            char pad[0x440];
            s32 unk45C;
        } view45C_31;
        struct {
            char pad[0x444];
            u8 unk460[376];
        } view460_32;
        struct {
            char pad[0x444];
            u8 pad3[376];
        } view460_33;
        struct {
            char pad[0x468];
            struct Shared_Voice * voice;
        } view484_44;
        struct {
            char pad[0x470];
            s8 unk48C;
        } view48C_34;
        struct {
            char pad[0x470];
            s8 state;
        } view48C_35;
        struct {
            char pad[0x4A4];
            void * unk4C0;
        } view4C0_47;
        struct {
            char pad[0x507];
            s8 unk523;
        } view523_36;
        struct {
            char pad[0x507];
            s8 busy;
        } view523_37;
        struct {
            char pad[0x578];
            s32 unk594;
        } view594_38;
        struct {
            char pad[0x578];
            s32 gear;
        } view594_39;
        struct {
            char pad[0x578];
            s32 mode;
        } view594_40;
        struct {
            char pad[0x584];
            f32 unk5A0;
        } view5A0_41;
        struct {
            char pad[0x584];
            f32 charge;
        } view5A0_42;
        struct {
            char pad[0x5B4];
            s32 unk5D0;
        } view5D0_43;
        struct {
            char pad[0x5B4];
            s32 f5D0;
        } view5D0_44;
        struct {
            char pad[0x5B8];
            s32 unk5D4;
        } view5D4_45;
        struct {
            char pad[0x5B8];
            s32 slot;
        } view5D4_46;
        struct {
            char pad[0x5B8];
            s32 profile;
        } view5D4_47;
        struct {
            char pad[0x5B8];
            s32 f5D4;
        } view5D4_48;
    } views1C;
    union {
        struct {
            struct Record * unk5D8;
        } view5D8_0;
        struct {
            struct Record * record;
        } view5D8_1;
        struct {
            struct Controls * controls;
        } view5D8_2;
        struct {
            struct TeamInfo * teamInfo;
        } view5D8_3;
        struct {
            struct Ctrl * ctrl;
        } view5D8_4;
        struct {
            unsigned char * info;
        } view5D8_5;
        struct {
            struct Profile * profile;
        } view5D8_6;
        struct {
            struct Settings * settings;
        } view5D8_7;
        struct {
            s32 f5D8;
        } view5D8_8;
        struct {
            struct Shared_Profile * profile;
        } view5D8_9;
    } views5D8;
    union {
        struct {
            void * unk5DC;
        } view5DC_0;
        struct {
            void * view;
        } view5DC_1;
        struct {
            struct func_8021CD70_S4 * view;
        } view5DC_2;
        struct {
            u8 pad4[8];
        } view5DC_3;
        struct {
            void * entity;
        } view5DC_4;
        struct {
            struct Rider * rider;
        } view5DC_5;
        struct {
            char * storage;
        } view5DC_6;
        struct {
            char * messages;
        } view5DC_7;
        struct {
            struct Shared_Hud * hud;
        } view5DC_8;
        struct {
            char pad[0x4];
            s32 unk5E0;
        } view5E0_8;
        struct {
            char pad[0x4];
            s32 state;
        } view5E0_9;
        struct {
            char pad[0x4];
            s32 slot;
        } view5E0_10;
    } views5DC;
    union {
        struct {
            s32 unk5E4;
        } view5E4_0;
        struct {
            s32 active;
        } view5E4_1;
        struct {
            s32 health;
        } view5E4_2;
        struct {
            s32 alive;
        } view5E4_3;
        struct {
            s32 holding;
        } view5E4_4;
    } views5E4;
    union {
        struct {
            u8 unk5E8[3140];
        } view5E8_0;
        struct {
            u8 pad5[3140];
        } view5E8_1;
        struct {
            char pad[0x2];
            s16 unk5EA;
        } view5EA_2;
        struct {
            char pad[0x2];
            s16 respawns;
        } view5EA_3;
        struct {
            char pad[0x2];
            s16 runType;
        } view5EA_4;
        struct {
            char pad[0x4];
            s32 unk5EC;
        } view5EC_5;
        struct {
            char pad[0x4];
            s32 model;
        } view5EC_6;
        struct {
            char pad[0x4];
            s32 spawnPoint;
        } view5EC_7;
        struct {
            char pad[0x4];
            s32 f5EC;
        } view5EC_8;
        struct {
            char pad[0x8];
            s32 unk5F0;
        } view5F0_9;
        struct {
            char pad[0x8];
            s32 f5F0;
        } view5F0_10;
        struct {
            char pad[0xC];
            s16 unk5F4[4];
        } view5F4_11;
        struct {
            char pad[0xC];
            s16 ammo[4];
        } view5F4_12;
        struct {
            char pad[0xC];
            s16 ammo[3];
        } view5F4_13;
        struct {
            char pad[0x1A];
            Shared_Slot slots[22];
        } view602_14;
        struct {
            char pad[0x46];
            s16 unk62E;
        } view62E_13;
        struct {
            char pad[0x46];
            s16 weapon;
        } view62E_14;
        struct {
            char pad[0x46];
            s16 character;
        } view62E_17;
        struct {
            char pad[0x68];
            s16 unk650;
        } view650_15;
        struct {
            char pad[0x68];
            s16 state;
        } view650_16;
        struct {
            char pad[0x68];
            s16 action;
        } view650_17;
        struct {
            char pad[0x68];
            s16 mode;
        } view650_18;
        struct {
            char pad[0x6A];
            s16 unk652;
        } view652_19;
        struct {
            char pad[0x6A];
            s16 previous;
        } view652_20;
        struct {
            char pad[0x6A];
            s16 pad652;
        } view652_24;
        struct {
            char pad[0x6C];
            s16 prevState;
        } view654_25;
        struct {
            char pad[0x6E];
            s16 pad656;
        } view656_26;
        struct {
            char pad[0x70];
            f32 unk658;
        } view658_21;
        struct {
            char pad[0x70];
            f32 counter;
        } view658_22;
        struct {
            char pad[0x70];
            f32 stride;
        } view658_23;
        struct {
            char pad[0x70];
            f32 swimTime;
        } view658_24;
        struct {
            char pad[0x70];
            f32 stateTime;
        } view658_31;
        struct {
            char pad[0x74];
            s32 unk65C;
        } view65C_32;
        struct {
            char pad[0x78];
            s32 unk660;
        } view660_25;
        struct {
            char pad[0x78];
            s32 previousTimer;
        } view660_26;
        struct {
            char pad[0x7C];
            s32 unk664;
        } view664_27;
        struct {
            char pad[0x7C];
            s32 timer;
        } view664_28;
        struct {
            char pad[0x84];
            f32 unk66C;
        } view66C_29;
        struct {
            char pad[0x88];
            f32 unk670;
        } view670_30;
        struct {
            char pad[0x88];
            f32 shield;
        } view670_31;
        struct {
            char pad[0x90];
            f32 unk678;
        } view678_40;
        struct {
            char pad[0xA0];
            char unk688[16];
        } view688_32;
        struct {
            char pad[0xA0];
            char body[16];
        } view688_33;
        struct {
            char pad[0xA0];
            Shared_Input input;
        } view688_43;
        struct {
            char pad[0xB0];
            struct Controller * unk698;
        } view698_34;
        struct {
            char pad[0xB0];
            struct Controller * controller;
        } view698_35;
        struct {
            char pad[0xB0];
            void * controller;
        } view698_36;
        struct {
            char pad[0xB0];
            char * emitter;
        } view698_37;
        struct {
            char pad[0xB0];
            char * title;
        } view698_38;
        struct {
            char pad[0xB4];
            f32 unk69C;
        } view69C_39;
        struct {
            char pad[0xB4];
            f32 stick;
        } view69C_40;
        struct {
            char pad[0xBC];
            f32 unk6A4;
        } view6A4_41;
        struct {
            char pad[0xBC];
            f32 strafe;
        } view6A4_42;
        struct {
            char pad[0xC0];
            f32 unk6A8;
        } view6A8_43;
        struct {
            char pad[0xC0];
            f32 lift;
        } view6A8_44;
        struct {
            char pad[0xC4];
            s32 unk6AC;
        } view6AC_45;
        struct {
            char pad[0xC8];
            s32 unk6B0;
        } view6B0_46;
        struct {
            char pad[0xC8];
            s32 input;
        } view6B0_47;
        struct {
            char pad[0xC8];
            s32 state;
        } view6B0_48;
        struct {
            char pad[0xD0];
            s32 unk6B8;
        } view6B8_49;
        struct {
            char pad[0xD0];
            s32 input;
        } view6B8_50;
        struct {
            char pad[0xD8];
            f32 unk6C0;
        } view6C0_51;
        struct {
            char pad[0xD8];
            f32 climb;
        } view6C0_52;
        struct {
            char pad[0xD8];
            f32 speed;
        } view6C0_53;
        struct {
            char pad[0xD8];
            f32 velX;
        } view6C0_64;
        struct {
            char pad[0xDC];
            f32 unk6C4;
        } view6C4_54;
        struct {
            char pad[0xDC];
            f32 side;
        } view6C4_55;
        struct {
            char pad[0xDC];
            f32 velZ;
        } view6C4_67;
        struct {
            char pad[0xE0];
            f32 unk6C8;
        } view6C8_56;
        struct {
            char pad[0xE0];
            f32 speed;
        } view6C8_57;
        struct {
            char pad[0xE4];
            f32 lastVelY;
        } view6CC_70;
        struct {
            char pad[0xE8];
            s32 onGround;
        } view6D0_71;
        struct {
            char pad[0xEC];
            f32 unk6D4;
        } view6D4_58;
        struct {
            char pad[0xF0];
            f32 unk6D8;
        } view6D8_59;
        struct {
            char pad[0xF4];
            f32 unk6DC;
        } view6DC_60;
        struct {
            char pad[0xFC];
            f32 unk6E4;
        } view6E4_61;
        struct {
            char pad[0xFC];
            f32 depth;
        } view6E4_62;
        struct {
            char pad[0xFC];
            f32 airTime;
        } view6E4_77;
        struct {
            char pad[0x100];
            f32 unk6E8;
        } view6E8_63;
        struct {
            char pad[0x100];
            Vec3 unk6E8;
        } view6E8_79;
        struct {
            char pad[0x104];
            f32 unk6EC;
        } view6EC_64;
        struct {
            char pad[0x104];
            f32 height;
        } view6EC_65;
        struct {
            char pad[0x108];
            f32 unk6F0;
        } view6F0_66;
        struct {
            char pad[0x10C];
            f32 unk6F4;
        } view6F4_83;
        struct {
            char pad[0x110];
            Vec3 unk6F8;
        } view6F8_84;
        struct {
            char pad[0x11C];
            f32 unk704;
        } view704_67;
        struct {
            char pad[0x11C];
            f32 lift;
        } view704_68;
        struct {
            char pad[0x130];
            f32 unk718;
        } view718_69;
        struct {
            char pad[0x130];
            f32 crouch;
        } view718_70;
        struct {
            char pad[0x134];
            s32 unk71C;
        } view71C_89;
        struct {
            char pad[0x138];
            f32 swim;
        } view720_90;
        struct {
            char pad[0x13C];
            f32 unk724;
        } view724_71;
        struct {
            char pad[0x13C];
            f32 pitch;
        } view724_72;
        struct {
            char pad[0x140];
            f32 unk728;
        } view728_73;
        struct {
            char pad[0x140];
            f32 kickPitch;
        } view728_74;
        struct {
            char pad[0x144];
            f32 unk72C;
        } view72C_75;
        struct {
            char pad[0x144];
            f32 kickRoll;
        } view72C_76;
        struct {
            char pad[0x144];
            f32 lean;
        } view72C_77;
        struct {
            char pad[0x148];
            f32 unk730[3];
        } view730_78;
        struct {
            char pad[0x148];
            f32 sway[3];
        } view730_79;
        struct {
            char pad[0x154];
            f32 unk73C;
        } view73C_80;
        struct {
            char pad[0x154];
            f32 side;
        } view73C_81;
        struct {
            char pad[0x154];
            Vec3 weapon;
        } view73C_82;
        struct {
            char pad[0x158];
            f32 unk740;
        } view740_83;
        struct {
            char pad[0x158];
            f32 height;
        } view740_84;
        struct {
            char pad[0x15C];
            f32 unk744;
        } view744_85;
        struct {
            char pad[0x15C];
            f32 forward;
        } view744_86;
        struct {
            char pad[0x170];
            f32 unk758;
        } view758_87;
        struct {
            char pad[0x170];
            f32 bobStrength;
        } view758_88;
        struct {
            char pad[0x174];
            f32 unk75C;
        } view75C_89;
        struct {
            char pad[0x174];
            f32 bobSpeed;
        } view75C_90;
        struct {
            char pad[0x188];
            s16 unk770;
        } view770_91;
        struct {
            char pad[0x188];
            s16 nextWeapon;
        } view770_92;
        struct {
            char pad[0x188];
            s16 weapon;
        } view770_113;
        struct {
            char pad[0x18A];
            s16 pad772;
        } view772_114;
        struct {
            char pad[0x18C];
            Vec3 unk774;
        } view774_115;
        struct {
            char pad[0x198];
            f32 unk780;
        } view780_116;
        struct {
            char pad[0x19C];
            f32 unk784;
        } view784_117;
        struct {
            char pad[0x1A0];
            s32 unk788;
        } view788_93;
        struct {
            char pad[0x1A0];
            s32 icons;
        } view788_94;
        struct {
            char pad[0x1B0];
            s32 unk798;
        } view798_95;
        struct {
            char pad[0x1B0];
            s32 carried;
        } view798_96;
        struct {
            char pad[0x1B4];
            Vec3 unk79C;
        } view79C_97;
        struct {
            char pad[0x1B4];
            Vec3 carriedPosition;
        } view79C_98;
        struct {
            char pad[0x1D0];
            s32 unk7B8;
        } view7B8_99;
        struct {
            char pad[0x1D0];
            s32 target;
        } view7B8_100;
        struct {
            char pad[0x1D4];
            f32 unk7BC;
        } view7BC_101;
        struct {
            char pad[0x1D4];
            f32 timer;
        } view7BC_102;
        struct {
            char pad[0x1D8];
            Vec3 unk7C0;
        } view7C0_103;
        struct {
            char pad[0x1D8];
            Vec3 targetPosition;
        } view7C0_104;
        struct {
            char pad[0x200];
            s32 unk7E8;
        } view7E8_105;
        struct {
            char pad[0x200];
            s32 zoomed;
        } view7E8_106;
        struct {
            char pad[0x204];
            f32 unk7EC;
        } view7EC_132;
        struct {
            char pad[0x208];
            f32 unk7F0;
        } view7F0_133;
        struct {
            char pad[0x224];
            struct Mount * unk80C;
        } view80C_107;
        struct {
            char pad[0x224];
            struct Mount * mount;
        } view80C_108;
        struct {
            char pad[0x228];
            s32 unk810;
        } view810_109;
        struct {
            char pad[0x228];
            s32 kind;
        } view810_110;
        struct {
            char pad[0x22C];
            Triple unk814;
        } view814_111;
        struct {
            char pad[0x22C];
            Triple offset;
        } view814_112;
        struct {
            char pad[0x250];
            f32 unk838;
        } view838_113;
        struct {
            char pad[0x250];
            f32 rideTime;
        } view838_114;
        struct {
            char pad[0x254];
            f32 unk83C;
        } view83C_115;
        struct {
            char pad[0x254];
            f32 bump;
        } view83C_116;
        struct {
            char pad[0x258];
            s32 unk840;
        } view840_117;
        struct {
            char pad[0x258];
            s32 surfaced;
        } view840_118;
        struct {
            char pad[0x264];
            s32 unk84C;
        } view84C_149;
        struct {
            char pad[0x26C];
            f32 unk854;
        } view854_147;
        struct {
            char pad[0x274];
            s32 unk85C;
        } view85C_119;
        struct {
            char pad[0x274];
            s32 w85C;
        } view85C_120;
        struct {
            char pad[0x27C];
            s32 unk864;
        } view864_121;
        struct {
            char pad[0x27C];
            s32 f864;
        } view864_122;
        struct {
            char pad[0x280];
            s32 unk868;
        } view868_123;
        struct {
            char pad[0x280];
            s32 f868;
        } view868_124;
        struct {
            char pad[0x284];
            s32 unk86C;
        } view86C_125;
        struct {
            char pad[0x284];
            s32 parameter;
        } view86C_126;
        struct {
            char pad[0x284];
            s32 animation;
        } view86C_127;
        struct {
            char pad[0x288];
            s32 unk870;
        } view870_157;
        struct {
            char pad[0x290];
            Shared_Effect effect;
        } view878_158;
        struct {
            char pad[0x350];
            char unk938[2188];
        } view938_128;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_129;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_130;
        struct {
            char pad[0x350];
            s32 unk938;
        } view938_162;
        struct {
            char pad[0x6D0];
            s32 unkCB8;
        } viewCB8_163;
        struct {
            char pad[0x6E4];
            s32 unkCCC;
        } viewCCC_164;
        struct {
            char pad[0x758];
            s32 unkD40;
        } viewD40_165;
        struct {
            char pad[0x96C];
            s32 unkF54;
        } viewF54_131;
        struct {
            char pad[0x96C];
            s32 selection;
        } viewF54_132;
        struct {
            char pad[0x9A8];
            s32 unkF90;
        } viewF90_133;
        struct {
            char pad[0x9A8];
            s32 choice;
        } viewF90_134;
        struct {
            char pad[0xBCC];
            s32 unk11B4;
        } view11B4_135;
        struct {
            char pad[0xBCC];
            s32 locked;
        } view11B4_136;
        struct {
            char pad[0xBD0];
            s32 unk11B8;
        } view11B8_137;
        struct {
            char pad[0xBD0];
            s32 frozen;
        } view11B8_138;
        struct {
            char pad[0xBD4];
            s32 unk11BC;
        } view11BC_139;
        struct {
            char pad[0xBD4];
            s32 f11BC;
        } view11BC_140;
        struct {
            char pad[0xBD8];
            s32 unk11C0;
        } view11C0_141;
        struct {
            char pad[0xBD8];
            s32 f11C0;
        } view11C0_142;
        struct {
            char pad[0xBDC];
            f32 unk11C4;
        } view11C4_143;
        struct {
            char pad[0xBDC];
            f32 soundTime;
        } view11C4_144;
        struct {
            char pad[0xBE4];
            s32 unk11CC;
        } view11CC_145;
        struct {
            char pad[0xBE4];
            s32 f11CC;
        } view11CC_146;
        struct {
            char pad[0xBF0];
            f32 unk11D8;
        } view11D8_147;
        struct {
            char pad[0xBF0];
            f32 recoil;
        } view11D8_148;
        struct {
            char pad[0xBF0];
            f32 stun;
        } view11D8_149;
        struct {
            char pad[0xBF4];
            f32 unk11DC;
        } view11DC_185;
        struct {
            char pad[0xBF8];
            f32 unk11E0;
        } view11E0_186;
        struct {
            char pad[0xC00];
            s32 unk11E8;
        } view11E8_150;
        struct {
            char pad[0xC00];
            s32 f11E8;
        } view11E8_151;
        struct {
            char pad[0xC04];
            f32 unk11EC;
        } view11EC_189;
        struct {
            char pad[0xC28];
            s32 unk1210;
        } view1210_152;
        struct {
            char pad[0xC28];
            s32 marker;
        } view1210_153;
        struct {
            char pad[0xC2C];
            s32 unk1214;
        } view1214_154;
        struct {
            char pad[0xC2C];
            s32 marker;
        } view1214_155;
        struct {
            char pad[0xC2C];
            s32 markerShown;
        } view1214_156;
        struct {
            char pad[0xC30];
            s32 unk1218;
        } view1218_157;
        struct {
            char pad[0xC30];
            s32 f1218;
        } view1218_158;
        struct {
            char pad[0xC34];
            s32 unk121C;
        } view121C_159;
        struct {
            char pad[0xC34];
            s32 f121C;
        } view121C_160;
        struct {
            char pad[0xC38];
            s32 unk1220;
        } view1220_161;
        struct {
            char pad[0xC38];
            s32 f1220;
        } view1220_162;
        struct { char pad[0xE]; s16 charge; } chargeView;
        struct { char pad[0x11F4 - 0x5E8]; f32 spin; s32 frame; } rapidFireView;
    } views5E8;
    union {
        struct {
            u32 unk122C;
        } view122C_0;
        struct {
            u32 flags;
        } view122C_1;
        struct {
            s32 options;
        } view122C_2;
        struct {
            s32 f122C;
        } view122C_3;
        struct {
            s32 fxFlags;
        } view122C_4;
    } views122C;
    f32 fxTime;
    f32 fxSpeed;
    s32 fxStage;
    char pad123C[0x4];
    f32 unk1240;
    f32 unk1244;
    char pad1248[0x7C];
    union {
        struct {
            s32 unk12C4;
        } view12C4_0;
        struct {
            s32 f12C4;
        } view12C4_1;
    } views12C4;
    union {
        struct {
            s32 unk12C8;
        } view12C8_0;
        struct {
            s32 f12C8;
        } view12C8_1;
    } views12C8;
    union {
        struct {
            s32 unk12CC[8];
        } view12CC_0;
        struct {
            s32 splitsA[8];
        } view12CC_1;
    } views12CC;
    s32 unk12EC;
    char pad12F0[0x4];
    union {
        struct {
            s32 unk12F4[8];
        } view12F4_0;
        struct {
            s32 splitsB[8];
        } view12F4_1;
    } views12F4;
    char pad1314[0x20];
    union {
        struct {
            s32 unk1334;
        } view1334_0;
        struct {
            s32 f1334;
        } view1334_1;
    } views1334;
    union {
        struct {
            s32 unk1338;
        } view1338_0;
        struct {
            s32 f1338;
        } view1338_1;
    } views1338;
    union {
        struct {
            s32 unk133C;
        } view133C_0;
        struct {
            s32 laps;
        } view133C_1;
        struct {
            s32 lives;
        } view133C_2;
    } views133C;
    union {
        struct {
            s32 unk1340;
        } view1340_0;
        struct {
            s32 stalls;
        } view1340_1;
        struct {
            s32 timer;
        } view1340_2;
        struct {
            s32 respawnTimer;
        } view1340_3;
    } views1340;
    char pad1344[0x70];
    union {
        struct {
            struct StateInfo * unk13B4;
        } view13B4_0;
        struct {
            struct StateInfo * states;
        } view13B4_1;
        struct {
            struct Mode * unk13B4;
        } view13B4_2;
        struct {
            void * character;
        } view13B4_3;
        struct {
            s32 f13B4;
        } view13B4_4;
        struct {
            struct Shared_StateInfo * states;
        } view13B4_5;
    } views13B4;
    char pad13B8[0x10];
    union {
        struct {
            s32 unk13C8;
        } view13C8_0;
        struct {
            s32 w13C8;
        } view13C8_1;
        struct {
            s32 f13C8;
        } view13C8_2;
    } views13C8;
    char pad13CC[0x8];
    s32 unk13D4;
    union {
        struct {
            struct Held * unk13D8;
        } view13D8_0;
        struct {
            struct Held * held;
        } view13D8_1;
    } views13D8;
    char pad13DC[0xC];
    s32 messageIndex;
    char pad13EC[0x64];
    union {
        struct {
            s32 unk1450;
        } view1450_0;
        struct {
            s32 computer;
        } view1450_1;
        struct {
            s32 infinite;
        } view1450_2;
        struct {
            s32 unlimited;
        } view1450_3;
        struct {
            s32 uncounted;
        } view1450_4;
        struct {
            s32 f1450;
        } view1450_5;
    } views1450;
    union {
        struct {
            s32 unk1454;
        } view1454_0;
        struct {
            s32 f1454;
        } view1454_1;
    } views1454;
    char pad1458[0xC];
    union {
        struct {
            Vec3 unk1464;
        } view1464_0;
        struct {
            Vec3 aim;
        } view1464_1;
    } views1464;
    char pad1470[0x10];
    union {
        struct {
            Matrix unk1480[2];
        } view1480_0;
        struct {
            Matrix beams[2];
        } view1480_1;
    } views1480;
    union {
        struct {
            Matrix unk1500[2];
        } view1500_0;
        struct {
            Matrix lasers[2];
        } view1500_1;
    } views1500;
    union {
        struct {
            Matrix unk1580[2];
        } view1580_0;
        struct {
            Matrix dots[2];
        } view1580_1;
    } views1580;
    char pad1600[0xD4];
    union {
        struct {
            s32 unk16D4;
        } view16D4_0;
        struct {
            s32 f16D4;
        } view16D4_1;
    } views16D4;
    u16 unk16D8;
    char pad16DA[0x6];
    union {
        struct {
            struct SharedPlayer_func_80226A34_de * unk16E0;
        } view16E0_0;
        struct {
            struct SharedPlayer_func_80226A34_de * next;
        } view16E0_1;
        struct {
            struct SharedPlayer_func_80226A34_de * next;
        } view16E0_2;
    } views16E0;
};
union func_80239C2C_S1_UF24;
union func_80239C2C_S1_UF24 {
    void * v0;
    char v1;
};
struct ALHeap;
struct ALHeap {
    u8 *base;
    u8 *cur;
    s32 len;
    s32 count;
};
struct Item_func_8043C9AC_de;
typedef struct Item_func_8043C9AC_de Item_func_8043C9AC_de;
struct StateBlock;
typedef struct StateBlock StateBlock;
struct Style_func_8043C9AC_de;
struct Style_func_8043C9AC_de {
    char pad0[0x30];
    f32 alpha;
    f32 fade;
};
struct Owner_func_8043DB04_de;
struct Owner_func_8043DB04_de {
    char pad[0x5D0];
    s32 value;
};
struct Holder;
struct Owner_func_8043DB04_de;
struct Holder {
    char pad[0x1C];
    struct Owner_func_8043DB04_de *owner;
};
struct CallbackStateC_4;
typedef struct CallbackStateC_4 CallbackStateC_4;
struct Field_void_4;
struct Field_void_4 {
    char pad[0x4];
    void * value;
};
struct Obj_func_802B20D4_de;
struct Obj_func_802B20D4_de {
    char pad18[0x18];
    s16 field18;
};
struct func_8022ED94_S1;
struct func_8022ED94_S1 {
    s32 unk0;
    char pad0[0x4 - 0x0 - sizeof(s32)];
    s32 unk4;
    char pad4[0x8 - 0x4 - sizeof(s32)];
    s32 unk8;
};
union func_80239C2C_S1_UF24;
typedef union func_80239C2C_S1_UF24 func_80239C2C_S1_UF24;
struct Item_func_8042B4D4_de;
struct Item_func_8042B4D4_de {
    char pad[0x10];
    u8 alpha;
    char pad11[0x14 - 0x11];
    s16 x;
};
struct func_8022EA2C_S1;
typedef struct func_8022EA2C_S1 func_8022EA2C_S1;
struct Draw;
typedef struct Draw Draw;
struct func_80258614_S1;
typedef struct func_80258614_S1 func_80258614_S1;
struct State_func_8042D8C4_de;
struct State_func_8042D8C4_de {
    char pad[0xE8];
    s32 count;
};
union func_8026E158_S1_U8;
typedef union func_8026E158_S1_U8 func_8026E158_S1_U8;
struct ALMIDIEvent;
struct ALMIDIEvent {
    s32 ticks;
    u8 status;
    u8 byte1;
    u8 byte2;
    u32 duration;
};
struct Func802608ECResult;
typedef struct Func802608ECResult Func802608ECResult;
struct Func802608ECResult;
struct Func802608ECResult {
    u32 value;
    f32 start;
    f32 delta;
};
struct MenuRules;
typedef struct MenuRules MenuRules;
struct Extra;
typedef struct Extra Extra;
struct ALSynth_func_802B3000_de;
struct ALSynth_func_802B3000_de {
    void *head;
    Link_func_802596B4_de pFreeList;
    Link_func_802596B4_de pAllocList;
    Link_func_802596B4_de pLameList;
    s32 paramSamples;
};
struct func_8025E58C_S1;
struct func_8025E58C_S1 {
    char pad0[0x10];
    short unk10;
};
struct func_8024C654_S1;
typedef struct func_8024C654_S1 func_8024C654_S1;
struct func_80254D70_S2;
typedef struct func_80254D70_S2 func_80254D70_S2;
struct Node75_func_802750B0_de;
typedef struct Node75_func_802750B0_de Node75_func_802750B0_de;
struct func_80207F90_S1;
struct func_80207F90_S1 {
    char pad0[0x100];
    unsigned int unk100;
};
extern int D_80140F88;
struct func_802A2E5C_S2;
typedef struct func_802A2E5C_S2 func_802A2E5C_S2;
struct Entry_func_8041EB50_de;
struct Entry_func_8041EB50_de {
    s32 value;
    char pad[28 - 4];
};
struct func_80229BE0_S2;
typedef struct func_80229BE0_S2 func_80229BE0_S2;
struct func_8022D418_S1;
typedef struct func_8022D418_S1 func_8022D418_S1;
struct ObjectLinks24_2;
typedef struct ObjectLinks24_2 ObjectLinks24_2;
struct func_80245690_S1;
struct func_80245690_S1 {
    s32 unk0;
    char pad0[0x4 - 0x0 - sizeof(s32)];
    s32 unk4;
    char pad4[0x38 - 0x4 - sizeof(s32)];
    s32 unk38;
    char pad38[0x3C - 0x38 - sizeof(s32)];
    s32 unk3C;
    char pad3C[0x60 - 0x3C - sizeof(s32)];
    s32 unk60;
};
struct Resource_func_804101BC_de;
struct Resource_func_804101BC_de {
    s32 id;
    s16 retained;
    s16 unused;
};
struct Field_Vec_18;
struct Field_Vec_18 {
    char pad[0x18];
    Vec3 value;
};
struct func_8022EA2C_S1;
struct func_8022EA2C_S1 {
    char pad0[0x2];
    u16 unk2;
};
extern int D_80111D24;
struct func_80205700_S1;
typedef struct func_80205700_S1 func_80205700_S1;
struct func_8024E58C_S1;
typedef struct func_8024E58C_S1 func_8024E58C_S1;
struct Player_func_80434750_de;
typedef struct Player_func_80434750_de Player_func_80434750_de;
struct ObjectState14;
typedef struct ObjectState14 ObjectState14;
union func_8022E280_S1_U744;
typedef union func_8022E280_S1_U744 func_8022E280_S1_U744;
union func_8022E280_S1_U744;
union func_8022E280_S1_U744 {
    s32 v0;
    f32 v1;
};
struct Record_func_8043E494_de;
struct Record_func_8043E494_de {
    char pad[0x7B];
    s8 mode;
};
struct Owner_func_8043E494_de;
struct Record_func_8043E494_de;
struct Owner_func_8043E494_de {
    char pad[0x5D8];
    struct Record_func_8043E494_de *record;
};
struct Menu_func_8043E494_de;
struct Owner_func_8043E494_de;
struct Menu_func_8043E494_de {
    char pad[0x1C];
    struct Owner_func_8043E494_de *owner;
};
struct func_8025C8F8_S1;
typedef struct func_8025C8F8_S1 func_8025C8F8_S1;
struct Cell_func_80421BEC_de;
struct Cell_func_80421BEC_de {
    char pad[0x16];
    s16 unk16;
    s16 unk18;
    s16 unk1A;
};
struct Cell_func_80421BEC_de;
struct Obj_func_80421BEC_de;
struct Obj_func_80421BEC_de {
    char pad[0x44];
    struct Cell_func_80421BEC_de *unk44;
};
struct Cell_func_80421BEC_de;
struct Obj_func_80421BEC_de;
struct State_func_80421BEC_de;
struct State_func_80421BEC_de {
    struct Obj_func_80421BEC_de *unk0;
    s32 unk4;
    struct Cell_func_80421BEC_de *unk8;
    s32 unkC;
    s32 unk10;
};
struct func_80228774_S4;
typedef struct func_80228774_S4 func_80228774_S4;
struct func_802165F8_S1;
typedef struct func_802165F8_S1 func_802165F8_S1;
struct Access_s32_5C;
struct Access_s32_5C {
    char pad[0x5C];
    s32 field;
};
struct ObjectState1E_2;
struct ObjectState1E_2 {
    char pad0[0x1D];
    u8 unk_1D;
};
struct func_80258BB4_S1;
typedef struct func_80258BB4_S1 func_80258BB4_S1;
struct func_80255BEC_S1;
typedef struct func_80255BEC_S1 func_80255BEC_S1;
struct State_func_8043E254_de;
typedef struct State_func_8043E254_de State_func_8043E254_de;
struct func_80204EA8_S1;
typedef struct func_80204EA8_S1 func_80204EA8_S1;
struct __OSDir;
typedef struct __OSDir __OSDir;
struct func_80255BEC_S1;
struct func_80255BEC_S1 {
    char pad0[0x8];
    void * unk8;
};
struct BufferPool;
struct BufferPool {
    s16 count;
    func_80255BEC_S1 *primary;
    func_80255BEC_S1 *secondary;
    u16 *flags;
    s16 *refs;
};
struct Node_func_80239AF4_de;
typedef struct Node_func_80239AF4_de Node_func_80239AF4_de;
struct Node_func_80239AF4_de;
struct Node_func_80239AF4_de {
    struct Node_func_80239AF4_de *next;
};
struct func_8022BECC_S2;
typedef struct func_8022BECC_S2 func_8022BECC_S2;
struct Controller_func_80217B3C_de;
struct Controller_func_80217B3C_de {
    char pad0[0xC6];
    s8 x;
    s8 y;
};
struct Event_func_8024C1C4_de;
struct Shape_func_802764D4_de_2;
struct Event_func_8024C1C4_de {
    u16 frame;
    u16 effect;
    s16 bone;
    s16 pad6;
    Vec3 local;
    struct Shape_func_802764D4_de_2 params;
};
struct Record_func_80208158_de;
struct Record_func_80208158_de {
    char pad0[0x80];
    s8 kind;
    char pad81[0x13];
    u8 display;
};
struct __OSContRequesFormat;
struct __OSContRequesFormat {
    u8 dummy;
    u8 txsize;
    u8 rxsize;
    u8 cmd;
    u8 typeh;
    u8 typel;
    u8 status;
    u8 dummy1;
};
struct func_80272908_S2;
struct func_80272908_S2 {
    f32 unk0;
    char pad0[0x4 - 0x0 - sizeof(f32)];
    f32 unk4;
    char pad4[0x8 - 0x4 - sizeof(f32)];
    f32 unk8;
    char pad8[0x10 - 0x8 - sizeof(f32)];
    f32 unk10;
    char pad10[0x14 - 0x10 - sizeof(f32)];
    f32 unk14;
    char pad14[0x18 - 0x14 - sizeof(f32)];
    f32 unk18;
    char pad18[0x20 - 0x18 - sizeof(f32)];
    f32 unk20;
    char pad20[0x24 - 0x20 - sizeof(f32)];
    f32 unk24;
    char pad24[0x28 - 0x24 - sizeof(f32)];
    f32 unk28;
    char pad28[0x30 - 0x28 - sizeof(f32)];
    f32 unk30;
    char pad30[0x34 - 0x30 - sizeof(f32)];
    f32 unk34;
    char pad34[0x38 - 0x34 - sizeof(f32)];
    f32 unk38;
};
struct WeaponInfo;
struct WeaponInfo {
    char pad0[0x20];
    s16 *weaponClass;
};
struct func_8022E694_S1;
typedef struct func_8022E694_S1 func_8022E694_S1;
struct Slot;
typedef struct Slot Slot;
struct func_8025E52C_S1;
struct func_8025E52C_S1 {
    char pad0[0x2];
    short unk2;
};
struct Effect_func_8024A1D0_de;
typedef struct Effect_func_8024A1D0_de Effect_func_8024A1D0_de;
struct Field_Vec_18;
typedef struct Field_Vec_18 Field_Vec_18;
struct ALVoiceConfig_s;
typedef struct ALVoiceConfig_s ALVoiceConfig_s;
struct InstanceHdr;
struct InstanceHdr {
    s32 w[5];
};
struct func_8023EBEC_S1;
typedef struct func_8023EBEC_S1 func_8023EBEC_S1;
extern int D_800CB720;
struct Input80216D3C;
typedef struct Input80216D3C Input80216D3C;
struct __OSDir;
struct __OSDir {
    u32 game_code;
    u16 company_code;
    __OSInodeUnit start_page;
    u8 status;
    s8 reserved;
    u16 data_sum;
    u8 ext_name[4];
    u8 game_name[16];
};
struct Element_func_8041200C_de;
typedef struct Element_func_8041200C_de Element_func_8041200C_de;
struct func_80207F90_S1;
typedef struct func_80207F90_S1 func_80207F90_S1;
struct Part;
struct Part {
    char pad[0x78];
    u8 active;
};
struct Player_func_8041EAC4_de;
struct Player_func_8041EAC4_de {
    char pad0[0x78];
    u8 active;
    char pad79[0x96 - 0x79];
};
struct TextEntry;
struct TextEntry {
    s32 id;
    char **text;
};
struct Node75_func_802750B0_de;
struct Node75_func_802750B0_de {
    int pad0;
    void *prev;
    void *cur;
    void *next;
};
struct Label;
struct Label {
    char pad0[0x38];
    char *text;
};
struct func_80228774_S6;
typedef struct func_80228774_S6 func_80228774_S6;
struct Effect_func_8024A1D0_de;
struct Effect_func_8024A1D0_de {
    unsigned char pad0[0x150];
    f32 field150;
    f32 field154;
};
struct Shape;
struct Shape {
    s32 flags;
    s8 enabled;
};
struct Shape;
typedef struct Shape Shape;
struct UnitVtx;
typedef struct UnitVtx UnitVtx;
struct Access_u8_3;
struct Access_u8_3 {
    char pad[0x3];
    u8 field;
};
struct Actor_func_80214310_de;
typedef struct Actor_func_80214310_de Actor_func_80214310_de;
struct Shield;
struct Shield {
    char pad0[0x68];
    f32 factor;
};
struct Header44;
typedef struct Header44 Header44;
struct Key;
typedef struct Key Key;
union func_8028472C_S2_U118;
union func_8028472C_S2_U118 {
    s32 v0;
    s32 * v1;
};
union func_8028472C_S2_U118;
typedef union func_8028472C_S2_U118 func_8028472C_S2_U118;
struct func_8020D0CC_S1;
struct func_8020D0CC_S1 {
    char pad0[0x24];
    void * unk24;
};
struct func_8022CA04_S4;
typedef struct func_8022CA04_S4 func_8022CA04_S4;
struct func_8020EA10_S1;
struct func_8020EA10_S1 {
    char pad0[0x78];
    s32 unk78;
};
struct Triple_func_802683E0_de;
typedef struct Triple_func_802683E0_de Triple_func_802683E0_de;
struct PlayerRecord;
typedef struct PlayerRecord PlayerRecord;
struct Shared_HudView;
struct Shared_HudView {
    char pad0[0x24];
    s32 flags;
    char pad28[0x274];
    f32 width;
    f32 height;
    f32 x;
    f32 y;
};
struct ALEventListItem;
typedef struct ALEventListItem ALEventListItem;
struct func_80207BB8_S4;
struct func_80207BB8_S4 {
    char pad0[0x64];
    f32 unk64;
};
struct func_8022CA04_S4;
struct func_8022CA04_S4 {
    char pad0[0x1C];
    Vec3 unk1C;
};
struct func_80435010_S4;
struct func_80435010_S4 {
    char pad0[0xB9C];
    s32 unkB9C;
};
struct Object_func_80442064_de;
struct Object_func_80442064_de {
    char pad[0x14];
    s32 *source;
};
struct PackedMatrixWords;
struct PackedMatrixWords {
    u32 upper[8];
    u32 lower[8];
};
struct func_8024575C_S1;
typedef struct func_8024575C_S1 func_8024575C_S1;
struct func_80239CDC_S1;
struct func_80239CDC_S1 {
    char pad0[0x4];
    int unk4;
    char pad4[0x8 - 0x4 - sizeof(int)];
    int unk8;
    char pad8[0xC - 0x8 - sizeof(int)];
    int unkC;
    char padC[0x10 - 0xC - sizeof(int)];
    int unk10;
};
struct func_80228774_S6;
struct func_80228774_S6 {
    char pad0[0x128];
    f32 unk128;
};
struct OSPifRam;
struct OSPifRam {
    u32 ramarray[15];
    u32 pifstatus;
};
struct func_802A6A54_S1;
typedef struct func_802A6A54_S1 func_802A6A54_S1;
struct Entry_func_80441EB0_de;
struct List_func_80442574_de;
struct List_func_80442574_de {
    struct Entry_func_80441EB0_de *entries;
    s16 count;
};
struct Record_func_80439C80_de;
struct Record_func_80439C80_de {
    s32 count;
    char pad4[0x34 - 4];
    s32 handle;
};
struct Record_func_80409BDC_de;
struct func_80242278_S1;
struct Record_func_80409BDC_de {
    char pad[0x20];
    struct func_80242278_S1 *inner;
};
struct func_8022A5E4_S2;
struct func_8022A5E4_S2 {
    char pad0[0x16E0];
    void * unk16E0;
};
struct MenuPanelRoot;
struct MenuPanelRoot {
    char pad0[0xE0];
    s32 window;
};
struct ReadWord;
struct ReadWord {
    s32 word;
    u8 byte;
};
struct func_802044C8_S1;
typedef struct func_802044C8_S1 func_802044C8_S1;
struct MatchMenuObjects;
struct MatchMenuObjects {
    char pad0[0x17F0];
    s32 transition;
};
struct func_8020E674_S1;
typedef struct func_8020E674_S1 func_8020E674_S1;
struct Shape_typemap_13;
struct Shape_typemap_13 {
    int field_0;
    int field_4;
};
struct func_8028B3C0_S1;
struct func_8028B3C0_S1 {
    char pad0[0x84];
    void * unk84;
};
struct func_8020C9CC_S1;
typedef struct func_8020C9CC_S1 func_8020C9CC_S1;
struct ALPlayer_s;
typedef struct ALPlayer_s ALPlayer_s;
struct ALPlayer_s;
struct ALPlayer_s {
    struct ALPlayer_s *next;
    void *clientData;
    void *handler;
    s32 callTime;
    s32 samplesLeft;
};
struct func_8028469C_S2;
typedef struct func_8028469C_S2 func_8028469C_S2;
struct Queue;
struct Queue {
    char pad[0x14];
    s32 items[4];
};
struct HashNode;
struct HashNode {
    s32 key;
    void *value;
    s32 unk08;
    struct HashNode *next;
};
struct InstanceHdr;
typedef struct InstanceHdr InstanceHdr;
struct OSPfs_func_80445F80_de;
struct OSPfs_func_80445F80_de {
    int status;
    void *queue;
    int channel;
    u8 id[32];
    u8 label[32];
    int version;
    int dir_size;
    int inode_table;
    int minode_table;
    int dir_table;
    int inode_start_page;
    u8 banks;
    u8 activebank;
};
struct func_8024C8B4_S1;
typedef struct func_8024C8B4_S1 func_8024C8B4_S1;
struct func_8020C9B0_S1;
struct func_8020C9B0_S1 {
    char pad0[0x8];
    char * unk8;
};
struct func_80245A10_S1;
typedef struct func_80245A10_S1 func_80245A10_S1;
struct ALEventListItem;
struct ALEventListItem {
    Link_func_802596B4_de node;
    s32 delta;
    Message_func_802AF150_de evt;
};
struct Params;
typedef struct Params Params;
struct func_802077F4_S4;
typedef struct func_802077F4_S4 func_802077F4_S4;
struct func_80204BB4_S1;
typedef struct func_80204BB4_S1 func_80204BB4_S1;
struct Queue_func_802BB420_de;
typedef struct Queue_func_802BB420_de Queue_func_802BB420_de;
struct func_802B7EB0_S1;
typedef struct func_802B7EB0_S1 func_802B7EB0_S1;
struct MenuRules;
struct MenuRules {
    char pad0[0x1C];
    s32 locked;
};
struct func_80207B5C_S2;
struct func_80207B5C_S2 {
    char pad0[0x24];
    s32 unk24;
};
struct TextEntry;
typedef struct TextEntry TextEntry;
struct func_802428C0_S2;
typedef struct func_802428C0_S2 func_802428C0_S2;
struct func_8020D280_S1;
typedef struct func_8020D280_S1 func_8020D280_S1;
struct Queue_func_802BB420_de;
struct Queue_func_802BB420_de {
    s32 *state;
    s32 unknown4;
    s32 count;
    s32 start;
    s32 capacity;
    s32 *entries;
};
struct func_80272908_S2;
typedef struct func_80272908_S2 func_80272908_S2;
struct Quad_func_802A1BE0_de;
typedef struct Quad_func_802A1BE0_de Quad_func_802A1BE0_de;
struct Quad_func_802A1BE0_de;
struct Quad_func_802A1BE0_de {
    u32 x;
    u32 y;
    u32 z;
    u32 w;
};
struct Params;
struct Params {
    Triple v;
    s32 w;
};
struct Node80253610;
typedef struct Node80253610 Node80253610;
struct func_8023ECAC_S2;
typedef struct func_8023ECAC_S2 func_8023ECAC_S2;
struct func_8021CD70_S3;
typedef struct func_8021CD70_S3 func_8021CD70_S3;
struct func_80251448_S1;
typedef struct func_80251448_S1 func_80251448_S1;
struct Instance8020CD74;
typedef struct Instance8020CD74 Instance8020CD74;
struct func_80255D10_S1;
struct func_80255D10_S1 {
    s32 unk0;
    char pad0[0x4 - 0x0 - sizeof(s32)];
    s32 unk4;
    char pad4[0x8 - 0x4 - sizeof(s32)];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    s32 unkC;
    char padC[0x10 - 0xC - sizeof(s32)];
    s32 unk10;
};
struct UnitVtx;
struct UnitVtx {
    s16 x;
    s16 y;
    s16 z;
    u16 flag;
    s16 s;
    s16 t;
    u8 r;
    u8 g;
    u8 b;
    u8 a;
};
extern int D_800CB6D0;
struct func_80250DBC_S2;
typedef struct func_80250DBC_S2 func_80250DBC_S2;
struct func_8025C8F8_S1;
struct func_8025C8F8_S1 {
    char pad0[0x14];
    char unk14;
    char pad14[0x28 - 0x14 - sizeof(char)];
    s32 unk28;
};
struct func_8024B8DC_S2;
struct func_8024B8DC_S2 {
    char pad0[0x4];
    s32 unk4;
    char pad4[0xC - 0x4 - sizeof(s32)];
    s32 unkC;
};
struct func_80264874_S1;
struct func_80264874_S1 {
    char pad0[0xCC];
    s32 unkCC;
};
extern unsigned char D_800CD72B;
struct Instance8020CD74;
struct Instance8020CD74 {
    s32 w[20];
};
struct func_80293C20_S1;
typedef struct func_80293C20_S1 func_80293C20_S1;
struct func_80293C20_S1;
struct func_80293C20_S1 {
    char pad0[0x26DD4];
    s32 unk26DD4;
};
struct func_80435010_S3;
struct func_80435010_S3 {
    char pad0[0xB8C];
    u8 unkB8C;
};
struct func_802A2BE0_S1;
typedef struct func_802A2BE0_S1 func_802A2BE0_S1;
extern int D_800CD8B8_de;
struct func_80212C04_S2;
struct func_80212C04_S2 {
    char pad0[0x1454];
    s32 * unk1454;
};
struct Limit;
struct Limit {
    char pad[0x16];
    s16 limit;
};
struct Triple_func_802683E0_de;
struct Triple_func_802683E0_de {
    s32 x;
    f32 y;
    s32 z;
};
struct World;
struct World {
    u8 pad000[0xFC];
    s32 state;
};
struct func_80251448_S1;
struct func_80251448_S1 {
    s32 unk0;
    char pad0[0x8 - 0x0 - sizeof(s32)];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    s32 unkC;
    char padC[0x10 - 0xC - sizeof(s32)];
    s32 unk10;
    char pad10[0x14 - 0x10 - sizeof(s32)];
    s32 unk14;
    char pad14[0x20 - 0x14 - sizeof(s32)];
    s32 unk20;
    char pad20[0x24 - 0x20 - sizeof(s32)];
    s32 unk24;
};
struct Field;
struct Field {
    char pad[0x14];
    char **text;
};
struct func_802165F8_S1;
struct func_802165F8_S1 {
    char pad0[0x8];
    Vec3 unk8;
    char pad8[0x6C - 0x8 - sizeof(Vec3)];
    f32 unk6C;
};
struct Field_void_80;
struct Field_void_80 {
    char pad[0x80];
    void * value;
};
struct func_802558C0_S1;
struct func_802558C0_S1 {
    char pad0[0x20];
    char unk20;
};
struct ObjectState1E_2;
typedef struct ObjectState1E_2 ObjectState1E_2;
struct Matrix_func_80213CF8_de;
typedef struct Matrix_func_80213CF8_de Matrix_func_80213CF8_de;
struct func_8023945C_S1;
typedef struct func_8023945C_S1 func_8023945C_S1;
struct Access_s32_50;
typedef struct Access_s32_50 Access_s32_50;
struct func_80254930_S1;
struct func_80254930_S1 {
    char pad0[0x8];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    s32 unkC;
};
struct Target_func_8040AB54_de;
struct Target_func_8040AB54_de {
    char pad[0x120];
    s32 flags;
};
struct Record_func_8040AB54_de;
struct Target_func_8040AB54_de;
struct Record_func_8040AB54_de {
    char pad[0xC];
    struct Target_func_8040AB54_de *target;
};
struct func_8022BECC_S2;
struct func_8022BECC_S2 {
    char pad0[0x8];
    short unk8;
};
struct Header;
struct Header {
    u8 data[0xCC];
};
struct Access_u8_3;
typedef struct Access_u8_3 Access_u8_3;
struct Vec3Words;
typedef struct Vec3Words Vec3Words;
struct func_80258D60_S1;
typedef struct func_80258D60_S1 func_80258D60_S1;
struct func_8022A5E4_S2;
typedef struct func_8022A5E4_S2 func_8022A5E4_S2;
struct func_80245690_S1;
typedef struct func_80245690_S1 func_80245690_S1;
struct func_8025E55C_S1;
typedef struct func_8025E55C_S1 func_8025E55C_S1;
struct State_func_80421D94_de;
struct State_func_80421D94_de {
    void *first;
    char pad4[0x10 - 4];
    s32 value;
};
struct HudStatusShared_MatchRules;
struct HudStatusShared_MatchRules {
    char pad0[0x20];
    s32 hideHud;
    s32 teams;
    char pad28[0x4];
    s32 teamScores[5];
    s32 squadScores[5];
    s32 countRule;
    char pad58[0x20];
    s32 squads;
    char pad7C[0x1C];
    s32 markers;
};
struct Shield;
typedef struct Shield Shield;
struct Item_func_8041A940_de;
struct Item_func_8041A940_de {
    s32 pad0;
    struct Item_func_8041A940_de *next;
    char pad8[0xE - 8];
    u16 kind;
    u8 alpha;
};
struct Slot;
struct Slot {
    char data[24];
};
struct MenuPanelRoot;
typedef struct MenuPanelRoot MenuPanelRoot;
typedef void ( *VoidCallback)(void);
struct __OSContRequesFormat;
typedef struct __OSContRequesFormat __OSContRequesFormat;
struct func_80205494_S3;
typedef struct func_80205494_S3 func_80205494_S3;
struct ReadWord;
typedef struct ReadWord ReadWord;
extern int D_800D3650;
struct Buf16;
typedef struct Buf16 Buf16;
struct func_80272BA8_S2;
typedef struct func_80272BA8_S2 func_80272BA8_S2;
struct func_8020D0CC_S2;
typedef struct func_8020D0CC_S2 func_8020D0CC_S2;
struct Buf16;
struct Buf16 {
    s16 count;
    s16 _pad2;
    s32 value;
    s32 _pad8;
    s32 _padC;
};
struct func_802A67D0_S1;
typedef struct func_802A67D0_S1 func_802A67D0_S1;
struct Table;
struct Table {
    s32 unk0;
    s32 unk4;
    s32 deltas[1];
};
struct Request;
struct Request {
    s16 type;
};
struct func_802428C0_S2;
struct func_802428C0_S2 {
    char pad0[0x38];
    unsigned int unk38;
};
struct Controller_func_80217B3C_de;
typedef struct Controller_func_80217B3C_de Controller_func_80217B3C_de;
struct ALFilter_s_func_802B3000_de;
struct ALFilter_s_func_802B3000_de {
    struct ALFilter_s_func_802B3000_de *source;
    void *handler;
    ALSetParam setParam;
};
extern int D_801427D0;
struct Field_u16_14;
typedef struct Field_u16_14 Field_u16_14;
struct func_804360F4_S2;
struct func_804360F4_S2 {
    char pad0[0x1C];
    void * unk1C;
};
struct ALFilter_s_func_802B3000_de;
struct ALVoice_s_func_802B3000_de;
struct PVoice_s_func_802B3000_de;
struct PVoice_s_func_802B3000_de {
    Link_func_802596B4_de node;
    struct ALVoice_s_func_802B3000_de *vvoice;
    struct ALFilter_s_func_802B3000_de *channelKnob;
    char pad10[0xD8 - 0x10];
    s32 offset;
};
struct ALVoice_s_func_802B3000_de {
    Link_func_802596B4_de node;
    struct PVoice_s_func_802B3000_de *pvoice;
    void *table;
    void *clientPrivate;
    s16 state;
    s16 priority;
    s16 fxBus;
    s16 unityPitch;
};
struct Field_func_8040A4A0_de;
struct Field_func_8040A4A0_de {
    char pad[0x14];
    char *text;
};
struct Header44;
struct Header44 {
    s32 words[11];
};
struct ImageHeader;
struct ImageHeader {
    char pad0[2];
    unsigned char widthShift;
    unsigned char heightShift;
    char pad4[0x1D - 4];
    unsigned char scale;
    char pad1E[0x21 - 0x1E];
    unsigned char width;
    unsigned char height;
    unsigned char format;
    char data[1];
};
struct Image;
struct ImageHeader;
struct Image {
    char pad0[8];
    struct ImageHeader *header;
    s32 fieldC;
    s32 field10;
    char pad14[0x3C - 0x14];
    s32 flags;
};
extern float D_800C4458_de;
struct func_8020676C_S1;
typedef struct func_8020676C_S1 func_8020676C_S1;
struct func_8028DA50_S1;
typedef struct func_8028DA50_S1 func_8028DA50_S1;
extern int D_800D5258;
struct func_802A68A0_S3;
struct func_802A68A0_S3 {
    char pad0[0x118];
    void * unk118;
};
struct func_8025C458_S3;
struct func_8025C458_S3 {
    char pad0[0xDC];
    s16 unkDC;
};
struct ModelDef;
struct ModelDef {
    char pad0[0xE];
    u8 colour;
};
struct func_80284AF4_G2;
typedef struct func_80284AF4_G2 func_80284AF4_G2;
struct Obj_func_802B3EDC_de;
struct Obj_func_802B3EDC_de {
    char pad14[0x14];
    s32 count;
    char pad18[0x4];
    s32 *base;
};
struct Brain_func_80212D78_eu_x;
typedef struct Brain_func_80212D78_eu_x Brain_func_80212D78_eu_x;
struct func_80228774_S4;
struct func_80228774_S4 {
    char pad0[0x8];
    f32 unk8;
    char pad8[0x10 - 0x8 - sizeof(f32)];
    f32 unk10;
    char pad10[0xC4 - 0x10 - sizeof(f32)];
    s32 unkC4;
    char padC4[0xD0 - 0xC4 - sizeof(s32)];
    s32 unkD0;
    char padD0[0x100 - 0xD0 - sizeof(s32)];
    s32 unk100;
    char pad100[0x1D8 - 0x100 - sizeof(s32)];
    void * unk1D8;
};
struct func_8020478C_S1;
typedef struct func_8020478C_S1 func_8020478C_S1;
struct Access_s32_50;
struct Access_s32_50 {
    char pad[0x50];
    s32 field;
};
union func_8026E158_S1_U8;
union func_8026E158_S1_U8 {
    s32 v0;
    char v1;
};
struct func_8020C9B0_S1;
typedef struct func_8020C9B0_S1 func_8020C9B0_S1;
struct func_80275120_S1;
typedef struct func_80275120_S1 func_80275120_S1;
struct func_80239760_S2;
struct func_80239760_S2 {
    char pad0[0xE40];
    char unkE40;
};
struct func_802A2E5C_S2;
struct func_802A2E5C_S2 {
    char pad0[0x4];
    void * unk4;
    char pad4[0xE - 0x4 - sizeof(void*)];
    u16 unkE;
    char padE[0x10 - 0xE - sizeof(u16)];
    s8 unk10;
};
struct func_80242278_S2;
typedef struct func_80242278_S2 func_80242278_S2;
struct func_802062E0_S2;
typedef struct func_802062E0_S2 func_802062E0_S2;
struct Work56EC8;
struct Work56EC8 {
    void *owner;
    s16 id;
    char pad6[2];
    char payload[0x40];
    void *base;
    s32 offset;
};
struct MenuSettings;
typedef struct MenuSettings MenuSettings;
struct func_8023ECAC_S2;
struct func_8023ECAC_S2 {
    char pad0[0x44];
    s32 unk44;
    char pad44[0x52 - 0x44 - sizeof(s32)];
    u16 unk52;
};
struct PackedMatrixWords;
typedef struct PackedMatrixWords PackedMatrixWords;
struct func_80205314_S2;
typedef struct func_80205314_S2 func_80205314_S2;
struct func_8020CA10_S2;
typedef struct func_8020CA10_S2 func_8020CA10_S2;
struct func_80254D70_S2;
struct func_80254D70_S2 {
    char pad0[0x8];
    s32 unk8;
};
struct func_8025BD20_S1;
typedef struct func_8025BD20_S1 func_8025BD20_S1;
struct func_8020D0CC_S2;
struct func_8020D0CC_S2 {
    char pad0[0x10];
    void * unk10;
};
struct func_80239CD0_S1;
typedef struct func_80239CD0_S1 func_80239CD0_S1;
struct Header;
typedef struct Header Header;
extern int D_800CC370;
struct State_func_804447F0_de;
struct State_func_804447F0_de {
    char a[8];
    s32 unk8;
    char b[8];
    char *unk14;
};
struct StateBlock;
struct StateBlock {
    char pad0[0x84];
    s32 unk84;
};
struct Shared_GameMode;
typedef struct Shared_GameMode Shared_GameMode;
extern int D_800E63AC;
struct func_80245A10_S1;
struct func_80245A10_S1 {
    char pad0[0x104];
    int unk104;
};
struct Args;
struct Args {
    u32 words[10];
};
struct func_8025E58C_S1;
typedef struct func_8025E58C_S1 func_8025E58C_S1;
struct Field_f32_10;
struct Field_f32_10 {
    char pad[0x10];
    f32 value;
};
struct func_80435010_S4;
typedef struct func_80435010_S4 func_80435010_S4;
struct Player_func_80434750_de;
struct Player_func_80434750_de {
    char pad[0x58];
    int state;
    char pad5C[0xB68 - 0x5C];
};
struct func_8025CA44_S1;
struct func_8025CA44_S1 {
    char pad0[0x14];
    func_80239C2C_S1_UF24 unk14;
};
extern int D_8014D260[];
struct HashNode;
typedef struct HashNode HashNode;
struct func_8025E55C_S1;
struct func_8025E55C_S1 {
    char pad0[0xA];
    short unkA;
};
struct func_8029A838_S1;
typedef struct func_8029A838_S1 func_8029A838_S1;
struct Record;
typedef struct Record Record;
extern float D_80146CB8;
struct func_802558C0_S1;
typedef struct func_802558C0_S1 func_802558C0_S1;
struct Shape_typemap_71;
struct Shape_typemap_71 {
    unsigned char padding_0[28];
    int field_1C;
};
struct func_8024E58C_S1;
struct func_8024E58C_S1 {
    f32 unk0;
    char pad0[0x8 - 0x0 - sizeof(f32)];
    f32 unk8;
};
struct BufferPool;
typedef struct BufferPool BufferPool;
struct Request;
typedef struct Request Request;
struct func_80284AF4_G2;
struct func_80284AF4_G2 {
    void * unk0;
};
struct func_80255D10_S1;
typedef struct func_80255D10_S1 func_80255D10_S1;
struct func_8024C654_S1;
struct func_8024C654_S1 {
    char pad0[0x18];
    s32 * unk18;
};
struct func_8020676C_S1;
struct func_8020676C_S1 {
    char pad0[0x6];
    unsigned short unk6;
};
struct func_80206930_S3;
struct func_80206930_S3 {
    char pad0[0x7];
    unsigned char unk7;
};
struct func_8029A9E0_S1;
typedef struct func_8029A9E0_S1 func_8029A9E0_S1;
struct Shared_HudView;
typedef struct Shared_HudView Shared_HudView;
struct State_func_8043E254_de;
struct State_func_8043E254_de {
    char pad0[0x1C];
    s32 unk1C;
    s32 unk20;
    char pad24[4];
    s32 unk28;
};
struct State_func_804447F0_de;
typedef struct State_func_804447F0_de State_func_804447F0_de;
struct ObjectLinks24_2;
struct ObjectLinks24_2 {
    char * unk_0;
    char pad0[0x4 - 0x0 - sizeof(char*)];
    char * unk_4;
    char pad4[0xC - 0x4 - sizeof(char*)];
    void * unk_C;
    char padC[0x10 - 0xC - sizeof(void*)];
    s32 unk_10;
    char pad10[0x14 - 0x10 - sizeof(s32)];
    s32 unk_14;
    char pad14[0x20 - 0x14 - sizeof(s32)];
    s32 unk_20;
};
struct func_8020F2A8_S3;
typedef struct func_8020F2A8_S3 func_8020F2A8_S3;
struct func_802831FC_S1;
typedef struct func_802831FC_S1 func_802831FC_S1;
struct Link;
struct Link {
    unsigned short from;
    unsigned short to;
    unsigned char type;
};
struct CollisionInfo;
struct CollisionInfo {
    s32 w[8];
};
struct func_80254D70_S1;
struct func_80254D70_S1 {
    char pad0[0x14];
    void * unk14;
};
struct OSPifRam;
typedef struct OSPifRam OSPifRam;
struct func_8026E158_S1;
struct func_8026E158_S1 {
    char pad0[0x8];
    func_8026E158_S1_U8 unk8;
};
struct func_80212C04_S2;
typedef struct func_80212C04_S2 func_80212C04_S2;
struct func_80293268_S2;
struct func_80293268_S2 {
    char pad0[0x26DBC];
    s32 unk26DBC;
    char pad26DBC[0x26DC1 - 0x26DBC - sizeof(s32)];
    s8 unk26DC1;
    char pad26DC1[0x26DD8 - 0x26DC1 - sizeof(s8)];
    s32 unk26DD8;
    char pad26DD8[0x26DDC - 0x26DD8 - sizeof(s32)];
    s32 unk26DDC;
};
struct func_80435010_S3;
typedef struct func_80435010_S3 func_80435010_S3;
struct Slots_func_8041B7FC_de;
struct Slots_func_8041B7FC_de {
    char pad[0x4C];
    s32 values[1];
};
struct Cell_func_80421BEC_de;
typedef struct Cell_func_80421BEC_de Cell_func_80421BEC_de;
struct D_800C7470_Pair;
struct D_800C7470_Pair {
    f32 first;
    f32 second;
};
struct func_8024C8B4_S1;
struct func_8024C8B4_S1 {
    f32 unk0;
    char pad0[0x4 - 0x0 - sizeof(f32)];
    f32 unk4;
    char pad4[0x8 - 0x4 - sizeof(f32)];
    f32 unk8;
    char pad8[0xC - 0x8 - sizeof(f32)];
    f32 unkC;
};
struct Pair14;
struct Pair14 {
    char pad[0x14];
    s16 first;
    s16 second;
};
struct Obj_func_80297DBC_de;
struct Obj_func_80297DBC_de {
    char p[0x40];
    s32 unk40;
};
struct func_8020E674_S1;
struct func_8020E674_S1 {
    char pad0[0x8];
    func_8020E674_S1_U8 unk8;
};
struct func_80272BA8_S2;
struct func_80272BA8_S2 {
    f32 unk0;
    char pad0[0x4 - 0x0 - sizeof(f32)];
    f32 unk4;
    char pad4[0x8 - 0x4 - sizeof(f32)];
    f32 unk8;
    char pad8[0x10 - 0x8 - sizeof(f32)];
    f32 unk10;
    char pad10[0x14 - 0x10 - sizeof(f32)];
    f32 unk14;
    char pad14[0x18 - 0x14 - sizeof(f32)];
    f32 unk18;
    char pad18[0x20 - 0x18 - sizeof(f32)];
    f32 unk20;
    char pad20[0x24 - 0x20 - sizeof(f32)];
    f32 unk24;
    char pad24[0x28 - 0x24 - sizeof(f32)];
    f32 unk28;
};
struct func_804360F4_S2;
typedef struct func_804360F4_S2 func_804360F4_S2;
struct func_802B4ECC_S1;
struct func_802B4ECC_S1 {
    char pad0[0x18];
    void * unk18;
    char pad18[0x24 - 0x18 - sizeof(void*)];
    s32 unk24;
};
struct Slot_func_8041F140_de;
struct Slot_func_8041F140_de {
    s32 key;
    char pad[0x70 - 4];
};
struct Shape_typemap_30;
struct Shape_typemap_30 {
    unsigned char padding_0[32];
    int field_20;
};
struct Block24;
struct Block24 {
    s32 words[6];
};
struct ALVoiceConfig_s;
struct ALVoiceConfig_s {
    s16 priority;
    s16 fxBus;
    u8 unityPitch;
};
struct IntegerStateDC_2;
typedef struct IntegerStateDC_2 IntegerStateDC_2;
struct func_802077F4_S4;
struct func_802077F4_S4 {
    char pad0[0x40];
    f32 unk40;
};
struct List;
struct List {
    char pad0[0x48];
    u8 visibleX;
    u8 visibleY;
    u8 maxX;
    u8 maxY;
    u8 cursorX;
    u8 cursorY;
    u8 scrollX;
    u8 scrollY;
    u8 minX;
    u8 minY;
};
struct func_802A67D0_S1;
struct func_802A67D0_S1 {
    char pad0[0x7528];
    void * unk7528;
};
struct func_8025C598_S1;
struct func_8025C598_S1 {
    s32 unk0;
    char pad0[0xB0 - 0x0 - sizeof(s32)];
    s32 unkB0;
};
struct MatchMenuObjects;
typedef struct MatchMenuObjects MatchMenuObjects;
struct func_80247F08_S1;
struct func_80247F08_S1 {
    char pad0[0x30];
    f32 unk30;
    char pad30[0x34 - 0x30 - sizeof(f32)];
    f32 unk34;
    char pad34[0x38 - 0x34 - sizeof(f32)];
    f32 unk38;
};
struct ControllerProfile;
struct ControllerProfile {
    char pad0[0x224];
};
struct Args;
typedef struct Args Args;
struct func_8020CC0C_S1;
typedef struct func_8020CC0C_S1 func_8020CC0C_S1;
struct func_80272848_S1;
typedef struct func_80272848_S1 func_80272848_S1;
struct Actor_func_80214310_de;
struct Actor_func_80214310_de {
    char pad0[8];
    Vec3 position;
    char pad14[0x70 - 0x14];
    f32 eye;
};
struct World_func_8028787C_de;
typedef struct World_func_8028787C_de World_func_8028787C_de;
struct ObjectState1E;
typedef struct ObjectState1E ObjectState1E;
extern int D_800CC38C;
struct func_80203908_S4;
typedef struct func_80203908_S4 func_80203908_S4;
struct Link;
typedef struct Link Link;
struct Draw;
struct Draw {
    char pad0[0xC];
    void *model;
};
struct Field_void_4;
typedef struct Field_void_4 Field_void_4;
struct func_80293268_S1;
typedef struct func_80293268_S1 func_80293268_S1;
struct func_80250BD4_S1;
typedef struct func_80250BD4_S1 func_80250BD4_S1;
struct ALEvent_func_802B21A8_de;
typedef struct ALEvent_func_802B21A8_de ALEvent_func_802B21A8_de;
struct func_8022E694_S1;
struct func_8022E694_S1 {
    char pad0[0x44];
    s32 unk44;
};
struct Obj_func_8043CC10_de;
struct Obj_func_8043CC10_de {
    char pad[0x14];
    u8 **unk14;
};
struct func_8020478C_S1;
struct func_8020478C_S1 {
    char pad0[0x4];
    unsigned short unk4;
    char pad4[0xA - 0x4 - sizeof(unsigned short)];
    unsigned short unkA;
};
struct World_func_8028787C_de;
struct World_func_8028787C_de {
    char pad0[0x80];
    void *levels;
    char pad84[0x1B40C - 0x84];
    s32 level;
};
struct func_80250DBC_S2;
struct func_80250DBC_S2 {
    char pad0[0xE];
    s8 unkE;
};
struct Field_void_80;
typedef struct Field_void_80 Field_void_80;
struct Node80253610;
struct Node80253610 {
    s32 field0;
    s32 field4;
    s32 references;
    u32 flags;
};
struct Obj_func_8043CC10_de;
typedef struct Obj_func_8043CC10_de Obj_func_8043CC10_de;
struct func_80247F08_S1;
typedef struct func_80247F08_S1 func_80247F08_S1;
struct HudStatusShared_Settings;
typedef struct HudStatusShared_Settings HudStatusShared_Settings;
struct func_80204BB4_S1;
struct func_80204BB4_S1 {
    char pad0[0x2C];
    void * unk2C;
    char pad2C[0x108 - 0x2C - sizeof(void*)];
    void * unk108;
};
struct func_80239760_S2;
typedef struct func_80239760_S2 func_80239760_S2;
struct func_8023EBEC_S1;
struct func_8023EBEC_S1 {
    char pad0[0x3C];
    s32 unk3C;
};
struct func_80264874_S1;
typedef struct func_80264874_S1 func_80264874_S1;
struct func_8022CA04_S3;
typedef struct func_8022CA04_S3 func_8022CA04_S3;
struct NodeEvent;
typedef struct NodeEvent NodeEvent;
struct Style_func_8043C9AC_de;
typedef struct Style_func_8043C9AC_de Style_func_8043C9AC_de;
struct Access_s32_5C;
typedef struct Access_s32_5C Access_s32_5C;
struct func_80228774_S7;
typedef struct func_80228774_S7 func_80228774_S7;
struct func_80293268_S1;
struct func_80293268_S1 {
    s32 unk0;
    char pad0[0x4 - 0x0 - sizeof(s32)];
    s32 unk4;
    char pad4[0x8 - 0x4 - sizeof(s32)];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    s32 unkC;
    char padC[0x88 - 0xC - sizeof(s32)];
    s32 unk88;
};
struct Work56EC8;
typedef struct Work56EC8 Work56EC8;
struct Table;
typedef struct Table Table;
extern int D_8014D270[];
struct func_8029A838_S1;
struct func_8029A838_S1 {
    s32 unk0;
    char pad0[0x10 - 0x0 - sizeof(s32)];
    s32 unk10;
};
struct Record_func_80444C68_de;
struct Record_func_80444C68_de {
    char pad[8];
    s32 flags;
    char padC[0x14 - 0xC];
    s32 value;
};
struct ResourceManagerState;
typedef struct ResourceManagerState ResourceManagerState;
struct Table_func_8028CE94_de;
typedef struct Table_func_8028CE94_de Table_func_8028CE94_de;
struct D_800C7470_Pair;
typedef struct D_800C7470_Pair D_800C7470_Pair;
struct Profile_func_80229554_de;
typedef struct Profile_func_80229554_de Profile_func_80229554_de;
struct func_8021846C_S3;
typedef struct func_8021846C_S3 func_8021846C_S3;
struct ControllerProfile;
typedef struct ControllerProfile ControllerProfile;
struct func_8024B8DC_S2;
typedef struct func_8024B8DC_S2 func_8024B8DC_S2;
struct func_80205494_S3;
struct func_80205494_S3 {
    char pad0[0x14];
    unsigned int unk14;
};
struct TextLayerRect;
struct TextLayerRect {
    char pad[0x14];
    int x;
    int right;
    int y;
};
struct Shared_GameMode;
struct Shared_GameMode {
    char pad0[0x1C];
    s32 unk1C;
    char pad20[0x8];
    s32 unk28;
};
struct Query;
struct Query {
    f32 radius;
    f32 bottom;
    f32 top;
    f32 top1;
    f32 bottom1;
    f32 top2;
    f32 bottom2;
    f32 minX;
    f32 minZ;
    f32 maxX;
    f32 maxZ;
    s32 flag;
};
struct Item_func_8041A940_de;
struct Menu_func_8041A940_de;
struct Menu_func_8041A940_de {
    char pad0[8];
    struct Item_func_8041A940_de *items;
    char padC[0x54 - 0xC];
    s32 state;
};
struct func_8022E3B4_S3;
struct func_8022E3B4_S3 {
    char pad0[0x4];
    s16 unk4;
};
extern int D_80100598[];
struct func_802A6A54_S1;
struct func_802A6A54_S1 {
    char pad0[0x14];
    f32 unk14;
    char pad14[0x24 - 0x14 - sizeof(f32)];
    f32 unk24;
    char pad24[0x34 - 0x24 - sizeof(f32)];
    f32 unk34;
    char pad34[0x38 - 0x34 - sizeof(f32)];
    f32 unk38;
    char pad38[0x3C - 0x38 - sizeof(f32)];
    f32 unk3C;
};
struct func_80204468_S2;
typedef struct func_80204468_S2 func_80204468_S2;
struct func_80203908_S4;
struct func_80203908_S4 {
    char pad0[0x6C];
    f32 unk6C;
};
struct PixelFormat;
struct PixelFormat {
    char pad0[0x14];
    u32 mask[4];
    s32 shift[4];
};
struct func_8025C458_S3;
typedef struct func_8025C458_S3 func_8025C458_S3;
struct func_8020D9C0_S1;
typedef struct func_8020D9C0_S1 func_8020D9C0_S1;
struct func_802045CC_S1;
typedef struct func_802045CC_S1 func_802045CC_S1;
struct ALFilter_s_func_802B3000_de;
typedef struct ALFilter_s_func_802B3000_de ALFilter_s_func_802B3000_de;
struct ObjectStateC_2;
typedef struct ObjectStateC_2 ObjectStateC_2;
struct func_8026E158_S1;
typedef struct func_8026E158_S1 func_8026E158_S1;
struct PixelFormat;
typedef struct PixelFormat PixelFormat;
struct Input80216D3C;
struct Input80216D3C {
    s32 unk0;
    s32 unk4;
    Triple vec;
};
struct CallbackStateC_4;
struct CallbackStateC_4 {
    char pad0[0x8];
    void (*callback)(void *, s32, void *);
};
struct func_8029A9E0_S1;
struct func_8029A9E0_S1 {
    char pad0[0x4];
    unsigned int unk4;
};
struct State_func_80421BEC_de;
typedef struct State_func_80421BEC_de State_func_80421BEC_de;
struct Record_func_80409DCC_de;
struct func_8021846C_S3;
struct Record_func_80409DCC_de {
    char pad[0x20];
    struct func_8021846C_S3 *inner;
};
struct Status;
struct Status {
    char pad0[0x78];
    u8 active;
    char pad79[0x80 - 0x79];
    s8 kind;
    char pad81[150 - 0x81];
};
struct Model;
typedef struct Model Model;
struct func_802428C0_S1;
typedef struct func_802428C0_S1 func_802428C0_S1;
struct func_802045CC_S1;
struct func_802045CC_S1 {
    char pad0[0x12C];
    s32 unk12C;
};
struct Entry_func_804101BC_de;
struct Entry_func_804101BC_de {
    s32 unused;
    s32 flags;
    char rest[0x14];
};
struct HudStatusShared_Settings;
struct HudStatusShared_Settings {
    s32 flags;
    s32 selection;
    char pad8[0x5];
    u8 trialKind;
    char padE[0x8];
    u8 hudFade;
    char pad17[0x6];
    u8 hudShown;
    char pad1E[0xB2];
    ListScreenRecord roster[8];
    char pad580[0x1];
    u8 language;
    char pad582[0x32];
    s32 state;
    char pad5B8[0x20];
    HudStatusShared_MatchRules rules;
    char pad674[0xC];
    s32 humanWon;
};
struct func_80205700_S1;
struct func_80205700_S1 {
    char pad0[0xC];
    unsigned int unkC;
};
extern int D_8010BBF0[];
struct WeaponInfo;
typedef struct WeaponInfo WeaponInfo;
struct func_8024575C_S1;
struct func_8024575C_S1 {
    char pad0[0xDC];
    int unkDC;
};
struct func_8020D9C0_S1;
struct func_8020D9C0_S1 {
    char pad0[0x14];
    f32 unk14;
};
extern int D_800CC388;
struct func_8020D280_S1;
struct func_8020D280_S1 {
    char pad0[0x28];
    int unk28;
};
struct Event_func_8024C1C4_de;
typedef struct Event_func_8024C1C4_de Event_func_8024C1C4_de;
struct func_8022BC04_S3;
struct func_8022BC04_S3 {
    char pad0[0x10];
    s32 unk10;
};
struct func_802A2BE0_S1;
struct func_802A2BE0_S1 {
    char pad0[0x8];
    void * unk8;
    char pad8[0x12 - 0x8 - sizeof(void*)];
    u16 unk12;
};
struct func_8020CB3C_S1;
typedef struct func_8020CB3C_S1 func_8020CB3C_S1;
struct MenuSettings;
struct MenuSettings {
    u8 padding[0x581];
    u8 language;
};
struct func_802B7EB0_S1;
struct func_802B7EB0_S1 {
    char pad0[0x14];
    char unk14;
    char pad14[0x3C - 0x14 - sizeof(char)];
    s32 unk3C;
    char pad3C[0x40 - 0x3C - sizeof(s32)];
    s32 unk40;
};
struct func_802831FC_S1;
struct func_802831FC_S1 {
    char pad0[0xFC3C];
    s8 * unkFC3C;
};
struct IntegerStateDC_2;
struct IntegerStateDC_2 {
    unsigned char padding[216];
    s32 state;
};
struct func_8022E3B4_S3;
typedef struct func_8022E3B4_S3 func_8022E3B4_S3;
struct func_80239CDC_S1;
typedef struct func_80239CDC_S1 func_80239CDC_S1;
struct func_8020F2A8_S3;
struct func_8020F2A8_S3 {
    char pad0[0x34];
    s32 unk34;
};
struct Node_func_80285B64_de;
typedef struct Node_func_80285B64_de Node_func_80285B64_de;
struct func_8024C5C4_S2;
struct func_8024C5C4_S2 {
    char pad0[0x4];
    s32 unk4;
    char pad4[0x8 - 0x4 - sizeof(s32)];
    char unk8;
};
struct func_80258614_S1;
struct func_80258614_S1 {
    char pad0[0x110];
    s32 unk110;
    char pad110[0x138 - 0x110 - sizeof(s32)];
    char unk138;
    char pad138[0x1DB8 - 0x138 - sizeof(char)];
    char unk1DB8;
};
struct Obj_func_802B3EDC_de;
typedef struct Obj_func_802B3EDC_de Obj_func_802B3EDC_de;
struct func_8020D0CC_S1;
typedef struct func_8020D0CC_S1 func_8020D0CC_S1;
struct Params_func_802B2F10_de;
struct Params_func_802B2F10_de {
    s16 f0;
    s32 f4;
    s16 f8;
};
struct func_802428C0_S1;
struct func_802428C0_S1 {
    char pad0[0x3C];
    unsigned int unk3C;
};
extern int D_80140FB0;
struct PlayerRecord;
struct PlayerRecord {
    char data[0x190];
};
struct func_8020CB3C_S1;
struct func_8020CB3C_S1 {
    void * unk0;
    char pad0[0x4 - 0x0 - sizeof(void*)];
    s32 unk4;
};
struct func_8025E5B0_S1;
typedef struct func_8025E5B0_S1 func_8025E5B0_S1;
extern float D_800C1A10_de;
extern float D_800C1A14_de;
extern float D_800C1A18;
extern float D_800C1A1C;
extern float D_800C1A20;
extern float D_800C1A24;
extern float D_800C1A28;
extern float D_800C1A2C;
extern float D_800C1A30;
extern float D_800C1A34_de;
extern float D_800C1A38_de;
extern float D_800C1A4C_de;
extern float D_800C1A6C_de;
extern float D_800C1A74_de;
extern float D_800C1A78_de;
extern double D_800C1AD8;
extern float D_800C1B10_de;
extern float D_800C1B14_de;
extern float D_800C1B18_de;
extern float D_800C1B1C_de;
extern float D_800C1B20_de;
extern float D_800C1B24_de;
extern float D_800C1B28_de;
extern float D_800C1B2C_de;
extern float D_800C1B34_de;
extern float D_800C1B38_de;
extern float D_800C1B3C_de;
extern float D_800C1B40_de;
extern float D_800C1B44_de;
extern float D_800C1B48_de;
extern float D_800C1B4C_de;
extern float D_800C1B50_de;
extern float D_800C1B54_de;
extern float D_800C1B5C_de;
extern float D_800C1B60_de;
extern float D_800C1B64_de;
extern float D_800C1B68_de;
extern float D_800C1B6C_de;
extern float D_800C1B70_de;
extern float D_800C1B74_de;
extern float D_800C1B78_de;
extern float D_800C1B7C_de;
extern float D_800C1B80_de;
extern float D_800C1B84_de;
extern float D_800C1B9C_de;
extern float D_800C1BB0_de;
extern float D_800C1BB4_de;
extern float D_800C1BB8_de;
extern float D_800C1BBC_de;
extern float D_800C1BC0_de;
extern float D_800C1BC4_de;
extern float D_800C1BC8_de;
extern float D_800C1BCC_de;
extern float D_800C1BD0_de;
extern float D_800C1BD4_de;
extern float D_800C1BD8_de;
extern float D_800C1BDC_de;
extern float D_800C1BE0_de;
extern float D_800C1BE4_de;
extern float D_800C1BF0_de;
extern float D_800C1C00;
extern float D_800C1C04;
extern float D_800C1C08;
extern float D_800C1C14;
extern float D_800C1C24_de;
extern float D_800C1C28_de;
extern float D_800C1C2C_de;
extern float D_800C1C30_de;
extern float D_800C1C34_de;
extern float D_800C1C38_de;
extern float D_800C1C3C_de;
extern float D_800C1C40_de;
extern float D_800C1C44_de;
extern float D_800C1C48_de;
extern float D_800C1C4C_de;
extern float D_800C1C50_de;
extern float D_800C1C54_de;
extern float D_800C1C58_de;
extern float D_800C1C5C_de;
extern float D_800C1C60_de;
extern float D_800C1C64_de;
extern float D_800C1C68_de;
extern float D_800C1C6C_de;
extern float D_800C1C70_de;
extern float D_800C1C74_de;
extern float D_800C1C78_de;
extern float D_800C1C84_de;
extern float D_800C1D34_de;
extern float D_800C1D44;
extern float D_800C1D48;
extern float D_800C1D4C_de;
extern float D_800C1D50_de;
extern float D_800C1D54_de;
extern float D_800C1D58_de;
extern float D_800C1D5C_de;
extern float D_800C1D60_de;
extern float D_800C1D60_eu_x;
extern float D_800C1D64_de;
extern float D_800C1D70_de;
extern float D_800C1D70_eu_x;
extern float D_800C1D74_de;
extern float D_800C1D74_eu_x;
extern float D_800C1D78_de;
extern float D_800C1D7C_de;
extern float D_800C1D80_de;
extern float D_800C1D84_de;
extern float D_800C1D88_de;
extern float D_800C1D94_de;
extern float D_800C1D98;
extern float D_800C1D9C;
extern float D_800C1DA0;
extern float D_800C1DB0_de;
extern float D_800C1DB4_de;
extern float D_800C1E54_de;
extern float D_800C1E60_de;
extern float D_800C1F14_de;
extern float D_800C1F20_de;
extern float D_800C1F24_de;
extern float D_800C1F28_de;
extern float D_800C1F2C_de;
extern float D_800C1F30_de;
extern float D_800C1F34_de;
extern float D_800C1F50_de;
extern float D_800C1F54_de;
extern float D_800C1F58_de;
extern float D_800C1F5C_de;
extern float D_800C1F60_de;
extern float D_800C1F64_de;
extern float D_800C1F68_de;
extern float D_800C1F6C_de;
extern float D_800C1F70_de;
extern float D_800C1F74_de;
extern float D_800C1F78_de;
extern float D_800C1F7C_de;
extern float D_800C1F80_de;
extern float D_800C1F90_de;
extern float D_800C1F94_de;
extern float D_800C1F98_de;
extern float D_800C1F9C_de;
extern float D_800C1FA0_de;
extern float D_800C1FA4_de;
extern float D_800C1FA8_de;
extern float D_800C1FAC_de;
extern float D_800C1FB0_de;
extern float D_800C1FB4_de;
extern float D_800C1FB8_de;
extern float D_800C1FBC_de;
extern float D_800C1FC0_de;
extern float D_800C1FC4_de;
extern float D_800C1FC8_de;
extern float D_800C1FCC_de;
extern float D_800C1FD0_de;
extern float D_800C1FD4_de;
extern float D_800C1FF4_de;
extern float D_800C207C_eu;
extern float D_800C2080_eu;
extern float D_800C2084_eu;
extern float D_800C20A8_eu;
extern float D_800C20AC_eu;
extern float D_800C20B0_eu;
extern float D_800C20B4_eu;
extern float D_800C20B8_eu;
extern float D_800C20BC_eu;
extern float D_800C20C0_eu;
extern float D_800C20C4_de;
extern float D_800C20C4_eu;
extern float D_800C20C8_eu;
extern float D_800C20CC_de;
extern float D_800C20CC_eu;
extern float D_800C20D0_eu;
extern float D_800C20D4_eu;
extern float D_800C20D8_eu;
extern float D_800C20DC_eu;
extern float D_800C2104_de;
extern float D_800C211C_de;
extern double D_800C2130_de;
extern float D_800C2138_de;
extern float D_800C213C_de;
extern float D_800C2160_de;
extern float D_800C2164_de;
extern float D_800C2168_de;
extern float D_800C217C_de;
extern float D_800C2180_de;
extern float D_800C2184_de;
extern float D_800C2188_de;
extern float D_800C218C;
extern float D_800C2190_de;
extern float D_800C2194;
extern float D_800C2198;
extern float D_800C219C_de;
extern float D_800C21A0_de;
extern float D_800C21A4_de;
extern float D_800C21A8_de;
extern float D_800C21AC_de;
extern float D_800C21B0_de;
extern float D_800C21B4_de;
extern float D_800C21B8_de;
extern float D_800C21BC_de;
extern float D_800C21C4_de;
extern float D_800C21D0_de;
extern float D_800C21D4_de;
extern float D_800C21E0_eu;
extern float D_800C2200_de;
extern float D_800C2204_de;
extern float D_800C2208_de;
extern float D_800C220C_de;
extern float D_800C2210_de;
extern float D_800C2214_de;
extern float D_800C2218_de;
extern float D_800C221C_de;
extern float D_800C2220_de;
extern float D_800C2224_de;
extern float D_800C2228_de;
extern float D_800C222C_de;
extern float D_800C2230_de;
extern float D_800C2234_de;
extern float D_800C2240_de;
extern float D_800C2244_de;
extern float D_800C2248_de;
extern float D_800C226C_de;
extern float D_800C2270_de;
extern float D_800C2274_de;
extern float D_800C2278_de;
extern float D_800C227C_de;
extern float D_800C2280_de;
extern float D_800C2284_de;
extern float D_800C2288_de;
extern float D_800C228C_de;
extern float D_800C2290_de;
extern float D_800C2294_de;
extern float D_800C2298_de;
extern float D_800C229C_de;
extern float D_800C229C_us;
extern float D_800C22A0_us;
extern float D_800C22A4_de;
extern float D_800C22A4_us;
extern float D_800C22A8_us;
extern float D_800C22AC_de;
extern float D_800C22AC_us;
extern float D_800C22B0_de;
extern float D_800C22B0_eu;
extern float D_800C22B4_de;
extern float D_800C22B4_eu;
extern float D_800C22B8_de;
extern float D_800C22B8_eu;
extern float D_800C22BC_de;
extern float D_800C22BC_eu;
extern float D_800C22C0_de;
extern float D_800C22C0_eu;
extern float D_800C22C4_de;
extern float D_800C22C4_eu;
extern float D_800C22C8_eu;
extern float D_800C22CC_eu;
extern float D_800C22D4_de;
extern float D_800C22D4_eu;
extern float D_800C22D8_de;
extern float D_800C22D8_eu;
extern float D_800C22DC_de;
extern float D_800C22DC_eu;
extern float D_800C22E0_de;
extern float D_800C22E4_eu;
extern float D_800C22E8_eu;
extern float D_800C22EC_de;
extern float D_800C22F0_eu;
extern float D_800C22F4_eu;
extern float D_800C22F8_eu;
extern float D_800C22FC_eu;
extern float D_800C2300_de;
extern float D_800C2300_eu;
extern float D_800C2304_de;
extern float D_800C2304_eu;
extern float D_800C2308_de;
extern float D_800C2308_eu;
extern float D_800C230C_eu;
extern float D_800C2310_de;
extern float D_800C2310_eu;
extern float D_800C2314_de;
extern float D_800C2314_eu;
extern float D_800C2318_de;
extern float D_800C231C_de;
extern float D_800C231C_eu;
extern float D_800C2320_de;
extern float D_800C2320_eu;
extern float D_800C2324_de;
extern float D_800C2328_de;
extern float D_800C2328_eu;
extern float D_800C232C_de;
extern float D_800C232C_eu;
extern float D_800C2330_de;
extern float D_800C2330_eu;
extern float D_800C2334_de;
extern float D_800C2334_eu;
extern float D_800C2338_de;
extern float D_800C2338_eu;
extern float D_800C233C_de;
extern float D_800C233C_eu;
extern float D_800C2340_de;
extern float D_800C2340_eu;
extern float D_800C2344_eu;
extern float D_800C2348_eu;
extern float D_800C234C_eu;
extern float D_800C2350_eu;
extern float D_800C2354_eu;
extern float D_800C2358_eu;
extern float D_800C235C_eu;
extern float D_800C2380_eu;
extern float D_800C2384_de;
extern float D_800C2384_eu;
extern float D_800C2388_de;
extern float D_800C238C_de;
extern float D_800C2390_de;
extern float D_800C2394_de;
extern float D_800C2398_de;
extern float D_800C239C_de;
extern float D_800C23A0_de;
extern float D_800C23A4_de;
extern float D_800C23A8_de;
extern float D_800C23AC_de;
extern float D_800C23B0_de;
extern float D_800C23B0_eu_x;
extern float D_800C23BC_de;
extern float D_800C23C0_de;
extern float D_800C23C4_de;
extern float D_800C23C8_de;
extern float D_800C23CC_de;
extern float D_800C23D0_de;
extern float D_800C23D4_de;
extern float D_800C23D8_de;
extern float D_800C23DC_de;
extern float D_800C23E4_de;
extern float D_800C23E8_de;
extern float D_800C23EC;
extern float D_800C23F0_de;
extern float D_800C2594_de;
extern float D_800C2598_de;
extern float D_800C259C_de;
extern float D_800C25A0_de;
extern float D_800C25A4_de;
extern float D_800C25A8_de;
extern float D_800C25AC_de;
extern float D_800C25B0_de;
extern float D_800C25B4_de;
extern float D_800C25B8_de;
extern float D_800C25BC_de;
extern float D_800C25C0_de;
extern float D_800C25C4_de;
extern float D_800C25C8_de;
extern float D_800C25CC_de;
extern float D_800C25D0_de;
extern float D_800C25D4_de;
extern float D_800C25D8_de;
extern float D_800C25DC_de;
extern float D_800C25E0_de;
extern float D_800C25E4_de;
extern float D_800C25E8_de;
extern float D_800C25EC_de;
extern float D_800C25F0_de;
extern float D_800C25F4_de;
extern float D_800C25F8_de;
extern float D_800C2600_de;
extern float D_800C2604_de;
extern float D_800C2608_de;
extern float D_800C2608_eu;
extern float D_800C260C_de;
extern float D_800C2610_de;
extern float D_800C2614_de;
extern float D_800C2618_de;
extern float D_800C261C_de;
extern float D_800C2620_de;
extern float D_800C2624_de;
extern float D_800C2628_de;
extern float D_800C262C_de;
extern float D_800C2630_de;
extern float D_800C2634_de;
extern float D_800C2638_de;
extern float D_800C263C_de;
extern float D_800C2640_de;
extern float D_800C2644_de;
extern float D_800C2648_de;
extern float D_800C264C_de;
extern float D_800C2650_de;
extern float D_800C2654_de;
extern float D_800C2658_de;
extern float D_800C265C_de;
extern float D_800C2660_de;
extern float D_800C2664_de;
extern float D_800C2668_de;
extern float D_800C266C_de;
extern float D_800C2670_de;
extern float D_800C2674_de;
extern float D_800C2678_de;
extern float D_800C267C_de;
extern float D_800C2680_de;
extern float D_800C2684_de;
extern float D_800C2688_de;
extern float D_800C268C_de;
extern float D_800C2690_de;
extern float D_800C2694_de;
extern float D_800C2698_de;
extern float D_800C269C_de;
extern float D_800C26A0_de;
extern float D_800C26A4_de;
extern float D_800C26A8_de;
extern float D_800C26AC_de;
extern float D_800C26B0_de;
extern float D_800C26B4_de;
extern float D_800C26B8_de;
extern float D_800C26BC_de;
extern float D_800C26C0_de;
extern float D_800C26C4_de;
extern float D_800C26C8_de;
extern float D_800C26CC_de;
extern float D_800C26D0_de;
extern float D_800C26D4_de;
extern float D_800C26D8_de;
extern float D_800C26DC_de;
extern float D_800C26E0_de;
extern float D_800C26E4_de;
extern float D_800C26E8_de;
extern float D_800C26EC_de;
extern float D_800C26F0_de;
extern float D_800C26F4_de;
extern float D_800C26F8_de;
extern float D_800C26FC_de;
extern float D_800C2700_de;
extern float D_800C2704_de;
extern float D_800C2708_de;
extern float D_800C270C_de;
extern float D_800C2710_de;
extern float D_800C2714_de;
extern float D_800C2718_de;
extern float D_800C271C_de;
extern float D_800C2720_de;
extern float D_800C2724_de;
extern float D_800C2728_de;
extern float D_800C272C_de;
extern float D_800C2730_de;
extern float D_800C2734_de;
extern float D_800C2738_de;
extern float D_800C273C_de;
extern float D_800C2740_de;
extern float D_800C2744_de;
extern float D_800C2748_de;
extern float D_800C274C_de;
extern float D_800C2750_de;
extern float D_800C2754_de;
extern float D_800C2758_de;
extern float D_800C275C_de;
extern float D_800C2760_de;
extern float D_800C2764_de;
extern float D_800C2768_de;
extern float D_800C276C_de;
extern float D_800C2770_de;
extern float D_800C2778_de;
extern float D_800C277C_de;
extern float D_800C2780_de;
extern float D_800C2784_de;
extern float D_800C2788_de;
extern float D_800C278C_de;
extern float D_800C2790_de;
extern float D_800C2794_de;
extern float D_800C2798_de;
extern float D_800C279C_de;
extern float D_800C27A0_de;
extern float D_800C27A4_de;
extern float D_800C27A8_de;
extern float D_800C27AC_de;
extern float D_800C27B0_de;
extern float D_800C27B4_de;
extern float D_800C27B8_de;
extern float D_800C27BC_de;
extern float D_800C27C4_de;
extern float D_800C27D4_de;
extern float D_800C27D8_de;
extern float D_800C27DC_de;
extern float D_800C27E0_de;
extern float D_800C27E4_de;
extern float D_800C27E8_de;
extern float D_800C27EC_de;
extern float D_800C27F0_de;
extern float D_800C27F4_de;
extern float D_800C27F8_de;
extern float D_800C27FC_de;
extern float D_800C2800_de;
extern float D_800C2804_de;
extern float D_800C2808_de;
extern float D_800C280C_de;
extern float D_800C2810_de;
extern float D_800C2814_de;
extern float D_800C2818_de;
extern float D_800C281C_de;
extern float D_800C2820_de;
extern float D_800C2824_de;
extern float D_800C2828_de;
extern float D_800C2830_de;
extern float D_800C2834_de;
extern float D_800C283C_de;
extern float D_800C2840_de;
extern float D_800C2844_de;
extern float D_800C284C_de;
extern float D_800C2854_de;
extern float D_800C285C_de;
extern float D_800C2860_de;
extern float D_800C2864_de;
extern float D_800C2868_de;
extern float D_800C286C_de;
extern float D_800C2874_de;
extern float D_800C287C_de;
extern float D_800C2880_de;
extern float D_800C2884_de;
extern float D_800C2888_de;
extern float D_800C288C_de;
extern float D_800C2890_de;
extern float D_800C2894_de;
extern float D_800C2898_de;
extern float D_800C289C_de;
extern float D_800C28A0_de;
extern float D_800C28A4_de;
extern float D_800C28A8_de;
extern float D_800C28AC_de;
extern float D_800C28B0_de;
extern float D_800C28B4_de;
extern float D_800C28B8_de;
extern float D_800C28BC_de;
extern float D_800C28C0_de;
extern float D_800C28C4_de;
extern float D_800C28C8_de;
extern float D_800C28CC_de;
extern float D_800C28D0_de;
extern float D_800C28D4_de;
extern float D_800C28D8_de;
extern float D_800C28DC_de;
extern float D_800C28E0_de;
extern float D_800C28E4_de;
extern float D_800C28E8_de;
extern float D_800C28EC_de;
extern float D_800C28F0_de;
extern float D_800C28F4_de;
extern float D_800C28F8_de;
extern float D_800C28FC_de;
extern float D_800C2900_de;
extern float D_800C2904_de;
extern float D_800C2908_de;
extern float D_800C290C_de;
extern float D_800C2910_de;
extern float D_800C2914_de;
extern float D_800C2920_de;
extern float D_800C2924_de;
extern float D_800C2928_de;
extern float D_800C292C_de;
extern float D_800C2930_de;
extern float D_800C2934_de;
extern float D_800C2938_de;
extern float D_800C293C_de;
extern float D_800C2940_de;
extern float D_800C2944_de;
extern float D_800C294C_de;
extern float D_800C2964_de;
extern float D_800C296C_de;
extern float D_800C29A0_de;
extern float D_800C29A4_de;
extern float D_800C29A8_de;
extern float D_800C29AC_de;
extern float D_800C29B0_de;
extern float D_800C29B4_de;
extern float D_800C29B8_de;
extern float D_800C29BC_de;
extern float D_800C29C0_de;
extern float D_800C29C4_de;
extern float D_800C29C8_de;
extern float D_800C29CC_de;
extern float D_800C29D0_de;
extern float D_800C29D4_de;
extern float D_800C29D8_de;
extern float D_800C29DC_de;
extern float D_800C29E0_de;
extern float D_800C29E4_de;
extern float D_800C29E8_de;
extern float D_800C29EC_de;
extern float D_800C29F0_de;
extern float D_800C29F4_de;
extern float D_800C29F8_de;
extern float D_800C29FC_de;
extern float D_800C2A00_de;
extern float D_800C2A04_de;
extern float D_800C2A08_de;
extern float D_800C2A0C_de;
extern float D_800C2A10_de;
extern float D_800C2A14_de;
extern float D_800C2A18_de;
extern float D_800C2A1C_de;
extern float D_800C2A20_de;
extern float D_800C2A24_de;
extern float D_800C2A28_de;
extern float D_800C2A2C_de;
extern float D_800C2A30_de;
extern float D_800C2A34_de;
extern float D_800C2A38_de;
extern float D_800C2A3C_de;
extern float D_800C2A40_de;
extern float D_800C2A44_de;
extern float D_800C2A48_de;
extern float D_800C2A4C_de;
extern float D_800C2A50_de;
extern float D_800C2A54_de;
extern float D_800C2A58_de;
extern float D_800C2A5C_de;
extern float D_800C2A60_de;
extern float D_800C2A6C_de;
extern float D_800C2A70_de;
extern float D_800C2A74_de;
extern float D_800C2A78_de;
extern float D_800C2A7C_de;
extern float D_800C2A80_de;
extern float D_800C2A84_de;
extern float D_800C2A88_de;
extern float D_800C2A8C_de;
extern float D_800C2A90_de;
extern float D_800C2A94_de;
extern float D_800C2A98_de;
extern float D_800C2A9C_de;
extern float D_800C2AA0_de;
extern float D_800C2AA4_de;
extern float D_800C2AA8_de;
extern float D_800C2AAC_de;
extern float D_800C2AB0_de;
extern float D_800C2AB4_de;
extern float D_800C2AB8_de;
extern float D_800C2ABC_de;
extern float D_800C2AC0_de;
extern float D_800C2AC4_de;
extern float D_800C2AC8_de;
extern float D_800C2ACC_de;
extern float D_800C2AD0_de;
extern float D_800C2AD4_de;
extern float D_800C2AD8_de;
extern float D_800C2ADC_de;
extern float D_800C2AE0_de;
extern float D_800C2AE4_de;
extern float D_800C2AE8_de;
extern float D_800C2AEC_de;
extern float D_800C2AF0_de;
extern float D_800C2AF4_de;
extern float D_800C2AF8_de;
extern float D_800C2AFC_de;
extern float D_800C2B00_de;
extern float D_800C2B04_de;
extern float D_800C2B08_de;
extern float D_800C2B0C_de;
extern float D_800C2B10_de;
extern float D_800C2B14_de;
extern float D_800C2B18_de;
extern float D_800C2B1C_de;
extern float D_800C2B20_de;
extern float D_800C2B24_de;
extern float D_800C2B28_de;
extern float D_800C2B2C_de;
extern float D_800C2B30_de;
extern float D_800C2B34_de;
extern float D_800C2B38_de;
extern float D_800C2B3C_de;
extern float D_800C2B40_de;
extern float D_800C2B44_de;
extern float D_800C2B4C_de;
extern float D_800C2B70_de;
extern float D_800C2B74_de;
extern float D_800C2B78_de;
extern float D_800C2BE4_de;
extern float D_800C2BFC_de;
extern float D_800C2C04_de;
extern float D_800C2C0C_de;
extern float D_800C2C14_de;
extern float D_800C2C18_de;
extern float D_800C2C1C_de;
extern float D_800C2C20_de;
extern float D_800C2C24_de;
extern float D_800C2C28_de;
extern float D_800C2C2C_de;
extern float D_800C2C30_de;
extern float D_800C2C34_de;
extern float D_800C2C38_de;
extern float D_800C2C3C_de;
extern float D_800C2C44_de;
extern float D_800C2C58_de;
extern float D_800C2CC4_de;
extern float D_800C2CC8_de;
extern float D_800C2CCC_de;
extern float D_800C2CD0_de;
extern float D_800C2CD4_de;
extern float D_800C2CD8_de;
extern float D_800C2CDC_de;
extern float D_800C2CE4_de;
extern float D_800C2CEC_de;
extern float D_800C2CF0_de;
extern float D_800C2CF4_de;
extern float D_800C2CF8_de;
extern float D_800C2CFC_de;
extern float D_800C2D14_de;
extern float D_800C2D20_de;
extern float D_800C2D24_de;
extern float D_800C2D40_de;
extern float D_800C2D44_de;
extern float D_800C2D48_de;
extern float D_800C2D4C_de;
extern float D_800C2D50_de;
extern float D_800C2D54_de;
extern float D_800C2D58_de;
extern float D_800C2D64_de;
extern float D_800C2D68_de;
extern float D_800C2D6C_de;
extern float D_800C2D70_de;
extern float D_800C2D74_de;
extern float D_800C2D7C_de;
extern float D_800C2D9C_de;
extern float D_800C2DB4_de;
extern float D_800C2DD4_de;
extern float D_800C2DDC_de;
extern float D_800C2DE4_de;
extern float D_800C2DEC_de;
extern float D_800C2DF4_de;
extern float D_800C2DFC_de;
extern float D_800C2E14_de;
extern float D_800C2E1C_de;
extern float D_800C2EE0_de;
extern float D_800C2EE4_de;
extern float D_800C2EE8_de;
extern float D_800C2EEC_de;
extern float D_800C2EF0_de;
extern float D_800C2EF4_de;
extern float D_800C2EF8_de;
extern float D_800C2EFC_de;
extern float D_800C2F00_de;
extern float D_800C2F00_eu;
extern float D_800C2F04_de;
extern float D_800C2F04_eu;
extern float D_800C2F08_de;
extern float D_800C2F08_eu;
extern float D_800C2F0C_de;
extern float D_800C2F0C_eu;
extern float D_800C2F10_de;
extern float D_800C2F10_eu;
extern float D_800C2F14_eu;
extern float D_800C2F18_eu;
extern float D_800C2F1C_de;
extern float D_800C2F1C_eu;
extern float D_800C2F20_eu;
extern float D_800C2F24_de;
extern float D_800C2F28_de;
extern float D_800C2F2C_de;
extern float D_800C2F30_de;
extern float D_800C2F34_de;
extern float D_800C2F38_de;
extern float D_800C2F3C_de;
extern float D_800C2F40_de;
extern float D_800C2F44_de;
extern float D_800C2F48_de;
extern float D_800C2F4C_de;
extern float D_800C2F50_de;
extern float D_800C2F54_de;
extern float D_800C2F58_de;
extern float D_800C2F64_de;
extern float D_800C2F68_de;
extern float D_800C2F6C_de;
extern float D_800C2F70_de;
extern float D_800C2F74_de;
extern float D_800C2F78_de;
extern float D_800C2F7C_de;
extern float D_800C2F80_de;
extern float D_800C2F84_de;
extern float D_800C2F88_de;
extern float D_800C2F8C_de;
extern float D_800C2F90_de;
extern float D_800C2F94_de;
extern float D_800C2F98_de;
extern float D_800C2F9C_de;
extern float D_800C2FA0_de;
extern float D_800C2FA4_de;
extern float D_800C2FA8_de;
extern float D_800C2FAC_de;
extern float D_800C2FB8_de;
extern float D_800C2FCC_de;
extern float D_800C2FD0_de;
extern float D_800C3014_de;
extern float D_800C3024_de;
extern float D_800C3034_de;
extern float D_800C3044_de;
extern float D_800C304C_de;
extern float D_800C306C_de;
extern float D_800C30A0_de;
extern float D_800C30A4_de;
extern float D_800C30A8_de;
extern float D_800C30AC_de;
extern float D_800C30B0_de;
extern double D_800C30B8_de;
extern float D_800C30C0_de;
extern float D_800C30C4_de;
extern float D_800C30C8_de;
extern float D_800C30CC_de;
extern float D_800C30D0_de;
extern float D_800C30D4_de;
extern float D_800C30D8_de;
extern float D_800C30DC_de;
extern float D_800C30E0_de;
extern double D_800C30E8_de;
extern float D_800C30F0_de;
extern double D_800C30F8_de;
extern double D_800C3100_de;
extern float D_800C3108_de;
extern float D_800C310C_de;
extern float D_800C3110_de;
extern float D_800C3114_de;
extern double D_800C3118_de;
extern float D_800C3120_de;
extern float D_800C3124_de;
extern float D_800C3128_de;
extern float D_800C312C_de;
extern double D_800C3130_de;
extern float D_800C3138_de;
extern float D_800C313C_de;
extern float D_800C3140_de;
extern float D_800C3144_de;
extern double D_800C3148_de;
extern float D_800C3150_de;
extern float D_800C3154_de;
extern float D_800C3158_de;
extern float D_800C315C_de;
extern float D_800C3168_de;
extern float D_800C316C_de;
extern float D_800C3170_de;
extern float D_800C3174_de;
extern float D_800C3178_de;
extern float D_800C317C_de;
extern double D_800C3180_de;
extern double D_800C3188_de;
extern double D_800C3190_de;
extern float D_800C3198_de;
extern double D_800C31A0_de;
extern double D_800C31A8_de;
extern double D_800C31B0_de;
extern double D_800C31B8_de;
extern double D_800C31C0_de;
extern double D_800C31C8_de;
extern float D_800C31D0_de;
extern double D_800C31D8_de;
extern double D_800C31E0_de;
extern double D_800C31E8_de;
extern float D_800C31F0_de;
extern float D_800C31F4_de;
extern float D_800C31F8_de;
extern float D_800C31FC_de;
extern float D_800C3204_de;
extern float D_800C320C_de;
extern float D_800C3210_de;
extern float D_800C3214_de;
extern float D_800C3218_de;
extern float D_800C321C_de;
extern float D_800C3220_de;
extern float D_800C3224_de;
extern float D_800C3228_de;
extern float D_800C322C_de;
extern float D_800C3230_de;
extern float D_800C3234_de;
extern float D_800C3238_de;
extern float D_800C323C_de;
extern float D_800C3240_de;
extern float D_800C3244_de;
extern float D_800C3248_de;
extern float D_800C324C_de;
extern float D_800C3250_de;
extern float D_800C3254_de;
extern float D_800C3258_de;
extern float D_800C325C_de;
extern float D_800C3260_de;
extern float D_800C3264_de;
extern float D_800C3268_de;
extern float D_800C326C_de;
extern float D_800C3270_de;
extern float D_800C3274_de;
extern float D_800C3278_de;
extern float D_800C327C_de;
extern float D_800C3280_de;
extern float D_800C3284_de;
extern float D_800C3288_de;
extern float D_800C328C_de;
extern float D_800C3298_de;
extern float D_800C329C_de;
extern float D_800C32A0_de;
extern float D_800C32A4_de;
extern float D_800C32A8_de;
extern float D_800C32AC_de;
extern float D_800C32B0_de;
extern float D_800C32B4_de;
extern float D_800C32B8_de;
extern float D_800C32BC_de;
extern float D_800C32C0_de;
extern float D_800C32C4_de;
extern float D_800C32C8_de;
extern float D_800C32CC_de;
extern float D_800C32EC_de;
extern float D_800C32F0_de;
extern float D_800C32FC_de;
extern float D_800C3308_de;
extern float D_800C3314_de;
extern float D_800C3320_de;
extern float D_800C3328_de;
extern float D_800C332C_de;
extern float D_800C3330_de;
extern float D_800C3334_de;
extern float D_800C3338_de;
extern float D_800C333C_de;
extern float D_800C3340_de;
extern float D_800C3344_de;
extern float D_800C3348_de;
extern float D_800C334C_de;
extern float D_800C3350_de;
extern float D_800C3354_de;
extern float D_800C3358_de;
extern float D_800C335C_de;
extern float D_800C3360_de;
extern float D_800C3364_de;
extern float D_800C3368_de;
extern float D_800C336C_de;
extern float D_800C3370_de;
extern float D_800C3374_de;
extern float D_800C3378_de;
extern float D_800C337C_de;
extern float D_800C3380_de;
extern float D_800C3384_de;
extern float D_800C3388_de;
extern float D_800C338C_de;
extern float D_800C3390_de;
extern float D_800C3394_de;
extern float D_800C3398_de;
extern float D_800C339C_de;
extern float D_800C33A0_de;
extern float D_800C33A4_de;
extern float D_800C33A8_de;
extern float D_800C33AC;
extern float D_800C33B0_de;
extern float D_800C33B4_de;
extern float D_800C33B8_de;
extern float D_800C33BC_de;
extern float D_800C33C0_de;
extern float D_800C33C4_de;
extern float D_800C33C8_de;
extern float D_800C33CC_de;
extern float D_800C33D0_de;
extern float D_800C33D4_de;
extern float D_800C33D8_de;
extern float D_800C33DC_de;
extern float D_800C33E0_de;
extern float D_800C33E4_de;
extern float D_800C33E8_de;
extern float D_800C33EC_de;
extern float D_800C33F0_de;
extern float D_800C33F4_de;
extern float D_800C33F8_de;
extern float D_800C33FC_de;
extern float D_800C3400_de;
extern float D_800C3404_de;
extern float D_800C3408_de;
extern float D_800C340C_de;
extern float D_800C3410_de;
extern float D_800C3414_de;
extern float D_800C3418_de;
extern float D_800C341C_de;
extern float D_800C3420_de;
extern float D_800C3424_de;
extern float D_800C3428_de;
extern float D_800C342C_de;
extern float D_800C3430_de;
extern float D_800C3434_de;
extern float D_800C3438_de;
extern float D_800C343C_de;
extern float D_800C3440_de;
extern float D_800C3444_de;
extern float D_800C3448_de;
extern int D_800C344C_de;
extern int D_800C3468_de;
extern float D_800C34D8_de;
extern float D_800C34DC_de;
extern float D_800C34E0_de;
extern float D_800C34E4_de;
extern float D_800C34E8_de;
extern float D_800C34EC_de;
extern float D_800C34F0_de;
extern float D_800C34F4_de;
extern float D_800C34F8_de;
extern float D_800C34FC_de;
extern float D_800C3500_de;
extern float D_800C3504_de;
extern float D_800C3508_de;
extern float D_800C350C_de;
extern float D_800C3510_de;
extern float D_800C3514_de;
extern float D_800C351C_de;
extern float D_800C3534_de;
extern float D_800C353C_de;
extern float D_800C3544_de;
extern float D_800C3558_de;
extern float D_800C355C_de;
extern float D_800C3560_de;
extern float D_800C3564_de;
extern float D_800C357C_de;
extern float D_800C35A4_de;
extern float D_800C35A8_de;
extern float D_800C35B0_de;
extern float D_800C35B4_de;
extern float D_800C35B8_de;
extern float D_800C35BC_de;
extern float D_800C35C0_de;
extern float D_800C35C4_de;
extern float D_800C35C8_de;
extern float D_800C35CC_de;
extern float D_800C35D0_de;
extern float D_800C35D4_de;
extern float D_800C35D8_de;
extern float D_800C35DC_de;
extern float D_800C35E0_de;
extern float D_800C35E4_de;
extern float D_800C35E8_de;
extern float D_800C35EC_de;
extern float D_800C35FC_de;
extern float D_800C3610_de;
extern float D_800C3614_de;
extern float D_800C3618_de;
extern float D_800C361C_de;
extern float D_800C3620_de;
extern float D_800C3624_de;
extern float D_800C3628_de;
extern float D_800C362C_de;
extern float D_800C3634_de;
extern float D_800C3638_de;
extern float D_800C363C_de;
extern float D_800C3640_de;
extern float D_800C3644_de;
extern float D_800C3648_de;
extern float D_800C3694_de;
extern float D_800C3698_de;
extern float D_800C36C8_de;
extern float D_800C36CC_de;
extern float D_800C36D4_de;
extern float D_800C36E0_de;
extern float D_800C36E4_de;
extern float D_800C371C_de;
extern float D_800C3720_de;
extern float D_800C3730_de;
extern float D_800C3734_de;
extern float D_800C3738_de;
extern float D_800C3750_de;
extern float D_800C3754_de;
extern float D_800C375C_de;
extern float D_800C3770;
extern float D_800C3774_de;
extern float D_800C3778;
extern float D_800C3780;
extern float D_800C3790_de;
extern float D_800C3794_de;
extern float D_800C3798_de;
extern float D_800C37A0_de;
extern float D_800C37A4_de;
extern float D_800C37A8_de;
extern float D_800C37B4_de;
extern float D_800C37B8_de;
extern float D_800C37BC_de;
extern float D_800C37C0_de;
extern float D_800C37C4_de;
extern float D_800C37C8_de;
extern float D_800C37CC_de;
extern float D_800C37F0_de;
extern float D_800C37F4_de;
extern float D_800C37F8_de;
extern float D_800C37FC_de;
extern float D_800C3800_de;
extern float D_800C3804_de;
extern float D_800C3808_de;
extern float D_800C380C_de;
extern float D_800C3810_de;
extern float D_800C3814_de;
extern float D_800C3818_de;
extern float D_800C381C_de;
extern float D_800C3820_de;
extern float D_800C392C_de;
extern float D_800C394C_de;
extern float D_800C3958;
extern float D_800C395C;
extern float D_800C3960_de;
extern float D_800C3964_de;
extern float D_800C3968_de;
extern float D_800C396C_de;
extern float D_800C3970_de;
extern float D_800C3974_de;
extern float D_800C3978_de;
extern float D_800C397C_de;
extern float D_800C3980_de;
extern float D_800C3984_de;
extern float D_800C3988_de;
extern float D_800C398C_de;
extern float D_800C3990_de;
extern float D_800C3994_de;
extern float D_800C3998_de;
extern float D_800C39A0_de;
extern float D_800C39A4_de;
extern float D_800C39A8_de;
extern float D_800C39AC_de;
extern float D_800C39B0_de;
extern float D_800C39B4_de;
extern float D_800C39B8_de;
extern float D_800C39BC_de;
extern float D_800C39C0_de;
extern float D_800C39C4_de;
extern float D_800C39C8_de;
extern float D_800C39CC_de;
extern float D_800C39D0_de;
extern float D_800C39D4_de;
extern float D_800C39D8_de;
extern float D_800C39DC_de;
extern float D_800C3A4C_de;
extern float D_800C3A54_de;
extern float D_800C3A5C_de;
extern float D_800C3A74_de;
extern float D_800C3A78_de;
extern float D_800C3A7C_de;
extern float D_800C3A80_de;
extern float D_800C3A84_de;
extern float D_800C3A88_de;
extern float D_800C3A8C_de;
extern float D_800C3A90_de;
extern float D_800C3A94_de;
extern float D_800C3A98_de;
extern float D_800C3A9C_de;
extern float D_800C3AA0_de;
extern float D_800C3AA4_de;
extern float D_800C3AA8_de;
extern float D_800C3AAC_de;
extern float D_800C3AB0_de;
extern float D_800C3AB4_de;
extern float D_800C3AB8_de;
extern float D_800C3ABC_de;
extern float D_800C3AC0_de;
extern float D_800C3AC4_de;
extern float D_800C3AC8_de;
extern float D_800C3ACC_de;
extern float D_800C3AD0_de;
extern float D_800C3AD4_de;
extern float D_800C3AD8_de;
extern float D_800C3ADC_de;
extern float D_800C3AE0_de;
extern float D_800C3AE4_de;
extern float D_800C3B4C_de;
extern float D_800C3B50;
extern float D_800C3B58;
extern float D_800C3B5C;
extern float D_800C3B64_de;
extern float D_800C3B68_de;
extern float D_800C3B6C_de;
extern float D_800C3B70;
extern float D_800C3B7C;
extern float D_800C3B84;
extern float D_800C3B8C_de;
extern float D_800C3B94;
extern float D_800C3B9C;
extern float D_800C3BA4_de;
extern float D_800C3BAC_de;
extern float D_800C3C84_de;
extern float D_800C3C88_de;
extern float D_800C3C8C_de;
extern float D_800C3C90_de;
extern float D_800C3C94_de;
extern float D_800C3CA4_de;
extern float D_800C3CA8_de;
extern float D_800C3CAC_de;
extern float D_800C3CB0_de;
extern float D_800C3CB4_de;
extern float D_800C3CB8_de;
extern float D_800C3CBC_de;
extern float D_800C3CC4_de;
extern float D_800C3CC8_de;
extern float D_800C3CCC_de;
extern float D_800C3CD4_de;
extern float D_800C3D80_de;
extern float D_800C3D84_de;
extern float D_800C3D88_de;
extern float D_800C3D8C_de;
extern float D_800C3D94_de;
extern float D_800C3D9C_de;
extern float D_800C3DA0_de;
extern float D_800C3DA4_de;
extern float D_800C3DF4;
extern float D_800C3E04_de;
extern float D_800C3E54_de;
extern double D_800C3EB0_de;
extern float D_800C3EB8_de;
extern double D_800C3EC0_de;
extern float D_800C3ED0_de;
extern float D_800C3ED4;
extern float D_800C3ED8_de;
extern float D_800C3EDC_de;
extern float D_800C3EE4_de;
extern float D_800C3EF8;
extern float D_800C3F04_de;
extern float D_800C3F0C_de;
extern float D_800C3F10_de;
extern float D_800C3F14_de;
extern float D_800C3F18_de;
extern float D_800C3F1C_de;
extern float D_800C3F20_de;
extern float D_800C3F24_de;
extern float D_800C3F28_de;
extern float D_800C3F2C_de;
extern float D_800C3F30_de;
extern float D_800C3F38_de;
extern float D_800C3F3C_de;
extern float D_800C3F40_de;
extern float D_800C3F44_de;
extern float D_800C3F48_de;
extern float D_800C3F5C_de;
extern float D_800C3F60_de;
extern float D_800C3F64_de;
extern float D_800C3F6C_de;
extern float D_800C3F70_de;
extern float D_800C3F74_de;
extern float D_800C3F7C_de;
extern float D_800C3F8C_de;
extern float D_800C3F94_de;
extern float D_800C3F9C_de;
extern double D_800C3FA0_de;
extern float D_800C3FA8_de;
extern float D_800C3FAC_de;
extern float D_800C3FB4_de;
extern float D_800C3FD4;
extern float D_800C3FDC;
extern float D_800C3FF4;
extern float D_800C3FF8_de;
extern float D_800C3FFC_de;
extern float D_800C4004;
extern float D_800C400C;
extern float D_800C4010_de;
extern float D_800C4014;
extern float D_800C4024_de;
extern float D_800C402C;
extern float D_800C4034_de;
extern double D_800C4040_de;
extern double D_800C4048_de;
extern double D_800C4050_de;
extern double D_800C4058_de;
extern double D_800C4060_de;
extern double D_800C4068_de;
extern double D_800C4070_de;
extern double D_800C4078_de;
extern double D_800C4080_de;
extern double D_800C4088_de;
extern float D_800C4090_de;
extern float D_800C4094_de;
extern float D_800C4098_de;
extern double D_800C40A0_de;
extern double D_800C40A8_de;
extern double D_800C40B0_de;
extern double D_800C40B8_de;
extern double D_800C40C0_de;
extern float D_800C40C0_eu;
extern float D_800C40C4_eu;
extern float D_800C40C8_de;
extern float D_800C40C8_eu;
extern float D_800C40CC_eu;
extern double D_800C40D0_de;
extern float D_800C40D0_eu;
extern float D_800C40D4_eu;
extern double D_800C40D8_de;
extern float D_800C40D8_eu;
extern float D_800C40DC_eu;
extern double D_800C40E0_de;
extern float D_800C40E0_eu;
extern float D_800C40E4_eu;
extern double D_800C40E8_de;
extern float D_800C40E8_eu;
extern float D_800C40EC_eu;
extern double D_800C40F0_de;
extern float D_800C410C_de;
extern float D_800C4114_de;
extern float D_800C411C_de;
extern float D_800C4120_de;
extern float D_800C4124_de;
extern float D_800C4128_de;
extern float D_800C412C_de;
extern float D_800C4130_de;
extern float D_800C4134;
extern double D_800C4138_de;
extern float D_800C4140_de;
extern float D_800C4144_de;
extern double D_800C4148_de;
extern double D_800C4150_de;
extern float D_800C4158_de;
extern double D_800C4160_de;
extern float D_800C416C_de;
extern float D_800C4178_de;
extern float D_800C419C;
extern float D_800C41AC_de;
extern float D_800C41BC_de;
extern float D_800C41C0_de;
extern double D_800C41C8_de;
extern double D_800C41D0_de;
extern double D_800C41D8_de;
extern double D_800C41E0_de;
extern double D_800C41E8_de;
extern float D_800C41F0_de;
extern float D_800C41F4_de;
extern float D_800C41F8_de;
extern float D_800C41FC_de;
extern double D_800C4200_de;
extern double D_800C4208_de;
extern double D_800C4210_de;
extern double D_800C4218_de;
extern double D_800C4220_de;
extern float D_800C4228_de;
extern double D_800C4230_de;
extern double D_800C4238_de;
extern double D_800C4240_de;
extern double D_800C4248_de;
extern double D_800C4250_de;
extern float D_800C4290_de;
extern float D_800C4294_de;
extern float D_800C4298_de;
extern float D_800C429C_de;
extern float D_800C42A0_de;
extern float D_800C42AC_de;
extern float D_800C42B8_de;
extern float D_800C42BC_de;
extern float D_800C42C8_de;
extern float D_800C42D4_de;
extern float D_800C42D8_de;
extern float D_800C42DC_de;
extern float D_800C42E0_de;
extern float D_800C42E4_de;
extern float D_800C42E8_de;
extern float D_800C42F0_de;
extern float D_800C42F4_de;
extern float D_800C42F8_de;
extern float D_800C42FC_de;
extern float D_800C4300_de;
extern float D_800C4304_de;
extern float D_800C431C_de;
extern float D_800C4320_de;
extern float D_800C43A4_de;
extern float D_800C43B0_de;
extern float D_800C43C0_de;
extern float D_800C43C4_de;
extern float D_800C43C8_de;
extern float D_800C43CC_de;
extern float D_800C43D0_de;
extern struct Node_func_80285B64_de * * D_800C43D4_de;
extern float D_800C43DC_de;
extern float D_800C43E0_de;
extern float D_800C43E4_de;
extern float D_800C43E8_de;
extern float D_800C43EC;
extern float D_800C43F0_de;
extern float D_800C43F4_de;
extern float D_800C43F8_de;
extern float D_800C4434_de;
extern float D_800C443C;
extern float D_800C4444;
extern struct Node_func_80285B64_de * * D_800C444C_de;
extern float D_800C4454_de;
extern float D_800C445C_de;
extern float D_800C4464;
extern float D_800C4478_de;
extern float D_800C447C;
extern float D_800C4484;
extern float D_800C4498_de;
extern float D_800C45C4_de;
extern float D_800C45C8_de;
extern float D_800C45CC_de;
extern float D_800C45D0_de;
extern float D_800C45D4_de;
extern float D_800C45D8_de;
extern float D_800C45DC_de;
extern float D_800C45E0_de;
extern float D_800C4608_de;
extern float D_800C460C_de;
extern float D_800C4610_de;
extern float D_800C4614_de;
extern float D_800C4638_de;
extern float D_800C463C_de;
extern float D_800C4640_de;
extern float D_800C4644_de;
extern float D_800C46AC_eu;
extern float D_800C46B0_eu;
extern float D_800C46B4_eu;
extern float D_800C46B8_eu;
extern float D_800C46BC_eu;
extern float D_800C46C0_eu;
extern int D_800C46C4_de;
extern float D_800C46C4_eu;
extern float D_800C46C8_eu;
extern float D_800C46CC_eu;
extern float D_800C46D0_de;
extern float D_800C46D4_de;
extern float D_800C46D8_de;
extern float D_800C46DC_de;
extern float D_800C46E0_de;
extern float D_800C46E4_de;
extern float D_800C46E8_de;
extern float D_800C46F4_de;
extern float D_800C46FC_de;
extern float D_800C4704_de;
extern float D_800C470C_de;
extern float D_800C4714_de;
extern float D_800C471C_de;
extern float D_800C4724_de;
extern float D_800C472C_de;
extern float D_800C4734_de;
extern float D_800C473C_de;
extern float D_800C4744_de;
extern float D_800C474C_de;
extern float D_800C4754_de;
extern float D_800C475C_de;
extern float D_800C4764_de;
extern float D_800C476C_de;
extern float D_800C4774_de;
extern float D_800C477C_de;
extern float D_800C4784_de;
extern float D_800C478C_de;
extern float D_800C4794_de;
extern float D_800C479C_de;
extern float D_800C47A4_de;
extern float D_800C47AC_de;
extern float D_800C47B4_de;
extern float D_800C47BC_de;
extern float D_800C47C4_de;
extern float D_800C47CC_de;
extern float D_800C47DC_de;
extern float D_800C47E4_de;
extern float D_800C47F4_de;
extern float D_800C47FC_de;
extern float D_800C4804_de;
extern float D_800C480C_de;
extern float D_800C4814_de;
extern float D_800C481C_de;
extern float D_800C4838_de;
extern float D_800C483C_de;
extern float D_800C4840_de;
extern float D_800C4844_de;
extern float D_800C484C_de;
extern float D_800C4854_de;
extern float D_800C485C_de;
extern float D_800C4864_de;
extern float D_800C487C_de;
extern float D_800C4884_de;
extern float D_800C489C_de;
extern float D_800C48A4_de;
extern float D_800C48AC_de;
extern float D_800C48B4_de;
extern float D_800C48BC_de;
extern float D_800C48C4_de;
extern float D_800C48CC_de;
extern float D_800C48D4_de;
extern float D_800C48E4_de;
extern float D_800C48FC_de;
extern float D_800C4904_de;
extern float D_800C490C_de;
extern float D_800C491C_de;
extern float D_800C4924_de;
extern float D_800C492C_de;
extern float D_800C4934_de;
extern float D_800C4938_de;
extern float D_800C493C;
extern float D_800C494C_de;
extern float D_800C4950_de;
extern float D_800C4954_de;
extern float D_800C4958_de;
extern float D_800C495C_de;
extern float D_800C4964_de;
extern float D_800C496C_de;
extern float D_800C4974_de;
extern float D_800C497C_de;
extern float D_800C4984_de;
extern float D_800C498C_de;
extern float D_800C4994_de;
extern float D_800C49A4_de;
extern float D_800C49AC_de;
extern float D_800C49D4_de;
extern float D_800C49DC_de;
extern float D_800C4A10_de;
extern float D_800C4A14_de;
extern float D_800C4A18_de;
extern float D_800C4A1C_de;
extern float D_800C4A20_de;
extern float D_800C4A24_de;
extern float D_800C4A28_de;
extern float D_800C4A2C_de;
extern float D_800C4A30_de;
extern float D_800C4A34_de;
extern float D_800C4A38_de;
extern float D_800C4A3C_de;
extern float D_800C4A40_de;
extern float D_800C4A44_de;
extern float D_800C4A48_de;
extern float D_800C4A4C_de;
extern float D_800C4A50_de;
extern float D_800C4A54_de;
extern float D_800C4A60_de;
extern float D_800C4A64_de;
extern float D_800C4A68_de;
extern float D_800C4A6C_de;
extern float D_800C4A70_de;
extern float D_800C4A74_de;
extern float D_800C4A78_de;
extern float D_800C4A7C_de;
extern float D_800C4A80_de;
extern float D_800C4A84_de;
extern float D_800C4A88_de;
extern float D_800C4A8C_de;
extern double D_800C4A90_de;
extern float D_800C4A98_de;
extern double D_800C4AA0_de;
extern double D_800C4AA8_de;
extern float D_800C4AB0_de;
extern float D_800C4AB4_de;
extern float D_800C4AB8_de;
extern float D_800C4ABC_de;
extern float D_800C4ADC_de;
extern float D_800C4AE0_de;
extern float D_800C4AE4_de;
extern float D_800C4AE8_de;
extern float D_800C4AEC_de;
extern float D_800C4AF0_de;
extern float D_800C4AF4_de;
extern double D_800C4AF8_de;
extern float D_800C4B00_de;
extern float D_800C4B04_de;
extern double D_800C4B08_de;
extern float D_800C4B10_de;
extern float D_800C4B14_de;
extern float D_800C4B18_de;
extern float D_800C4B30_de;
extern float D_800C4B40_de;
extern float D_800C4B44_de;
extern float D_800C4B48_de;
extern float D_800C4B4C_de;
extern float D_800C4B50_de;
extern float D_800C4B54_de;
extern float D_800C4B58_de;
extern float D_800C4B5C_de;
extern float D_800C4B60_de;
extern float D_800C4B64_de;
extern float D_800C4B68_de;
extern float D_800C4B6C_de;
extern float D_800C4B70_de;
extern float D_800C4B74_de;
extern float D_800C4B78_de;
extern float D_800C4B7C_de;
extern float D_800C4B80_de;
extern float D_800C4B84_de;
extern float D_800C4B88_de;
extern float D_800C4B8C_de;
extern float D_800C4B90_de;
extern float D_800C4B94_de;
extern float D_800C4B98_de;
extern float D_800C4B9C_de;
extern float D_800C4BA0_de;
extern float D_800C4BA4_de;
extern float D_800C4BA8_de;
extern float D_800C4BAC_de;
extern float D_800C4BB0_de;
extern float D_800C4BB4_de;
extern float D_800C4BB8_de;
extern float D_800C4BBC_de;
extern float D_800C4BC0_de;
extern float D_800C4BC4_de;
extern float D_800C4BC8_de;
extern float D_800C4BD0_de;
extern float D_800C4BD4_de;
extern float D_800C4BD8_de;
extern float D_800C4BDC_de;
extern float D_800C4BE4_de;
extern float D_800C4BE8_de;
extern float D_800C4BEC_de;
extern float D_800C4BF0_de;
extern float D_800C4BF4_de;
extern float D_800C4BF8_de;
extern float D_800C4BFC_de;
extern float D_800C4C00_de;
extern float D_800C4C04_de;
extern float D_800C4C08_de;
extern float D_800C4C0C_de;
extern float D_800C4C68_de;
extern float D_800C4C6C_de;
extern float D_800C4C70_de;
extern float D_800C4C74_de;
extern float D_800C4C78_de;
extern float D_800C4C7C_de;
extern float D_800C4C80_de;
extern float D_800C4C84_de;
extern float D_800C4C88_de;
extern float D_800C4C8C_de;
extern float D_800C4C90_de;
extern float D_800C4C94_de;
extern float D_800C4C9C_de;
extern float D_800C4CA0_de;
extern float D_800C4CA4_de;
extern float D_800C4CE8_de;
extern float D_800C4CEC_de;
extern float D_800C4CF0_de;
extern float D_800C4CF4_de;
extern float D_800C4CF8_de;
extern float D_800C4CFC_de;
extern float D_800C4D00_de;
extern float D_800C4D04_de;
extern float D_800C4D08_de;
extern float D_800C4D0C_de;
extern float D_800C4D10_de;
extern float D_800C4D14_de;
extern float D_800C4D1C_de;
extern float D_800C4D20_de;
extern float D_800C4D24_de;
extern float D_800C4D28_de;
extern float D_800C4D2C_de;
extern float D_800C4D30_de;
extern float D_800C4D34_de;
extern float D_800C4D78_de;
extern float D_800C4D7C_de;
extern float D_800C4D80_de;
extern float D_800C4D84_de;
extern float D_800C4D88_de;
extern float D_800C4D8C_de;
extern float D_800C4D90_de;
extern float D_800C4D94_de;
extern float D_800C4D98_de;
extern float D_800C4D9C_de;
extern float D_800C4DA0_de;
extern float D_800C4DA4_de;
extern float D_800C4DA8_de;
extern float D_800C4DAC_de;
extern float D_800C4DB0_de;
extern float D_800C4DB4_de;
extern float D_800C4DD0_de;
extern float D_800C4DD4_de;
extern float D_800C4DD8_de;
extern float D_800C4DDC_de;
extern float D_800C4DE0_de;
extern float D_800C4DE4_de;
extern float D_800C4DE8_de;
extern float D_800C4DEC_de;
extern float D_800C4DF0_de;
extern float D_800C4DF4_de;
extern float D_800C4DF8_de;
extern float D_800C4DFC_de;
extern float D_800C4E00_de;
extern float D_800C4E04_de;
extern float D_800C4E08_de;
extern float D_800C4E0C_de;
extern float D_800C4E2C_de;
extern float D_800C4E30_de;
extern float D_800C4E38_de;
extern float D_800C4E3C_de;
extern float D_800C4E40_de;
extern float D_800C4E44_de;
extern float D_800C4E48_de;
extern float D_800C4E4C_de;
extern float D_800C4E50_de;
extern float D_800C4E54_de;
extern struct Node_func_80285B64_de * * D_800C4E5C_de;
extern float D_800C4E64_de;
extern float D_800C4E68_de;
extern float D_800C4E6C_de;
extern float D_800C4E70_de;
extern float D_800C4E74_de;
extern float D_800C4E78_de;
extern float D_800C4E7C_de;
extern float D_800C4E80_de;
extern float D_800C4E84_de;
extern float D_800C4E8C_de;
extern float D_800C4E94_de;
extern float D_800C4E98_de;
extern float D_800C4E9C_de;
extern float D_800C4EC0_de;
extern float D_800C4EC0_eu;
extern float D_800C4EC4_de;
extern float D_800C4EC4_eu;
extern float D_800C4EC8_eu;
extern float D_800C4ECC_de;
extern float D_800C4ECC_eu;
extern float D_800C4ED0_eu;
extern float D_800C4ED4_eu;
extern float D_800C4ED8_eu;
extern float D_800C4EDC_eu;
extern float D_800C4EE0_eu;
extern float D_800C4EE4_eu;
extern float D_800C50E4_de;
extern float D_800C50FC_de;
extern float D_800C51D4;
extern float D_800C51F4_de;
extern float D_800C51F8;
extern float D_800C5200_de;
extern float D_800C5204;
extern float D_800C5208;
extern float D_800C520C;
extern double D_800C5240_de;
extern float D_800C5248;
extern float D_800C524C;
extern float D_800C5250_de;
extern float D_800C5254_de;
extern float D_800C5258;
extern float D_800C525C;
extern float D_800C5260_de;
extern float D_800C5264_de;
extern float D_800C5268_de;
extern float D_800C526C_de;
extern float D_800C5270_de;
extern float D_800C5274_de;
extern float D_800C5278_de;
extern float D_800C527C;
extern float D_800C52E8_de;
extern float D_800C52EC_de;
extern float D_800C52F4;
extern float D_800C52FC_de;
extern float D_800C5304_de;
extern float D_800C5340;
extern float D_800C5354_de;
extern float D_800C5358_de;
extern float D_800C535C_de;
extern float D_800C5360_de;
extern float D_800C5364_de;
extern float D_800C5390_de;
extern float D_800C5394_de;
extern float D_800C5398_de;
extern float D_800C539C_de;
extern float D_800C53A0_de;
extern float D_800C53A4_de;
extern float D_800C53AC_de;
extern float D_800C53B0_de;
extern float D_800C53B8_de;
extern float D_800C53D0_de;
extern float D_800C53D4_de;
extern float D_800C53D8_de;
extern float D_800C53DC_de;
extern float D_800C53E0_de;
extern float D_800C53E4_de;
extern float D_800C53E8_de;
extern float D_800C53EC_de;
extern float D_800C53F0_de;
extern float D_800C53F4_de;
extern float D_800C53F8_de;
extern float D_800C53FC_de;
extern float D_800C5428;
extern float D_800C542C;
extern float D_800C5430_de;
extern float D_800C5434;
extern float D_800C5438_de;
extern float D_800C543C;
extern float D_800C5440_de;
extern float D_800C5444_de;
extern float D_800C5448;
extern float D_800C544C;
extern float D_800C5450_de;
extern float D_800C5454;
extern float D_800C5458_de;
extern float D_800C545C;
extern float D_800C5460;
extern float D_800C5464_de;
extern float D_800C546C;
extern float D_800C5470_de;
extern float D_800C5478;
extern float D_800C547C;
extern float D_800C5480_de;
extern float D_800C5484_de;
extern float D_800C5488_de;
extern float D_800C548C;
extern float D_800C5490_de;
extern float D_800C549C;
extern float D_800C54B0_de;
extern float D_800C54B8_de;
extern float D_800C54BC_de;
extern float D_800C54C4_de;
extern float D_800C54C8_de;
extern float D_800C54CC;
extern float D_800C54E0;
extern double D_800C5620_de;
extern double D_800C5670_de;
extern double D_800C56C0_de;
extern double D_800C56C8_de;
extern double D_800C56D0_de;
extern double D_800C56D8_de;
extern double D_800C56E0_de;
extern double D_800C56E8_de;
extern double D_800C56F0_de;
extern double D_800C56F8_de;
extern double D_800C5700_de;
extern double D_800C5708_de;
extern double D_800C5710_de;
extern double D_800C5718_de;
extern double D_800C5720_de;
extern double D_800C5728_de;
extern double D_800C5730_de;
extern double D_800C5738_de;
extern double D_800C5740_de;
extern double D_800C5748_de;
extern double D_800C5750_de;
extern double D_800C5758_de;
extern double D_800C5760_de;
extern double D_800C5768_de;
extern double D_800C5770_de;
extern double D_800C5778_de;
extern double D_800C5780_de;
extern double D_800C5788_de;
extern double D_800C5790_de;
extern double D_800C5798_de;
extern double D_800C57A0_de;
extern double D_800C57A8_de;
extern double D_800C57B0_de;
extern double D_800C57B8_de;
extern double D_800C57C0_de;
extern double D_800C57C8_de;
extern double D_800C57D0_de;
extern double D_800C57D8_de;
extern double D_800C57E0_de;
extern double D_800C57E8_de;
extern double D_800C57F0_de;
extern double D_800C57F8_de;
extern double D_800C5800_de;
extern double D_800C5808_de;
extern double D_800C5810_de;
extern double D_800C5818_de;
extern double D_800C5820_de;
extern double D_800C5828_de;
extern double D_800C5830_de;
extern double D_800C5838_de;
extern double D_800C5840_de;
extern double D_800C5848_de;
extern double D_800C5850_de;
extern double D_800C5858_de;
extern double D_800C5860_de;
extern double D_800C5868_de;
extern double D_800C5870_de;
extern float D_800C587C;
extern float D_800C5884;
extern float D_800C588C;
extern float D_800C5894;
extern float D_800C589C;
extern float D_800C58A4;
extern float D_800C58AC;
extern float D_800C58B4;
extern float D_800C58BC;
extern float D_800C58CC;
extern float D_800C58D4;
extern float D_800C58DC;
extern float D_800C58E4;
extern float D_800C58EC;
extern float D_800C58F4;
extern float D_800C58FC;
extern float D_800C590C;
extern float D_800C5914;
extern float D_800C591C_de;
extern float D_800C5924;
extern float D_800C5934;
extern float D_800C593C;
extern double D_800C5940_de;
extern double D_800C5948_de;
extern double D_800C5950_de;
extern double D_800C5958_de;
extern double D_800C5960_de;
extern double D_800C5968_de;
extern double D_800C5970_de;
extern double D_800C5978_de;
extern double D_800C5980_de;
extern double D_800C5988_de;
extern double D_800C5990_de;
extern double D_800C5998_de;
extern double D_800C59A0_de;
extern double D_800C59A8_de;
extern double D_800C59B0_de;
extern double D_800C59B8_de;
extern double D_800C59C0_de;
extern double D_800C59C8_de;
extern double D_800C59D0_de;
extern double D_800C59D8_de;
extern double D_800C59E0_de;
extern double D_800C59E8_de;
extern double D_800C59F0_de;
extern double D_800C59F8_de;
extern double D_800C5A00_de;
extern double D_800C5A08_de;
extern float D_800C5A10_de;
extern float D_800C5A14_de;
extern float D_800C5A18_de;
extern float D_800C5A1C_de;
extern float D_800C5A20_de;
extern float D_800C5A2C_de;
extern float D_800C5A30_de;
extern float D_800C5A34_de;
extern float D_800C5A38_de;
extern float D_800C5A3C_de;
extern float D_800C5A40_de;
extern float D_800C5A44;
extern float D_800C5A48_de;
extern float D_800C5A4C;
extern float D_800C5A50_de;
extern float D_800C5A54;
extern float D_800C5A58_de;
extern float D_800C5A5C;
extern float D_800C5A60_de;
extern float D_800C5A64;
extern float D_800C5A68_de;
extern float D_800C5A6C;
extern float D_800C5A70_de;
extern float D_800C5A74;
extern float D_800C5A78_de;
extern float D_800C5A7C;
extern float D_800C5A80_de;
extern float D_800C5A84;
extern float D_800C5A88_de;
extern float D_800C5A8C;
extern float D_800C5A90_de;
extern float D_800C5A94;
extern float D_800C5A98_de;
extern float D_800C5A9C;
extern float D_800C5AA0_de;
extern float D_800C5AA4;
extern float D_800C5AAC;
extern float D_800C5AB4;
extern float D_800C5ABC;
extern float D_800C5AC4;
extern float D_800C5ACC;
extern float D_800C5AD4;
extern float D_800C5ADC;
extern float D_800C5AE4;
extern float D_800C5AEC;
extern float D_800C5AF4;
extern float D_800C5AF8_de;
extern float D_800C5AFC;
extern float D_800C5B04_de;
extern float D_800C5B08_de;
extern float D_800C5BE4_de;
extern float D_800C5BEC_de;
extern float D_800C5BF4_de;
extern float D_800C5BFC_de;
extern float D_800C5C04_de;
extern float D_800C5C0C_de;
extern float D_800C5C14_de;
extern float D_800C5C1C_de;
extern float D_800C5C24;
extern float D_800C5C2C;
extern float D_800C5C34;
extern float D_800C5C3C;
extern float D_800C5C44;
extern float D_800C5C4C;
extern float D_800C5C5C;
extern float D_800C5C60_de;
extern float D_800C5C64;
extern float D_800C5C68_de;
extern double D_800C5C70_de;
extern float D_800C5C78_de;
extern float D_800C5C7C;
extern float D_800C5C80_de;
extern float D_800C5C84;
extern float D_800C5C8C;
extern float D_800C5C9C;
extern float D_800C5CA4_de;
extern float D_800C5CA8_de;
extern float D_800C5CCC_de;
extern float D_800C5DB8_de;
extern float D_800C5DBC_de;
extern float D_800C5DC4_de;
extern float D_800C5DC8_de;
extern float D_800C5DCC_de;
extern float D_800C5DD0_de;
extern float D_800C5DD4_de;
extern float D_800C5DD8_de;
extern float D_800C5DDC_de;
extern float D_800C5DE4_de;
extern float D_800C5DEC_de;
extern float D_800C5DF0_de;
extern float D_800C5DF4_de;
extern float D_800C5DF8_de;
extern float D_800C5DFC;
extern float D_800C5E00_de;
extern float D_800C5E04_de;
extern float D_800C5E08_de;
extern float D_800C5E38_de;
extern float D_800C5E3C_de;
extern float D_800C5E64_de;
extern float D_800C5E68_de;
extern float D_800C5E6C_de;
extern float D_800C5E70_de;
extern float D_800C5E74_de;
extern float D_800C5E78_de;
extern float D_800C5E7C_de;
extern float D_800C5E80_de;
extern float D_800C5E84_de;
extern float D_800C5E8C_de;
extern float D_800C5EAC_de;
extern float D_800C5EB4_de;
extern float D_800C5ED0_de;
extern float D_800C5ED4_de;
extern float D_800C5ED8_de;
extern float D_800C5EDC_de;
extern float D_800C5EE0_de;
extern float D_800C5EE4_de;
extern float D_800C5EE8_de;
extern float D_800C5EEC_de;
extern float D_800C5EF0_de;
extern float D_800C5EF4_de;
extern float D_800C5EF8_de;
extern float D_800C5EFC_de;
extern float D_800C5F00_de;
extern float D_800C5F04_de;
extern float D_800C5F08_de;
extern float D_800C5F0C_de;
extern float D_800C5F20_de;
extern float D_800C5F24_de;
extern float D_800C5F28_de;
extern float D_800C5F2C_de;
extern float D_800C5F30_de;
extern float D_800C5F34;
extern float D_800C5F38_de;
extern float D_800C5F3C_de;
extern float D_800C5F40_de;
extern float D_800C5F44_de;
extern float D_800C5F48_de;
extern float D_800C5F4C_de;
extern float D_800C5F50_de;
extern float D_800C5F94_de;
extern float D_800C5F98_de;
extern float D_800C5F9C_de;
extern float D_800C5FA0_de;
extern float D_800C5FA4_de;
extern float D_800C5FA8_de;
extern float D_800C5FAC_de;
extern float D_800C6028_de;
extern float D_800C6060_de;
extern float D_800C613C_de;
extern float D_800C6140_de;
extern float D_800C6178_de;
extern float D_800C61B0_de;
extern float D_800C61B4_de;
extern float D_800C61C0_de;
extern float D_800C61D0_de;
extern float D_800C61D4_de;
extern float D_800C61D8_de;
extern double D_800C61E0_de;
extern float D_800C61E8_de;
extern float D_800C61EC_de;
extern float D_800C622C_de;
extern double D_800C6230_de;
extern float D_800C6238_de;
extern float D_800C623C_de;
extern float D_800C6240_de;
extern double D_800C6248_de;
extern float D_800C6250_de;
extern float D_800C6254_de;
extern float D_800C6258;
extern float D_800C6264;
extern float D_800C626C;
extern float D_800C6278_de;
extern float D_800C6280_de;
extern float D_800C62A0;
extern float D_800C62A8;
extern float D_800C62B0;
extern float D_800C62E4;
extern float D_800C7368_de;
extern float D_800C7420_de;
extern float D_800C7424_de;
extern float D_800C7428_de;
extern float D_800C7434_de;
extern float D_800C7438;
extern float D_800C7458_de;
extern float D_800C74C4_de;
extern float D_800C74F4_de;
extern float D_800C7510_de;
extern double D_800C7560;
extern float D_800C758C;
extern float D_800C7594;
extern double D_800C75B8_de;
extern double D_800C75C8_de;
extern float D_800C75D4;
extern double D_800C75D8_de;
extern float D_800C77B8_de;
extern float D_800C77DC_de;
extern float D_800C7870_de;
extern float D_800C7874_de;
extern float D_800C7878_de;
extern float D_800C787C_de;
extern float D_800C78A0_de;
extern float D_800C78A4_de;
extern float D_800C78A8_de;
extern float D_800C78AC_de;
extern float D_800C78B0_de;
extern float D_800C78B4_de;
extern float D_800C78C4_de;
extern float D_800C78CC_de;
extern double D_800C7920_de;
extern float D_800C7928_de;
extern float D_800C792C_de;
extern float D_800C7CC4;
extern float D_800C7CCC_de;
extern float D_800C7CD8_de;
extern float D_800C7CDC_de;
extern float D_800C7CE0_de;
extern float D_800C7CE4_de;
extern double D_800C8120_de;
extern double D_800C8128_de;
extern double D_800C8130_de;
extern int D_800C8144_de;
extern float D_800C87E0;
extern float D_800C87E4;
extern float D_800C87E8;
extern float D_800C913C_de;
extern float D_800C917C;
extern float D_800C9194;
extern int D_800C9228_de;
extern int D_800C94DC_de;
extern float D_800C9514_de;
extern short D_800C9FD6;
extern short D_800C9FDA;
extern short D_800C9FDE;
extern float D_800C9FE8;
extern float D_800CB388;
extern float D_800CB38C_de;
extern float D_800CB394;
extern int D_800CB3A0;
extern int D_800CB3F8_de;
extern float D_800CB404_de;
extern int D_800CB410_de;
extern int D_800CB414_de;
extern float D_800CB434_de;
extern int D_800CB6E0;
extern unsigned int D_800CB710;
extern float D_800CB8EC[];
extern float D_800CBB60;
extern int D_800CBC30[];
extern int D_800CBC40[];
extern float D_800CC3DC[];
extern float D_800CC3E0[];
extern int D_800CD668_de[];
extern float D_800CD6B4;
extern float D_800CD74C;
extern float D_800CD754;
extern int D_800CD790[];
extern double D_800CD9A0;
extern int D_800CDBD0[];
extern unsigned char * D_800D1D60;
extern int D_800D26A4;
extern unsigned char * D_800D2A90;
extern void * D_800D3038;
extern unsigned char * D_800D30AC;
extern int D_800D311C;
extern int D_800D3120;
extern int D_800D3124;
extern unsigned char * D_800D3128;
extern unsigned char * D_800D312C;
extern int D_800D3130;
extern unsigned char * D_800D3134;
extern unsigned char * D_800D3138;
extern int D_800D313C;
extern int D_800D3140_de;
extern int D_800D3144;
extern int D_800D3148;
extern unsigned char * D_800D3150;
extern unsigned char * D_800D3154;
extern unsigned char * D_800D3158;
extern unsigned char * D_800D315C;
extern int D_800D3160;
extern int D_800D3164;
extern unsigned char * D_800D31B8;
extern int D_800D324C;
extern int D_800D32C4;
extern int D_800D3304;
extern int D_800D3334;
extern int D_800D333C;
extern int D_800D3340;
extern int D_800D334C_de;
extern int D_800D3350;
extern int D_800D3354;
extern int D_800D3358;
extern int D_800D335C;
extern int D_800D3360;
extern int D_800D3364;
extern int D_800D3368_de;
extern int D_800D336C;
extern int D_800D3370;
extern int D_800D3374;
extern int D_800D3378;
extern int D_800D337C;
extern int D_800D3380;
extern int D_800D3384;
extern int D_800D3388;
extern int D_800D338C;
extern int D_800D3390_de;
extern int D_800D3398;
extern int D_800D34D8;
extern int D_800D34DC;
extern int D_800D3584;
extern int D_800D3588;
extern int D_800D358C;
extern int D_800D3590;
extern int D_800D35F4;
extern int D_800D3628;
extern int D_800D36E4;
extern int D_800D37D0;
extern int D_800D3958;
extern int D_800D3A58;
extern unsigned char * D_800D3A9C;
extern int D_800D3C44;
extern int D_800D3C48;
extern int D_800D3C4C;
extern int D_800D3C50;
extern int D_800D3D98;
extern int D_800D3DA8;
extern int D_800D3DB8;
extern int D_800D3DC0;
extern int D_800D3DD8;
extern int D_800D5564;
extern float D_800DCAF0;
extern float D_800DCAF4;
extern float D_800DCAF8;
extern float D_800DCB18_de;
extern float D_800DCB20_de;
extern float D_800DCB28;
extern float D_800DCB34;
extern float D_800DCB3C;
extern float D_800DCB48;
extern float D_800DCB50;
extern float D_800DCB58;
extern float D_800DCB5C;
extern float D_800DCB60_de;
extern float D_800DCB68;
extern float D_800DCB70_de;
extern float D_800DCB78_de;
extern float D_800DCB7C_de;
extern float D_800DCB80_de;
extern float D_800DCB88;
extern float D_800DCB8C;
extern float D_800DCB90;
extern float D_800DCB94;
extern float D_800DCB98;
extern float D_800DCBA0;
extern float D_800DCBA4;
extern float D_800DCBA8;
extern float D_800DCBAC;
extern float D_800DCBB0;
extern float D_800DCBB8;
extern float D_800DCBBC;
extern float D_800DCBC0;
extern float D_800DCBC4_de;
extern float D_800DCBC8_de;
extern float D_800DCBD0_de;
extern float D_800DCBD4_de;
extern float D_800DCBD8_de;
extern float D_800DCBE0_de;
extern float D_800DCBE8_de;
extern float D_800DCBEC_de;
extern float D_800DCBF0_de;
extern float D_800DCBF8_de;
extern float D_800DCC00_de;
extern float D_800DCC08_de;
extern float D_800DCC10_de;
extern float D_800DCC14_de;
extern float D_800DCC18_de;
extern float D_800DCC1C;
extern float D_800DCC20;
extern float D_800DCC28;
extern double D_800DCC30;
extern double D_800DCC40_de;
extern float D_800DCC48_de;
extern float D_800DCC4C_de;
extern float D_800DCC58_de;
extern float D_800DCC60;
extern float D_800DCC70;
extern float D_800DCC74;
extern float D_800DCC78;
extern float D_800DCC84_de;
extern float D_800DD0A8;
extern double D_800DD0F0;
extern double D_800DD0F8_de;
extern double D_800DD108_de;
extern double D_800DD110_de;
extern double D_800DD120_de;
extern double D_800DD128_de;
extern double D_800DD130_de;
extern double D_800DD138_de;
extern double D_800DD140_de;
extern double D_800DD148_de;
extern double D_800DD150_de;
extern double D_800DD158_de;
extern double D_800DD160_de;
extern double D_800DD168_de;
extern double D_800DD170_de;
extern double D_800DD178_de;
extern double D_800DD180_de;
extern double D_800DD188_de;
extern double D_800DD190_de;
extern double D_800DD198_de;
extern double D_800DD1A0;
extern double D_800DD1A8_de;
extern double D_800DD1B0;
extern double D_800DD1B8;
extern float D_800DD360;
extern float D_800DD368;
extern float D_800DD370_de;
extern float D_800DD378;
extern float D_800DD380;
extern float D_800DD388;
extern float D_800DD390;
extern float D_800DD398;
extern float D_800DD3A0_de;
extern float D_800DD3A8_de;
extern float D_800DD3B0_de;
extern float D_800DD3B8;
extern float D_800DD3C0;
extern float D_800DD3C8;
extern float D_800DD3D8;
extern float D_800DD3E0;
extern float D_800DD3E4;
extern float D_800DD3FC;
extern float D_800DD400_de;
extern float D_800DD404;
extern f32 D_800DD408_de[2];
extern float D_800DD420;
extern float D_800DD428;
extern float D_800DD42C;
extern float D_800DD434;
extern float D_800DD438;
extern float D_800DD488;
extern float D_800DD490_de;
extern float D_800DD4BC_de;
extern float D_800DD528_de;
extern float D_800DD530_de;
extern float D_800DD538_de;
extern float D_800DD564;
extern float D_800DD568;
extern float D_800DD570;
extern float D_800DD584;
extern float D_800DD610;
extern float D_800DD684;
extern float D_800DD688;
extern float D_800DD68C;
extern float D_800DD690;
extern float D_800DD9A4;
extern float D_800DD9A8;
extern float D_800DD9B0;
extern float D_800DDB00;
extern float D_800DDB54;
extern float D_800DDB58;
extern float D_800DDE68;
extern float D_800DDE6C;
extern float D_800DDE70;
extern float D_800DDF20_de;
extern float D_800DDF28_de;
extern float D_800DDF38_de;
extern float D_800DDF40_de;
extern float D_800DDF48;
extern float D_800DDF5C;
extern float D_800DDF60_de;
extern float D_800DDF90_de;
extern float D_800DDF98_de;
extern float D_800DDFA8;
extern float D_800DDFAC_de;
extern float D_800DDFCC;
extern float D_800DDFDC;
extern float D_800DE030_de;
extern float D_800DE038;
extern float D_800DE03C_de;
extern float D_800DE040;
extern float D_800DE048_de;
extern float D_800DE320;
extern float D_800DE32C;
extern float D_800DE334;
extern float D_800DE338;
extern float D_800DE428;
extern float D_800DE460;
extern float D_800DE46C;
extern float D_800DE470;
extern float D_800DE474_de;
extern float D_800DE478;
extern float D_800DE47C_de;
extern float D_800DE480_de;
extern float D_800DE484;
extern float D_800DE488;
extern double D_800DE490;
extern float D_800DE498_de;
extern float D_800DE4A0;
extern float D_800DE4A8;
extern float D_800DE4AC;
extern float D_800DE4B0_de;
extern float D_800DE4B4;
extern float D_800DE4B8;
extern double D_800DE4C0;
extern float D_800DE4C8_de;
extern float D_800DE4D0;
extern float D_800DE4D8;
extern float D_800DE4DC;
extern float D_800DE4E0_de;
extern float D_800DE4E4;
extern float D_800DE4F4;
extern float D_800DE4F8_de;
extern float D_800DE7CC;
extern float D_800DE7D0;
extern int D_800DE858;
extern int D_800DE9C4[];
extern int D_800DE9C8[];
extern int D_800DE9CC[];
extern int D_800DE9D0[];
extern int D_800DEAD4[];
extern int D_800DF268_de;
extern int D_800DF520;
extern void * D_800DF964[];
extern int D_800E01B0_de[];
extern int D_800E0286[];
extern int D_800E1CC0[];
extern int D_800EB1AC;
extern float D_800EE144;
extern float D_800EE148;
extern float D_800EE150;
extern float D_800EE154;
extern float D_800EE158;
extern float D_800EE160;
extern int D_800F1DB0;
extern unsigned char D_800F3452;
extern int D_800F3468;
extern int jtbl_800C1AA0[];
extern int jtbl_800C1AF0[];
extern int jtbl_800C1B88[];
extern int jtbl_800C2060[];
extern int jtbl_800C21D0[];
extern int jtbl_800C23F8[];
extern int jtbl_800C25E8[];
extern int jtbl_800C2B80[];
extern int jtbl_800C2E98[];
extern int jtbl_800C3650[];
extern int jtbl_800C3BC0[];
extern int jtbl_800C3BF8[];
extern int jtbl_800C3C40[];
extern int jtbl_800C3D00[];
extern int jtbl_800C44A0[];
extern int jtbl_800C45E8[];
extern int jtbl_800C4618[];
extern int jtbl_800C4648[];
extern int jtbl_800C4CA8[];
extern int jtbl_800C4DB8[];
extern int jtbl_800C4E10[];
extern int jtbl_800C5368[];
extern int jtbl_800C5520[];
extern int jtbl_800C5560[];
extern int jtbl_800C55A0[];
extern int jtbl_800C5628[];
extern int jtbl_800C5690[];
extern int jtbl_800C5E10[];
extern int jtbl_800C5E40[];
extern int jtbl_800C5FB8_de[];
extern int jtbl_800C5FF8_de[];
extern int jtbl_800C6030[];
extern int jtbl_800C6068[];
extern int jtbl_800C6088[];
extern int jtbl_800C60A8[];
extern int jtbl_800C60C8[];
extern int jtbl_800C60E8[];
extern int jtbl_800C6108[];
extern int jtbl_800C6148[];
extern int jtbl_800C6180[];
extern int jtbl_800C62B8_de[];
extern int jtbl_800C7370[];
extern int jtbl_800C7460[];
extern int jtbl_800C7520[];
extern int jtbl_800C75A0[];
extern int jtbl_800C7798[];
extern int jtbl_800C7B18[];
extern int jtbl_800C8BD0[];
extern int jtbl_800C8EF0[];
extern int jtbl_800DBA88[];
extern int jtbl_800DCA38[];
extern int jtbl_800DCA58[];
extern int jtbl_800DCDA8[];
extern int jtbl_800DCDC0[];
extern int jtbl_800DD080[];
extern int jtbl_800DD1F8[];
extern int jtbl_800DD3E8[];
extern int jtbl_800DD4A0[];
extern int jtbl_800DD548[];
extern int jtbl_800DD660[];
extern int jtbl_800DD698[];
extern int jtbl_800DD930[];
extern int jtbl_800DD980[];
extern int jtbl_800DD9D8[];
extern int jtbl_800DDA30[];
extern int jtbl_800DDB40[];
extern int jtbl_800DDB98[];
extern int jtbl_800DDBB0[];
extern int jtbl_800DDBD0[];
extern int jtbl_800DDC30[];
extern int jtbl_800DDC90[];
extern int jtbl_800DDD08[];
extern int jtbl_800DDDD0[];
extern int jtbl_800DDE48[];
extern int jtbl_800DDE90[];
extern int jtbl_800DDED8[];
extern int jtbl_800DDFB0[];
extern int jtbl_800DDFE0[];
extern int jtbl_800DDFF8[];
extern int jtbl_800DE340[];
extern int jtbl_800DE398[];
extern int jtbl_800DE3C8[];
extern int jtbl_800DE3F8[];
extern int jtbl_800DE430[];
extern int jtbl_800DE500[];
extern int jtbl_800DE698[];
extern int jtbl_800DE6C8[];
extern int jtbl_800DE708[];
extern int jtbl_800DE728[];
extern int jtbl_800DE770[];
extern int jtbl_800EDCA0[];
extern int jtbl_800EE120[];
extern int jtbl_800EE3A8[];
extern int jtbl_800EE3C8[];
extern int jtbl_800EE3E8[];
struct Player;
struct Player {
    char pad0[8];
    Vec3 pos;
};
struct func_8020A028_S4;
typedef struct func_8020A028_S4 func_8020A028_S4;
struct func_8028FFB0_S3;
typedef struct func_8028FFB0_S3 func_8028FFB0_S3;
struct func_8022A404_S1;
struct func_8022A404_S1 {
    char pad0[0x20];
    int unk20;
};
struct func_8022ADA0_S1;
struct func_8022ADA0_S1 {
    char pad0[0x5E4];
    int unk5E4;
};
struct func_80237E70_G1;
struct func_80237E70_G1 {
    u8 * unk0;
};
struct func_8022C070_S1;
typedef struct func_8022C070_S1 func_8022C070_S1;
struct Player;
typedef struct Player Player;
union func_80237E70_S1_UF24;
typedef union func_80237E70_S1_UF24 func_80237E70_S1_UF24;
struct Course;
struct Course {
    char pad0[0x28];
    u8 laps;
};
struct CollisionInfo8020CD74;
typedef struct CollisionInfo8020CD74 CollisionInfo8020CD74;
struct func_8021C9B4_S2;
typedef struct func_8021C9B4_S2 func_8021C9B4_S2;
struct func_8021C9B4_S3;
typedef struct func_8021C9B4_S3 func_8021C9B4_S3;
struct func_8021C9B4_S3;
struct func_8021C9B4_S3 {
    char pad0[0xC];
    s16 unkC;
};
union func_80234DD0_S1_U260;
typedef union func_80234DD0_S1_U260 func_80234DD0_S1_U260;
struct Message;
struct Message {
    char pad0[0xC];
    f32 size;
    f32 alpha;
    s32 kind;
    s32 timer;
    s32 target;
    s32 pad20;
    u8 *text;
    s32 pad28;
    s32 pad2C;
    f32 x;
    f32 y;
    f32 scaleX;
    f32 scaleY;
};
struct Message;
union func_80237E70_S1_UF24;
union func_80237E70_S1_UF24 {
    struct Message * v0;
    char v1;
};
struct func_8022C884_S1;
typedef struct func_8022C884_S1 func_8022C884_S1;
struct func_80237E70_S2;
typedef struct func_80237E70_S2 func_80237E70_S2;
struct func_80209B64_S2;
struct func_80209B64_S2 {
    char pad0[0x93];
    u8 unk93;
};
struct Body;
struct Character;
struct Controller;
struct Controls;
struct Ctrl;
struct Held;
struct Mode;
struct Model;
struct Mount;
struct Profile;
struct Record;
struct Rider;
struct Settings;
struct SharedPlayer_func_80209CD8_de;
struct Shared_Body;
struct Shared_Hud;
struct Shared_Model;
struct Shared_Profile;
struct Shared_StateInfo;
struct Shared_Voice;
struct StateInfo;
struct TeamInfo;
struct View;
struct SharedPlayer_func_80209CD8_de {
    union {
        struct {
            u8 unk0[24];
        } view0_0;
        struct {
            u8 pad0[24];
        } view0_1;
        struct {
            char pad[0x3];
            u8 team;
        } view3_2;
        struct {
            char pad[0x8];
            Vec3 unk8;
        } view8_2;
        struct {
            char pad[0x8];
            Vec3 pos;
        } view8_3;
        struct {
            char pad[0x8];
            Vec3 position;
        } view8_4;
        struct {
            char pad[0x14];
            struct Shared_Model * model;
        } view14_6;
        struct { char pad[8]; s32 positionWords[3]; } positionBits;
    } views0;
    union {
        struct {
            char * unk18;
        } view18_0;
        struct {
            char * track;
        } view18_1;
        struct {
            struct Model * model;
        } view18_2;
        struct {
            struct Body * body;
        } view18_3;
        struct {
            struct Character * character;
        } view18_4;
        struct {
            struct Shared_Body * body;
        } view18_5;
    } views18;
    union {
        struct {
            u8 unk1C[344];
        } view1C_0;
        struct {
            u8 pad1[344];
        } view1C_1;
        struct {
            char pad[0x4];
            f32 velY;
        } view20_2;
        struct {
            char pad[0x1C];
            s32 unk38;
        } view38_2;
        struct {
            char pad[0x1C];
            s32 flags;
        } view38_3;
        struct {
            char pad[0x24];
            f32 unk40;
        } view40_5;
        struct {
            char pad[0x40];
            Shared_Quad unk5C;
        } view5C_6;
        struct {
            char pad[0x50];
            f32 unk6C;
        } view6C_4;
        struct {
            char pad[0x50];
            f32 heading;
        } view6C_5;
        struct {
            char pad[0x50];
            f32 yaw;
        } view6C_9;
        struct {
            char pad[0xC8];
            u16 unkE4;
        } viewE4_6;
        struct {
            char pad[0xC8];
            u16 kind;
        } viewE4_7;
        struct {
            char pad[0xE4];
            s32 unk100;
        } view100_8;
        struct {
            char pad[0xE4];
            s32 flags;
        } view100_9;
        struct {
            char pad[0xE8];
            f32 unk104;
        } view104_10;
        struct {
            char pad[0xE8];
            f32 idleTime;
        } view104_11;
        struct {
            char pad[0xEC];
            s16 anim;
        } view108_16;
        struct {
            char pad[0xF2];
            s8 unk10E;
        } view10E_12;
        struct {
            char pad[0xF2];
            s8 idle;
        } view10E_13;
        struct {
            char pad[0xF2];
            s8 replaying;
        } view10E_14;
        struct {
            char pad[0xF2];
            s8 animPending;
        } view10E_20;
        struct {
            char pad[0x154];
            char unk170[100];
        } view170_15;
        struct {
            char pad[0x154];
            char body[100];
        } view170_16;
        struct {
            char pad[0x154];
            s32 unk170;
        } view170_23;
        struct {
            char pad[0x158];
            s32 unk174;
        } view174_17;
        struct {
            char pad[0x15C];
            u8 unk178[740];
        } view178_18;
        struct {
            char pad[0x15C];
            u8 pad2[740];
        } view178_19;
        struct {
            char pad[0x1B8];
            f32 unk1D4;
        } view1D4_20;
        struct {
            char pad[0x1B8];
            f32 holdTime;
        } view1D4_21;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80209CD8_de * unk1D8;
        } view1D8_22;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80209CD8_de * self;
        } view1D8_23;
        struct {
            char pad[0x1BC];
            struct SharedPlayer_func_80209CD8_de * f1D8;
        } view1D8_24;
        struct {
            char pad[0x1BC];
            void * unk1D8;
        } view1D8_32;
        struct {
            char pad[0x244];
            Vec3 unk260;
        } view260_25;
        struct {
            char pad[0x244];
            Vec3 muzzle;
        } view260_26;
        struct {
            char pad[0x2CC];
            char unk2E8[368];
        } view2E8_27;
        struct {
            char pad[0x2CC];
            char weapon[368];
        } view2E8_28;
        struct {
            char pad[0x2CC];
            Shared_Emitter emitter;
        } view2E8_37;
        struct {
            char pad[0x43C];
            char unk458[384];
        } view458_29;
        struct {
            char pad[0x43C];
            char ammo[384];
        } view458_30;
        struct {
            char pad[0x43C];
            s32 unk458;
        } view458_40;
        struct {
            char pad[0x440];
            s32 unk45C;
        } view45C_31;
        struct {
            char pad[0x444];
            u8 unk460[376];
        } view460_32;
        struct {
            char pad[0x444];
            u8 pad3[376];
        } view460_33;
        struct {
            char pad[0x468];
            struct Shared_Voice * voice;
        } view484_44;
        struct {
            char pad[0x470];
            s8 unk48C;
        } view48C_34;
        struct {
            char pad[0x470];
            s8 state;
        } view48C_35;
        struct {
            char pad[0x4A4];
            void * unk4C0;
        } view4C0_47;
        struct {
            char pad[0x507];
            s8 unk523;
        } view523_36;
        struct {
            char pad[0x507];
            s8 busy;
        } view523_37;
        struct {
            char pad[0x578];
            s32 unk594;
        } view594_38;
        struct {
            char pad[0x578];
            s32 gear;
        } view594_39;
        struct {
            char pad[0x578];
            s32 mode;
        } view594_40;
        struct {
            char pad[0x584];
            f32 unk5A0;
        } view5A0_41;
        struct {
            char pad[0x584];
            f32 charge;
        } view5A0_42;
        struct {
            char pad[0x5B4];
            s32 unk5D0;
        } view5D0_43;
        struct {
            char pad[0x5B4];
            s32 f5D0;
        } view5D0_44;
        struct {
            char pad[0x5B8];
            s32 unk5D4;
        } view5D4_45;
        struct {
            char pad[0x5B8];
            s32 slot;
        } view5D4_46;
        struct {
            char pad[0x5B8];
            s32 profile;
        } view5D4_47;
        struct {
            char pad[0x5B8];
            s32 f5D4;
        } view5D4_48;
    } views1C;
    union {
        struct {
            struct Record * unk5D8;
        } view5D8_0;
        struct {
            struct Record * record;
        } view5D8_1;
        struct {
            struct Controls * controls;
        } view5D8_2;
        struct {
            struct TeamInfo * teamInfo;
        } view5D8_3;
        struct {
            struct Ctrl * ctrl;
        } view5D8_4;
        struct {
            unsigned char * info;
        } view5D8_5;
        struct {
            struct Profile * profile;
        } view5D8_6;
        struct {
            struct Settings * settings;
        } view5D8_7;
        struct {
            s32 f5D8;
        } view5D8_8;
        struct {
            struct Shared_Profile * profile;
        } view5D8_9;
    } views5D8;
    union {
        struct {
            void * unk5DC;
        } view5DC_0;
        struct {
            void * view;
        } view5DC_1;
        struct {
            struct View * view;
        } view5DC_2;
        struct {
            u8 pad4[8];
        } view5DC_3;
        struct {
            void * entity;
        } view5DC_4;
        struct {
            struct Rider * rider;
        } view5DC_5;
        struct {
            char * storage;
        } view5DC_6;
        struct {
            char * messages;
        } view5DC_7;
        struct {
            struct Shared_Hud * hud;
        } view5DC_8;
        struct {
            char pad[0x4];
            s32 unk5E0;
        } view5E0_8;
        struct {
            char pad[0x4];
            s32 state;
        } view5E0_9;
        struct {
            char pad[0x4];
            s32 slot;
        } view5E0_10;
    } views5DC;
    union {
        struct {
            s32 unk5E4;
        } view5E4_0;
        struct {
            s32 active;
        } view5E4_1;
        struct {
            s32 health;
        } view5E4_2;
        struct {
            s32 alive;
        } view5E4_3;
        struct {
            s32 holding;
        } view5E4_4;
    } views5E4;
    union {
        struct {
            u8 unk5E8[3140];
        } view5E8_0;
        struct {
            u8 pad5[3140];
        } view5E8_1;
        struct {
            char pad[0x2];
            s16 unk5EA;
        } view5EA_2;
        struct {
            char pad[0x2];
            s16 respawns;
        } view5EA_3;
        struct {
            char pad[0x2];
            s16 runType;
        } view5EA_4;
        struct {
            char pad[0x4];
            s32 unk5EC;
        } view5EC_5;
        struct {
            char pad[0x4];
            s32 model;
        } view5EC_6;
        struct {
            char pad[0x4];
            s32 spawnPoint;
        } view5EC_7;
        struct {
            char pad[0x4];
            s32 f5EC;
        } view5EC_8;
        struct {
            char pad[0x8];
            s32 unk5F0;
        } view5F0_9;
        struct {
            char pad[0x8];
            s32 f5F0;
        } view5F0_10;
        struct {
            char pad[0xC];
            s16 unk5F4[4];
        } view5F4_11;
        struct {
            char pad[0xC];
            s16 ammo[4];
        } view5F4_12;
        struct {
            char pad[0xC];
            s16 ammo[3];
        } view5F4_13;
        struct {
            char pad[0x1A];
            Shared_Slot slots[22];
        } view602_14;
        struct {
            char pad[0x46];
            s16 unk62E;
        } view62E_13;
        struct {
            char pad[0x46];
            s16 weapon;
        } view62E_14;
        struct {
            char pad[0x46];
            s16 character;
        } view62E_17;
        struct {
            char pad[0x68];
            s16 unk650;
        } view650_15;
        struct {
            char pad[0x68];
            s16 state;
        } view650_16;
        struct {
            char pad[0x68];
            s16 action;
        } view650_17;
        struct {
            char pad[0x68];
            s16 mode;
        } view650_18;
        struct {
            char pad[0x6A];
            s16 unk652;
        } view652_19;
        struct {
            char pad[0x6A];
            s16 previous;
        } view652_20;
        struct {
            char pad[0x6A];
            s16 pad652;
        } view652_24;
        struct {
            char pad[0x6C];
            s16 prevState;
        } view654_25;
        struct {
            char pad[0x6E];
            s16 pad656;
        } view656_26;
        struct {
            char pad[0x70];
            f32 unk658;
        } view658_21;
        struct {
            char pad[0x70];
            f32 counter;
        } view658_22;
        struct {
            char pad[0x70];
            f32 stride;
        } view658_23;
        struct {
            char pad[0x70];
            f32 swimTime;
        } view658_24;
        struct {
            char pad[0x70];
            f32 stateTime;
        } view658_31;
        struct {
            char pad[0x74];
            s32 unk65C;
        } view65C_32;
        struct {
            char pad[0x78];
            s32 unk660;
        } view660_25;
        struct {
            char pad[0x78];
            s32 previousTimer;
        } view660_26;
        struct {
            char pad[0x7C];
            s32 unk664;
        } view664_27;
        struct {
            char pad[0x7C];
            s32 timer;
        } view664_28;
        struct {
            char pad[0x84];
            f32 unk66C;
        } view66C_29;
        struct {
            char pad[0x88];
            f32 unk670;
        } view670_30;
        struct {
            char pad[0x88];
            f32 shield;
        } view670_31;
        struct {
            char pad[0x90];
            f32 unk678;
        } view678_40;
        struct {
            char pad[0xA0];
            char unk688[16];
        } view688_32;
        struct {
            char pad[0xA0];
            char body[16];
        } view688_33;
        struct {
            char pad[0xA0];
            Shared_Input input;
        } view688_43;
        struct {
            char pad[0xB0];
            struct Controller * unk698;
        } view698_34;
        struct {
            char pad[0xB0];
            struct Controller * controller;
        } view698_35;
        struct {
            char pad[0xB0];
            void * controller;
        } view698_36;
        struct {
            char pad[0xB0];
            char * emitter;
        } view698_37;
        struct {
            char pad[0xB0];
            char * title;
        } view698_38;
        struct {
            char pad[0xB4];
            f32 unk69C;
        } view69C_39;
        struct {
            char pad[0xB4];
            f32 stick;
        } view69C_40;
        struct {
            char pad[0xBC];
            f32 unk6A4;
        } view6A4_41;
        struct {
            char pad[0xBC];
            f32 strafe;
        } view6A4_42;
        struct {
            char pad[0xC0];
            f32 unk6A8;
        } view6A8_43;
        struct {
            char pad[0xC0];
            f32 lift;
        } view6A8_44;
        struct {
            char pad[0xC4];
            s32 unk6AC;
        } view6AC_45;
        struct {
            char pad[0xC8];
            s32 unk6B0;
        } view6B0_46;
        struct {
            char pad[0xC8];
            s32 input;
        } view6B0_47;
        struct {
            char pad[0xC8];
            s32 state;
        } view6B0_48;
        struct {
            char pad[0xD0];
            s32 unk6B8;
        } view6B8_49;
        struct {
            char pad[0xD0];
            s32 input;
        } view6B8_50;
        struct {
            char pad[0xD8];
            f32 unk6C0;
        } view6C0_51;
        struct {
            char pad[0xD8];
            f32 climb;
        } view6C0_52;
        struct {
            char pad[0xD8];
            f32 speed;
        } view6C0_53;
        struct {
            char pad[0xD8];
            f32 velX;
        } view6C0_64;
        struct {
            char pad[0xDC];
            f32 unk6C4;
        } view6C4_54;
        struct {
            char pad[0xDC];
            f32 side;
        } view6C4_55;
        struct {
            char pad[0xDC];
            f32 velZ;
        } view6C4_67;
        struct {
            char pad[0xE0];
            f32 unk6C8;
        } view6C8_56;
        struct {
            char pad[0xE0];
            f32 speed;
        } view6C8_57;
        struct {
            char pad[0xE4];
            f32 lastVelY;
        } view6CC_70;
        struct {
            char pad[0xE8];
            s32 onGround;
        } view6D0_71;
        struct {
            char pad[0xEC];
            f32 unk6D4;
        } view6D4_58;
        struct {
            char pad[0xF0];
            f32 unk6D8;
        } view6D8_59;
        struct {
            char pad[0xF4];
            f32 unk6DC;
        } view6DC_60;
        struct {
            char pad[0xFC];
            f32 unk6E4;
        } view6E4_61;
        struct {
            char pad[0xFC];
            f32 depth;
        } view6E4_62;
        struct {
            char pad[0xFC];
            f32 airTime;
        } view6E4_77;
        struct {
            char pad[0x100];
            f32 unk6E8;
        } view6E8_63;
        struct {
            char pad[0x100];
            Vec3 unk6E8;
        } view6E8_79;
        struct {
            char pad[0x104];
            f32 unk6EC;
        } view6EC_64;
        struct {
            char pad[0x104];
            f32 height;
        } view6EC_65;
        struct {
            char pad[0x108];
            f32 unk6F0;
        } view6F0_66;
        struct {
            char pad[0x10C];
            f32 unk6F4;
        } view6F4_83;
        struct {
            char pad[0x110];
            Vec3 unk6F8;
        } view6F8_84;
        struct {
            char pad[0x11C];
            f32 unk704;
        } view704_67;
        struct {
            char pad[0x11C];
            f32 lift;
        } view704_68;
        struct {
            char pad[0x130];
            f32 unk718;
        } view718_69;
        struct {
            char pad[0x130];
            f32 crouch;
        } view718_70;
        struct {
            char pad[0x134];
            s32 unk71C;
        } view71C_89;
        struct {
            char pad[0x138];
            f32 swim;
        } view720_90;
        struct {
            char pad[0x13C];
            f32 unk724;
        } view724_71;
        struct {
            char pad[0x13C];
            f32 pitch;
        } view724_72;
        struct {
            char pad[0x140];
            f32 unk728;
        } view728_73;
        struct {
            char pad[0x140];
            f32 kickPitch;
        } view728_74;
        struct {
            char pad[0x144];
            f32 unk72C;
        } view72C_75;
        struct {
            char pad[0x144];
            f32 kickRoll;
        } view72C_76;
        struct {
            char pad[0x144];
            f32 lean;
        } view72C_77;
        struct {
            char pad[0x148];
            f32 unk730[3];
        } view730_78;
        struct {
            char pad[0x148];
            f32 sway[3];
        } view730_79;
        struct {
            char pad[0x154];
            f32 unk73C;
        } view73C_80;
        struct {
            char pad[0x154];
            f32 side;
        } view73C_81;
        struct {
            char pad[0x154];
            Vec3 weapon;
        } view73C_82;
        struct {
            char pad[0x158];
            f32 unk740;
        } view740_83;
        struct {
            char pad[0x158];
            f32 height;
        } view740_84;
        struct {
            char pad[0x15C];
            f32 unk744;
        } view744_85;
        struct {
            char pad[0x15C];
            f32 forward;
        } view744_86;
        struct {
            char pad[0x170];
            f32 unk758;
        } view758_87;
        struct {
            char pad[0x170];
            f32 bobStrength;
        } view758_88;
        struct {
            char pad[0x174];
            f32 unk75C;
        } view75C_89;
        struct {
            char pad[0x174];
            f32 bobSpeed;
        } view75C_90;
        struct {
            char pad[0x188];
            s16 unk770;
        } view770_91;
        struct {
            char pad[0x188];
            s16 nextWeapon;
        } view770_92;
        struct {
            char pad[0x188];
            s16 weapon;
        } view770_113;
        struct {
            char pad[0x18A];
            s16 pad772;
        } view772_114;
        struct {
            char pad[0x18C];
            Vec3 unk774;
        } view774_115;
        struct {
            char pad[0x198];
            f32 unk780;
        } view780_116;
        struct {
            char pad[0x19C];
            f32 unk784;
        } view784_117;
        struct {
            char pad[0x1A0];
            s32 unk788;
        } view788_93;
        struct {
            char pad[0x1A0];
            s32 icons;
        } view788_94;
        struct {
            char pad[0x1B0];
            s32 unk798;
        } view798_95;
        struct {
            char pad[0x1B0];
            s32 carried;
        } view798_96;
        struct {
            char pad[0x1B4];
            Vec3 unk79C;
        } view79C_97;
        struct {
            char pad[0x1B4];
            Vec3 carriedPosition;
        } view79C_98;
        struct {
            char pad[0x1D0];
            s32 unk7B8;
        } view7B8_99;
        struct {
            char pad[0x1D0];
            s32 target;
        } view7B8_100;
        struct {
            char pad[0x1D4];
            f32 unk7BC;
        } view7BC_101;
        struct {
            char pad[0x1D4];
            f32 timer;
        } view7BC_102;
        struct {
            char pad[0x1D8];
            Vec3 unk7C0;
        } view7C0_103;
        struct {
            char pad[0x1D8];
            Vec3 targetPosition;
        } view7C0_104;
        struct {
            char pad[0x200];
            s32 unk7E8;
        } view7E8_105;
        struct {
            char pad[0x200];
            s32 zoomed;
        } view7E8_106;
        struct {
            char pad[0x204];
            f32 unk7EC;
        } view7EC_132;
        struct {
            char pad[0x208];
            f32 unk7F0;
        } view7F0_133;
        struct {
            char pad[0x224];
            struct Mount * unk80C;
        } view80C_107;
        struct {
            char pad[0x224];
            struct Mount * mount;
        } view80C_108;
        struct {
            char pad[0x228];
            s32 unk810;
        } view810_109;
        struct {
            char pad[0x228];
            s32 kind;
        } view810_110;
        struct {
            char pad[0x22C];
            Triple unk814;
        } view814_111;
        struct {
            char pad[0x22C];
            Triple offset;
        } view814_112;
        struct {
            char pad[0x250];
            f32 unk838;
        } view838_113;
        struct {
            char pad[0x250];
            f32 rideTime;
        } view838_114;
        struct {
            char pad[0x254];
            f32 unk83C;
        } view83C_115;
        struct {
            char pad[0x254];
            f32 bump;
        } view83C_116;
        struct {
            char pad[0x258];
            s32 unk840;
        } view840_117;
        struct {
            char pad[0x258];
            s32 surfaced;
        } view840_118;
        struct {
            char pad[0x264];
            s32 unk84C;
        } view84C_149;
        struct {
            char pad[0x26C];
            f32 unk854;
        } view854_147;
        struct {
            char pad[0x274];
            s32 unk85C;
        } view85C_119;
        struct {
            char pad[0x274];
            s32 w85C;
        } view85C_120;
        struct {
            char pad[0x27C];
            s32 unk864;
        } view864_121;
        struct {
            char pad[0x27C];
            s32 f864;
        } view864_122;
        struct {
            char pad[0x280];
            s32 unk868;
        } view868_123;
        struct {
            char pad[0x280];
            s32 f868;
        } view868_124;
        struct {
            char pad[0x284];
            s32 unk86C;
        } view86C_125;
        struct {
            char pad[0x284];
            s32 parameter;
        } view86C_126;
        struct {
            char pad[0x284];
            s32 animation;
        } view86C_127;
        struct {
            char pad[0x288];
            s32 unk870;
        } view870_157;
        struct {
            char pad[0x290];
            Shared_Effect effect;
        } view878_158;
        struct {
            char pad[0x350];
            char unk938[2188];
        } view938_128;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_129;
        struct {
            char pad[0x350];
            char strokes[2188];
        } view938_130;
        struct {
            char pad[0x350];
            s32 unk938;
        } view938_162;
        struct {
            char pad[0x6D0];
            s32 unkCB8;
        } viewCB8_163;
        struct {
            char pad[0x6E4];
            s32 unkCCC;
        } viewCCC_164;
        struct {
            char pad[0x758];
            s32 unkD40;
        } viewD40_165;
        struct {
            char pad[0x96C];
            s32 unkF54;
        } viewF54_131;
        struct {
            char pad[0x96C];
            s32 selection;
        } viewF54_132;
        struct {
            char pad[0x9A8];
            s32 unkF90;
        } viewF90_133;
        struct {
            char pad[0x9A8];
            s32 choice;
        } viewF90_134;
        struct {
            char pad[0xBCC];
            s32 unk11B4;
        } view11B4_135;
        struct {
            char pad[0xBCC];
            s32 locked;
        } view11B4_136;
        struct {
            char pad[0xBD0];
            s32 unk11B8;
        } view11B8_137;
        struct {
            char pad[0xBD0];
            s32 frozen;
        } view11B8_138;
        struct {
            char pad[0xBD4];
            s32 unk11BC;
        } view11BC_139;
        struct {
            char pad[0xBD4];
            s32 f11BC;
        } view11BC_140;
        struct {
            char pad[0xBD8];
            s32 unk11C0;
        } view11C0_141;
        struct {
            char pad[0xBD8];
            s32 f11C0;
        } view11C0_142;
        struct {
            char pad[0xBDC];
            f32 unk11C4;
        } view11C4_143;
        struct {
            char pad[0xBDC];
            f32 soundTime;
        } view11C4_144;
        struct {
            char pad[0xBE4];
            s32 unk11CC;
        } view11CC_145;
        struct {
            char pad[0xBE4];
            s32 f11CC;
        } view11CC_146;
        struct {
            char pad[0xBF0];
            f32 unk11D8;
        } view11D8_147;
        struct {
            char pad[0xBF0];
            f32 recoil;
        } view11D8_148;
        struct {
            char pad[0xBF0];
            f32 stun;
        } view11D8_149;
        struct {
            char pad[0xBF4];
            f32 unk11DC;
        } view11DC_185;
        struct {
            char pad[0xBF8];
            f32 unk11E0;
        } view11E0_186;
        struct {
            char pad[0xC00];
            s32 unk11E8;
        } view11E8_150;
        struct {
            char pad[0xC00];
            s32 f11E8;
        } view11E8_151;
        struct {
            char pad[0xC04];
            f32 unk11EC;
        } view11EC_189;
        struct {
            char pad[0xC28];
            s32 unk1210;
        } view1210_152;
        struct {
            char pad[0xC28];
            s32 marker;
        } view1210_153;
        struct {
            char pad[0xC2C];
            s32 unk1214;
        } view1214_154;
        struct {
            char pad[0xC2C];
            s32 marker;
        } view1214_155;
        struct {
            char pad[0xC2C];
            s32 markerShown;
        } view1214_156;
        struct {
            char pad[0xC30];
            s32 unk1218;
        } view1218_157;
        struct {
            char pad[0xC30];
            s32 f1218;
        } view1218_158;
        struct {
            char pad[0xC34];
            s32 unk121C;
        } view121C_159;
        struct {
            char pad[0xC34];
            s32 f121C;
        } view121C_160;
        struct {
            char pad[0xC38];
            s32 unk1220;
        } view1220_161;
        struct {
            char pad[0xC38];
            s32 f1220;
        } view1220_162;
        struct { char pad[0xE]; s16 charge; } chargeView;
        struct { char pad[0x11F4 - 0x5E8]; f32 spin; s32 frame; } rapidFireView;
    } views5E8;
    union {
        struct {
            u32 unk122C;
        } view122C_0;
        struct {
            u32 flags;
        } view122C_1;
        struct {
            s32 options;
        } view122C_2;
        struct {
            s32 f122C;
        } view122C_3;
        struct {
            s32 fxFlags;
        } view122C_4;
    } views122C;
    f32 fxTime;
    f32 fxSpeed;
    s32 fxStage;
    char pad123C[0x4];
    f32 unk1240;
    f32 unk1244;
    char pad1248[0x7C];
    union {
        struct {
            s32 unk12C4;
        } view12C4_0;
        struct {
            s32 f12C4;
        } view12C4_1;
    } views12C4;
    union {
        struct {
            s32 unk12C8;
        } view12C8_0;
        struct {
            s32 f12C8;
        } view12C8_1;
    } views12C8;
    union {
        struct {
            s32 unk12CC[8];
        } view12CC_0;
        struct {
            s32 splitsA[8];
        } view12CC_1;
    } views12CC;
    s32 unk12EC;
    char pad12F0[0x4];
    union {
        struct {
            s32 unk12F4[8];
        } view12F4_0;
        struct {
            s32 splitsB[8];
        } view12F4_1;
    } views12F4;
    char pad1314[0x20];
    union {
        struct {
            s32 unk1334;
        } view1334_0;
        struct {
            s32 f1334;
        } view1334_1;
    } views1334;
    union {
        struct {
            s32 unk1338;
        } view1338_0;
        struct {
            s32 f1338;
        } view1338_1;
    } views1338;
    union {
        struct {
            s32 unk133C;
        } view133C_0;
        struct {
            s32 laps;
        } view133C_1;
        struct {
            s32 lives;
        } view133C_2;
    } views133C;
    union {
        struct {
            s32 unk1340;
        } view1340_0;
        struct {
            s32 stalls;
        } view1340_1;
        struct {
            s32 timer;
        } view1340_2;
        struct {
            s32 respawnTimer;
        } view1340_3;
    } views1340;
    char pad1344[0x70];
    union {
        struct {
            struct StateInfo * unk13B4;
        } view13B4_0;
        struct {
            struct StateInfo * states;
        } view13B4_1;
        struct {
            struct Mode * unk13B4;
        } view13B4_2;
        struct {
            void * character;
        } view13B4_3;
        struct {
            s32 f13B4;
        } view13B4_4;
        struct {
            struct Shared_StateInfo * states;
        } view13B4_5;
    } views13B4;
    char pad13B8[0x10];
    union {
        struct {
            s32 unk13C8;
        } view13C8_0;
        struct {
            s32 w13C8;
        } view13C8_1;
        struct {
            s32 f13C8;
        } view13C8_2;
    } views13C8;
    char pad13CC[0x8];
    s32 unk13D4;
    union {
        struct {
            struct Held * unk13D8;
        } view13D8_0;
        struct {
            struct Held * held;
        } view13D8_1;
    } views13D8;
    char pad13DC[0xC];
    s32 messageIndex;
    char pad13EC[0x64];
    union {
        struct {
            s32 unk1450;
        } view1450_0;
        struct {
            s32 computer;
        } view1450_1;
        struct {
            s32 infinite;
        } view1450_2;
        struct {
            s32 unlimited;
        } view1450_3;
        struct {
            s32 uncounted;
        } view1450_4;
        struct {
            s32 f1450;
        } view1450_5;
    } views1450;
    union {
        struct {
            s32 unk1454;
        } view1454_0;
        struct {
            s32 f1454;
        } view1454_1;
    } views1454;
    char pad1458[0xC];
    union {
        struct {
            Vec3 unk1464;
        } view1464_0;
        struct {
            Vec3 aim;
        } view1464_1;
    } views1464;
    char pad1470[0x10];
    union {
        struct {
            Matrix unk1480[2];
        } view1480_0;
        struct {
            Matrix beams[2];
        } view1480_1;
    } views1480;
    union {
        struct {
            Matrix unk1500[2];
        } view1500_0;
        struct {
            Matrix lasers[2];
        } view1500_1;
    } views1500;
    union {
        struct {
            Matrix unk1580[2];
        } view1580_0;
        struct {
            Matrix dots[2];
        } view1580_1;
    } views1580;
    char pad1600[0xD4];
    union {
        struct {
            s32 unk16D4;
        } view16D4_0;
        struct {
            s32 f16D4;
        } view16D4_1;
    } views16D4;
    u16 unk16D8;
    char pad16DA[0x6];
    union {
        struct {
            struct SharedPlayer_func_80209CD8_de * unk16E0;
        } view16E0_0;
        struct {
            struct SharedPlayer_func_80209CD8_de * next;
        } view16E0_1;
        struct {
            struct SharedPlayer_func_80209CD8_de * next;
        } view16E0_2;
    } views16E0;
};
struct func_80205314_S1;
struct func_80205314_S1 {
    char pad0[0x18];
    void * unk18;
};
extern int D_800C922C;
struct func_80229A54_S2;
struct func_80229A54_S2 {
    char pad0[0x5D8];
    char * unk5D8;
    char pad5D8[0x16E0 - 0x5D8 - sizeof(char*)];
    char * unk16E0;
};
struct Message;
typedef struct Message Message;
union func_80234DD0_S1_U260;
union func_80234DD0_S1_U260 {
    Vec3 v0;
    f32 v1;
};
struct Message;
union func_80237E70_S2_UE40;
union func_80237E70_S2_UE40 {
    char v0;
    struct Message * v1;
};
union func_80237E70_S2_UE40;
typedef union func_80237E70_S2_UE40 func_80237E70_S2_UE40;
struct func_80237E70_S2;
struct func_80237E70_S2 {
    char pad0[0xE40];
    func_80237E70_S2_UE40 unkE40;
};
struct ObjectLinks3C;
typedef struct ObjectLinks3C ObjectLinks3C;
struct func_80237E70_S4;
typedef struct func_80237E70_S4 func_80237E70_S4;
struct func_80209B64_S4;
typedef struct func_80209B64_S4 func_80209B64_S4;
struct func_80209B64_S4;
struct func_80209B64_S4 {
    char pad0[0x5D8];
    void * unk5D8;
};
struct func_80237E70_G1;
typedef struct func_80237E70_G1 func_80237E70_G1;
struct Model_func_80223E34_de;
struct Model_func_80223E34_de {
    char pad0[0xF4];
    f32 height;
};
struct func_802285C4_S1;
struct func_802285C4_S1 {
    char pad0[0x20];
    char * unk20;
};
struct Frame;
typedef struct Frame Frame;
union func_80209DAC_S2_U93;
typedef union func_80209DAC_S2_U93 func_80209DAC_S2_U93;
struct func_80216BF4_S1;
struct func_80216BF4_S1 {
    char pad0[0xC];
    f32 unkC;
};
union func_80209DAC_S2_U93;
union func_80209DAC_S2_U93 {
    u8 v0;
    s8 v1;
};
struct func_8021C9B4_S2;
struct func_8021C9B4_S2 {
    char pad0[0x81];
    u8 unk81;
    char pad81[0x8F - 0x81 - sizeof(u8)];
    u8 unk8F;
};
struct Message;
struct func_80237E70_S4;
struct func_80237E70_S4 {
    char pad0[0x4];
    struct Message * unk4;
};
struct func_8020D1FC_S1;
struct func_8020D1FC_S1 {
    char pad0[0x38];
    s32 unk38;
};
struct func_8020D1FC_S1;
typedef struct func_8020D1FC_S1 func_8020D1FC_S1;
struct func_80219490_S2;
typedef struct func_80219490_S2 func_80219490_S2;
struct func_80207ABC_S1;
typedef struct func_80207ABC_S1 func_80207ABC_S1;
struct func_80237E70_S1;
struct func_80237E70_S1 {
    char pad0[0xF24];
    func_80237E70_S1_UF24 unkF24;
};
struct Model_func_80223E34_de;
typedef struct Model_func_80223E34_de Model_func_80223E34_de;
struct Course;
typedef struct Course Course;
struct ObjectLinks3C;
struct ObjectLinks3C {
    char pad0[0x18];
    char * unk_18;
    char pad18[0x38 - 0x18 - sizeof(char*)];
    s32 unk_38;
};
struct func_80219490_S2;
struct func_80219490_S2 {
    char pad0[0x29C];
    f32 unk29C;
    char pad29C[0x2A0 - 0x29C - sizeof(f32)];
    f32 unk2A0;
    char pad2A0[0x2A4 - 0x2A0 - sizeof(f32)];
    f32 unk2A4;
    char pad2A4[0x2A8 - 0x2A4 - sizeof(f32)];
    f32 unk2A8;
};
struct func_80204620_S2;
struct func_80204620_S2 {
    char pad0[0x28];
    s16 unk28;
};
struct func_80207ABC_S1;
struct func_80207ABC_S1 {
    char pad0[0x18];
    void * unk18;
    char pad18[0x38 - 0x18 - sizeof(void*)];
    s32 unk38;
};
struct func_8028FFB0_S3;
struct func_8028FFB0_S3 {
    char pad0[0x1D8];
    char * unk1D8;
};
struct func_80203E78_S1;
struct func_80203E78_S1 {
    char pad0[0x4];
    s32 unk4;
};
struct func_8022C070_S1;
struct func_8022C070_S1 {
    char pad0[0x2C];
    f32 unk2C;
};
struct func_80216BF4_S1;
typedef struct func_80216BF4_S1 func_80216BF4_S1;
struct func_8020A028_S4;
struct func_8020A028_S4 {
    char pad0[0x8];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    s32 unkC;
    char padC[0x10 - 0xC - sizeof(s32)];
    s32 unk10;
};
struct func_80228774_S1;
struct func_80228774_S1 {
    char pad0[0x20];
    void * unk20;
};
struct func_802285C4_S1;
typedef struct func_802285C4_S1 func_802285C4_S1;
struct func_8022C884_S1;
struct func_8022C884_S1 {
    char pad0[0x1C];
    int unk1C;
    char pad1C[0x20 - 0x1C - sizeof(int)];
    int unk20;
    char pad20[0x24 - 0x20 - sizeof(int)];
    int unk24;
};
extern int D_801371DC;
extern int D_800C91E0_de[];
struct func_8022A404_S1;
typedef struct func_8022A404_S1 func_8022A404_S1;
struct Record_func_80208158_de;
typedef struct Record_func_80208158_de Record_func_80208158_de;
struct func_80237E70_S1;
typedef struct func_80237E70_S1 func_80237E70_S1;
struct func_80209B64_S2;
typedef struct func_80209B64_S2 func_80209B64_S2;
struct func_8022ADA0_S1;
typedef struct func_8022ADA0_S1 func_8022ADA0_S1;
struct SharedPlayer_func_80209CD8_de;
typedef struct SharedPlayer_func_80209CD8_de SharedPlayer_func_80209CD8_de;
struct func_80205314_S1;
typedef struct func_80205314_S1 func_80205314_S1;
struct CollisionInfo8020CD74;
struct CollisionInfo8020CD74 {
    s32 w[7];
};
struct func_80229A54_S2;
typedef struct func_80229A54_S2 func_80229A54_S2;
struct func_80203E78_S1;
typedef struct func_80203E78_S1 func_80203E78_S1;
struct func_8021CD70_S4;
typedef struct func_8021CD70_S4 func_8021CD70_S4;
struct func_80228774_S1;
typedef struct func_80228774_S1 func_80228774_S1;
struct Frame;
struct Frame {
    char pad0[0x110];
    void *colorImage;
};
typedef union Gfx {
    struct { u32 w0; u32 w1; } words;
    u64 force_structure_alignment;
} Gfx;
struct Actor_func_80281A9C_de;
typedef struct Actor_func_80281A9C_de Actor_func_80281A9C_de;
struct Shared_ParticleInstance;
struct Shared_ParticleInstance {
    char pad0[0x4];
    u16 type;
    char pad6[0x2];
    Vec3 pos;
    s32 unk14;
    char pad18[0x4];
    Vec3 velocity;
    char pad28[0x10];
    s32 unk38;
    char pad3C[0x14];
};
struct func_8027EB00_S2;
struct func_8027EB00_S2 {
    char pad0[0x8];
    char unk8;
    char pad8[0x110 - 0x8 - sizeof(char)];
    s32 unk110;
    s32 unk114;
    void *unk118;
};
struct Actor_func_8027B428_de;
typedef struct Actor_func_8027B428_de Actor_func_8027B428_de;
struct Actor_func_8027B428_de;
struct Shape_func_8021A2D4_de_2;
struct Actor_func_8027B428_de {
    char pad0[4];
    u16 type;
    char pad6[0x12];
    struct Shape_func_8021A2D4_de_2 *descriptor;
    char pad1C[0x110];
    func_8024E8F0_S1 *owner;
};
struct Parent;
typedef struct Parent Parent;
extern void func_8027FF58_de(void *arg0);
struct Entry_func_80282C8C_de;
struct Entry_func_80282C8C_de {
    s16 kind;
    char pad[2];
    s16 id;
};
struct Shared_CollisionResult;
typedef struct Shared_CollisionResult Shared_CollisionResult;
union func_80282E6C_S1_U8;
union func_80282E6C_S1_U8 {
    Triple v0;
    Vec3 v1;
};
union func_8027C5A0_S1_U118;
union func_8027C5A0_S1_U118 {
    void * v0;
    s32 * v1;
};
union func_8027C5A0_S1_U118;
typedef union func_8027C5A0_S1_U118 func_8027C5A0_S1_U118;
struct func_8027C5A0_S1;
struct func_8027C5A0_S1 {
    char pad0[0x1C];
    Triple unk1C;
    char pad1C[0x5C - 0x1C - sizeof(Triple)];
    s32 unk5C;
    char pad5C[0x118 - 0x5C - sizeof(s32)];
    func_8027C5A0_S1_U118 unk118;
    char pad118[0x12C - 0x118 - sizeof(func_8027C5A0_S1_U118)];
    void * unk12C;
    char pad12C[0x130 - 0x12C - sizeof(void*)];
    s32 unk130;
    char pad130[0x134 - 0x130 - sizeof(s32)];
    s32 unk134;
};
struct func_8027D950_S1;
typedef struct func_8027D950_S1 func_8027D950_S1;
struct Shared_ParticleInstance;
typedef struct Shared_ParticleInstance Shared_ParticleInstance;
struct Shared_ParticleOwner;
typedef struct Shared_ParticleOwner Shared_ParticleOwner;
struct Entry_func_80282C8C_de;
typedef struct Entry_func_80282C8C_de Entry_func_80282C8C_de;
struct Record_func_80282C8C_de;
struct Record_func_80282C8C_de {
    char pad[0x20];
    Entry_func_80282C8C_de *first[3];
    Entry_func_80282C8C_de *second[3];
};
struct Node_func_8027FF58_de;
typedef struct Node_func_8027FF58_de Node_func_8027FF58_de;
struct func_8027EB00_S2;
typedef struct func_8027EB00_S2 func_8027EB00_S2;
extern int D_801002C4;
struct Actor_func_8027DAD0_de;
typedef struct Actor_func_8027DAD0_de Actor_func_8027DAD0_de;
struct Actor_func_8027E784_de;
typedef struct Actor_func_8027E784_de Actor_func_8027E784_de;
struct Instance_func_8027E784_de;
typedef struct Instance_func_8027E784_de Instance_func_8027E784_de;
struct Instance_func_8027E784_de;
struct Instance_func_8027E784_de {
    char pad0[8];
    Vec3 position;
    char pad14[8];
    Vec3 velocity;
    char pad28[0x28];
};
struct ActorDef;
struct ActorDef {
    s32 flags;
    char pad4[0x10];
    s32 large;
    char pad18[0xC];
    func_80232C78_S4 *size;
};
struct ActorDef;
struct Actor_func_8027E784_de;
struct Actor_func_8027E784_de {
    Instance_func_8027E784_de instance;
    char pad50[0xC8];
    struct ActorDef *def;
    char pad11C[0x24];
    f32 damage;
    char pad144[8];
    s16 health;
    char pad14E[0xA];
    f32 radius;
};
extern void func_8027E784_de(Actor_func_8027E784_de *actor);
struct Shared_ParticleTarget;
struct Shared_ParticleTarget {
    char pad0[0x100];
    s32 flags;
    char pad104[0x6C];
    s32 unk170;
    s32 unk174;
    char pad178[0x2C];
    s8 unk1A4;
};
struct func_80282E6C_Table;
struct func_80282E6C_Table {
    char pad[0xA8];
    u16 unkA8;
};
extern float D_800C4E60_de;
struct Object_func_80281A9C_de;
typedef struct Object_func_80281A9C_de Object_func_80281A9C_de;
struct Object_func_80281A9C_de;
struct Object_func_80281A9C_de {
    char pad0[8];
    Vec3 position;
    char pad14[0x160];
    s32 count;
};
struct World_func_80281A9C_de;
struct World_func_80281A9C_de {
    char pad0[0xE54];
    Object_func_80281A9C_de *objects[64];
    s32 objectCount;
};
struct Shared_Particle;
typedef struct Shared_Particle Shared_Particle;
struct func_8027C324_S1;
typedef struct func_8027C324_S1 func_8027C324_S1;
union func_8027C324_S1_U118;
union func_8027C324_S1_U118 {
    s32 * v0;
    void * v1;
};
struct func_80282E6C_S1;
typedef struct func_80282E6C_S1 func_80282E6C_S1;
struct Ground;
struct Ground {
    s32 found;
    char pad4[8];
    f32 height;
    char pad10[0xE0];
    Vec3 normal;
};
extern int D_8010029C;
struct func_80282E6C_Table;
typedef struct func_80282E6C_Table func_80282E6C_Table;
struct func_8027D950_S1;
struct func_8027D950_S1 {
    char pad0[0x8];
    s32 unk8;
    char pad8[0xC - 0x8 - sizeof(s32)];
    f32 unkC;
    char padC[0x10 - 0xC - sizeof(f32)];
    s32 unk10;
    char pad10[0x1D0 - 0x10 - sizeof(s32)];
    func_80209DAC_S2_U93 unk1D0;
};
struct Parent;
struct Parent {
    char pad0[8];
    Vec3 position;
    char pad14[0x60];
    f32 transform[16];
    void *skeleton;
    char padB8[0x48];
    s32 flags;
    char pad104[0xD4];
    func_80228774_S5 *model;
};
struct Actor_func_8027DAD0_de;
struct Parent;
struct Actor_func_8027DAD0_de {
    char pad0[4];
    u16 type;
    char pad6[2];
    Vec3 position;
    s32 unk14;
    char pad18[4];
    Vec3 heading;
    char pad28[0x28];
    Vec3 offset;
    s32 flags;
    char pad60[0xCC];
    struct Parent *owner;
    char pad130[4];
    struct Parent *parent;
    char pad138[0x3C];
    Vec3 facing;
    char pad180[0x51];
    s8 bone;
};
struct func_8027DAA4_S1;
struct func_8027DAA4_S1 {
    char pad0[0x160];
    char unk160;
};
struct Shared_CollisionResult;
struct Shared_CollisionResult {
    u8 *unk0;
    char pad4[0x4];
    char unk8[0x80];
    s32 unk88;
    char pad8C[0x4];
    char unk90[0xC];
    s32 unk9C;
    char unkA0[0x10];
    s32 unkB0;
    s32 unkB4;
    char unkB8[0xC];
    s32 unkC4;
    char unkC8[0x10];
    Vec3 unkD8;
};
struct func_80282E6C_S3;
struct func_80282E6C_S3 {
    char pad0[0x140];
    char unk140;
};
union func_80282E6C_S1_U8;
typedef union func_80282E6C_S1_U8 func_80282E6C_S1_U8;
struct func_80282E6C_S1;
struct func_80282E6C_S1 {
    char pad0[0x4];
    u16 unk4;
    char pad4[0x8 - 0x4 - sizeof(u16)];
    func_80282E6C_S1_U8 unk8;
    char pad8[0x118 - 0x8 - sizeof(func_80282E6C_S1_U8)];
    void * unk118;
    char pad118[0x12C - 0x118 - sizeof(void*)];
    void * unk12C;
    char pad12C[0x1D0 - 0x12C - sizeof(void*)];
    s8 unk1D0;
};
struct func_80282E6C_S5;
struct func_80282E6C_S5 {
    char pad0[0x70];
    u16 unk70;
    char pad70[0x8C - 0x70 - sizeof(u16)];
    u16 unk8C;
};
union func_8027C324_S1_U118;
typedef union func_8027C324_S1_U118 func_8027C324_S1_U118;
struct Shared_ParticleOwner;
struct Shared_ParticleOwner {
    u8 kind;
    char pad1[0xFF];
    s32 flags;
    char pad104[0xD4];
    Player_func_802676EC_de *state;
};
struct Shared_ParticleColors;
struct Shared_ParticleColors {
    char pad0[0x6];
    u8 prim[3];
    u8 env[3];
};
struct Shared_ParticleFade;
struct Shared_ParticleFade {
    char pad0[0x5];
    s8 rangeMode;
    char pad6[0x3];
    s8 fadeIn;
    s8 fadeOut;
    char padB[0x3];
    s8 unkE;
};
struct Shared_ParticleColors;
struct Shared_ParticleDesc;
struct Shared_ParticleFade;
struct ParticleRandomScalePair {
    u16 value;
    u16 range;
};
struct ParticleScaleRange {
    struct ParticleRandomScalePair xScale;
    struct ParticleRandomScalePair xScaleIncrement;
    struct ParticleRandomScalePair yScale;
    struct ParticleRandomScalePair yScaleIncrement;
    struct ParticleRandomScalePair zScale;
    struct ParticleRandomScalePair zScaleIncrement;
    f32 shadowScale;
    f32 start;
    f32 end;
};
struct ParticleAttachmentParameters {
    struct ParticleRandomScalePair xAmplitude;
    struct ParticleRandomScalePair xFrequency;
    struct ParticleRandomScalePair xPhase;
    struct ParticleRandomScalePair yAmplitude;
    struct ParticleRandomScalePair yFrequency;
    struct ParticleRandomScalePair yPhase;
    s8 duration;
    char reserved19;
};
struct Shared_ParticleDesc {
    s32 flags;
    char pad4[0x4];
    s8 animMode;
    char pad9[1];
    s8 heightMode;
    char padB[5];
    s16 unk10;
    char pad12[2];
    s32 renderKind;
    char pad18[0xC];
    struct ParticleScaleRange *scaleRange;
    char pad28[4];
    struct ParticleAttachmentParameters *attachment;
    char pad30[4];
    struct Shared_ParticleColors *colors;
    struct Shared_ParticleFade *fade;
};
struct Shared_Particle;
struct Shared_ParticleDesc;
struct Shared_ParticleOwner;
struct Shared_ParticleTarget;
struct Shared_Particle {
    Shared_ParticleInstance inst;
    char pad50[0xC];
    s32 flags;
    Matrix mtx[2];
    u8 drawState[2][0x18];
    char pad110[8];
    struct Shared_ParticleDesc *desc;
    s32 model;
    char pad120[0xC];
    struct Shared_ParticleOwner *owner;
    char pad130[0x4];
    struct Shared_ParticleTarget *target;
    char pad138[0x8];
    f32 time;
    f32 frame;
    f32 unk148;
    s16 life;
    s8 unk14E;
    s8 unk14F;
    Vec3 size;
    Vec3 growth;
    Vec3 prevPos;
    Vec3 unk174;
    Vec3 rot;
    Vec3 rotSpeed;
    f32 alpha;
    f32 unk19C;
    f32 unk1A0;
    char pad1A4[8];
    f32 unk1AC;
    f32 unk1B0;
    s32 unk1B4;
    char pad1B8[0x1];
    s8 unk1B9;
    char pad1BA[0x2];
    f32 unk1BC;
    char pad1C0[0x10];
    s8 unk1D0;
    s8 unk1D1;
    u8 prim[3];
    u8 env[3];
    u8 opacity;
};
struct func_8027C808_S1;
typedef struct func_8027C808_S1 func_8027C808_S1;
struct func_80282E6C_S3;
typedef struct func_80282E6C_S3 func_80282E6C_S3;
struct func_8027C808_S1;
struct func_8027C808_S1 {
    char pad0[0x1C];
    Triple unk1C;
    char pad1C[0x5C - 0x1C - sizeof(Triple)];
    s32 unk5C;
    char pad5C[0x118 - 0x5C - sizeof(s32)];
    func_8027C5A0_S1_U118 unk118;
    char pad118[0x12C - 0x118 - sizeof(func_8027C5A0_S1_U118)];
    void * unk12C;
    char pad12C[0x130 - 0x12C - sizeof(void*)];
    s32 unk130;
    char pad130[0x134 - 0x130 - sizeof(s32)];
    s32 unk134;
    char pad134[0x18C - 0x134 - sizeof(s32)];
    char unk18C;
    char pad18C[0x1BA - 0x18C - sizeof(char)];
    s8 unk1BA;
    char pad1BA[0x1C4 - 0x1BA - sizeof(s8)];
    s32 unk1C4;
};
struct func_8027D950_S2;
typedef struct func_8027D950_S2 func_8027D950_S2;
struct func_80282E6C_S5;
typedef struct func_80282E6C_S5 func_80282E6C_S5;
struct func_80282E6C_S2;
typedef struct func_80282E6C_S2 func_80282E6C_S2;
struct Node_func_8027FF58_de;
struct Node_func_8027FF58_de {
    char pad0[0x5C];
    s32 flags;
    char pad60[0xD0];
    s32 *counter;
    char pad134[4];
    s32 resource;
    char pad13C[0x9D];
    u8 marker;
    char pad1DA[0xA];
    void *handle;
    char pad1E8[4];
    struct Node_func_8027FF58_de *next;
};
struct Shared_ParticleTarget;
typedef struct Shared_ParticleTarget Shared_ParticleTarget;
struct func_8027D950_S2;
struct func_8027D950_S2 {
    char pad0[0xE54];
    char unkE54;
    char padE54[0xE94 - 0xE54 - sizeof(char)];
    char unkE94;
};
struct Record_func_80282C8C_de;
typedef struct Record_func_80282C8C_de Record_func_80282C8C_de;
struct func_8027C5A0_S1;
typedef struct func_8027C5A0_S1 func_8027C5A0_S1;
struct func_8027C324_S1;
struct func_8027C324_S1 {
    char pad0[0x1C];
    Triple unk1C;
    char pad1C[0x5C - 0x1C - sizeof(Triple)];
    s32 unk5C;
    char pad5C[0x118 - 0x5C - sizeof(s32)];
    func_8027C324_S1_U118 unk118;
    char pad118[0x12C - 0x118 - sizeof(func_8027C324_S1_U118)];
    void * unk12C;
    char pad12C[0x130 - 0x12C - sizeof(void*)];
    s32 unk130;
    char pad130[0x134 - 0x130 - sizeof(s32)];
    s32 unk134;
    char pad134[0x18C - 0x134 - sizeof(s32)];
    char unk18C;
    char pad18C[0x1B9 - 0x18C - sizeof(char)];
    s8 unk1B9;
    char pad1B9[0x1C4 - 0x1B9 - sizeof(s8)];
    s32 unk1C4;
};
struct func_80282E6C_S2;
struct func_80282E6C_S2 {
    char pad0[0x8];
    Vec3 unk8;
    char pad8[0x698 - 0x8 - sizeof(Vec3)];
    void * unk698;
    char pad698[0x11EC - 0x698 - sizeof(void*)];
    f32 unk11EC;
};
struct func_8027DAA4_S1;
typedef struct func_8027DAA4_S1 func_8027DAA4_S1;
struct Ground;
typedef struct Ground Ground;
struct Actor_func_80281A9C_de;
struct Actor_func_80281A9C_de {
    char pad0[4];
    u16 type;
    char pad6[2];
    Vec3 position;
    char pad14[0x118];
    SharedPlayer_func_8022A398_de *owner;
    char pad130[0x1C];
    s16 crowded;
};
struct World_func_80281A9C_de;
typedef struct World_func_80281A9C_de World_func_80281A9C_de;
extern void func_8027DD48_de(Shared_Particle *, void *, SharedPlayer_func_8022A398_de *, f32);
void func_8026F620_de(f32 *, f32 *, f32 *);
void func_8027027C_de(f32 *, void *);
void func_80271F34_de(Vec3 *, Vec3 *, Vec3 *);
void func_80271F9C_de(Vec3 *, Vec3 *, f32);
void func_80272018_de(Vec3 *, Vec3 *, Vec3 *);
void func_8027207C_de(Vec3 *);
s32 func_8027254C_de(Vec3 *, f32);
void func_802727D8_de(void *);
void func_80272828_de(f32 *);
void func_80272C60_de(void *, f32, f32, f32);
void func_80272E3C_de(f32 *, f32, f32, f32);
void func_80272FBC_de(float *, float *);
void func_802733B4_de(void *, f32, f32, f32);
void func_80273448_de(char *, float, float, float);
void func_8027347C_de(void *, f32, f32, f32);
void func_80273760_de(void *, f32);
void func_802738C0_de(void *, f32);
void func_80273A98_de(void *, f32);
void func_80273D6C_de(void *);
f32 func_8027525C_de(void *, f32, f32);
f32 func_80275DD4_de(void *, f32, f32);
void * func_8027D97C_de(void *, void *);
void func_8027DAD0_de(void *, void *, void *);
void func_8028C6D4_de(void *, s32, void *);
float func_802B7130_de(float);
extern s32 D_8011BDC8;
extern s32 D_800CD72C;
extern f32 D_800C9D74;
extern f32 D_800C9D7C;
extern f32 D_800C9D84;
extern f32 D_800C9D88;
extern f32 D_800C9D8C;
extern f32 D_800C4CD4_de;
extern f32 D_800C9DC8;
extern f32 D_800C4CDC_de;
extern f32 D_800C4CE0_de;
extern f32 D_800C4CE4_de;
extern f32 D_800C9DDC;
extern f32 D_800C9DF4;
extern f32 D_800C9DFC;
static inline void clamp_upper_height_at(Vec3 *position, f32 step) {
    f32 selected;
    if (func_80275DD4_de(0, position->x, position->z) + step < position->y) {
        selected = position->y;
    } else {
        selected = func_80275DD4_de(0, position->x, position->z) + step;
    }
    position->y = selected;
}
void func_8027DD48_de(Shared_Particle *arg0, void *arg1, SharedPlayer_func_8022A398_de *arg2, f32 arg3) {
    Matrix m10, m50, m90, mD0, m110;
    Vec3 v150;
    Vec3 v160;
    Vec3 v170;
    Vec3 v180;
    Vec3 v190;
    Vec3 v1A0;
    Vec3 v1B0;
    Vec3 v1C0;
    Vec3 v1D0;
    Vec3 v1E0;
    f32 *temp_v0_3;
    f32 *var_a0;
    f32 temp_f0;
    f32 elapsed;
    f32 blend_start;
    f32 case3_step;
    f32 case6_step;
    f32 temp_f0_2;
    f32 temp_f1;
    f32 temp_f20;
    f32 temp_f20_3;
    f32 temp_f20_4;
    f32 temp_f21;
    f32 temp_f2;
    f32 temp_f2_2;
    f32 var_f0;
    f32 var_f1;
    f32 var_f0_2;
    f32 var_f0_3;
    f32 var_f21;
    f32 var_f22;
    f32 var_f23;
    f32 var_f4;
    s32 temp_v0_2;
    s8 temp_a0;
    s8 temp_v0;
    s32 temp_v1;
    u16 temp_v1_2;
    struct Shared_ParticleDesc *temp_s5;
    struct Shared_ParticleDesc *interpolation;
    temp_s5 = arg0->desc;
    if (arg2 != 0) {
        interpolation = temp_s5;
        if (temp_s5->flags & 4) {
            var_f4 = arg3;
            temp_f1 = var_f4 - D_800C4C68_de;
            blend_start = 0.0f;
            var_f0 = 0.0f;
            if (!(temp_f1 < var_f0)) {
                var_f0 = temp_f1 * D_800C4C6C_de;
                temp_f2_2 = D_800C4C70_de;
                if (var_f0 > temp_f2_2) {
                    var_f0 = temp_f2_2;
                } else {
                    if (temp_f1 < blend_start) {
                        var_f0 = 0.0f;
                    } else {
                        var_f0 = temp_f1 * D_800C4C74_de;
                    }
                }
            }
            temp_f2_2 = interpolation->scaleRange->end;
            blend_start = interpolation->scaleRange->start;
            temp_f2_2 -= blend_start;
            temp_f2_2 *= var_f0;
            blend_start += temp_f2_2;
            var_f4 *= blend_start;
            var_f4 *= D_800C4C78_de;
        } else {
            var_f4 = D_800C4C7C_de;
        }
        temp_f2 = arg2->views1C.view6C_9.yaw;
        var_f23 = var_f4 * D_800C4C88_de * (temp_f2 + ((D_800C4C80_de - temp_f2) * D_800C9D74));
    } else {
        var_f23 = D_800C9D7C;
    }
    if (temp_s5->flags & 8) {
        var_f22 = arg0->size.y * arg0->size.z * var_f23;
    } else {
        var_f22 = 0.0f;
    }
    func_8027DAD0_de(arg0, &v150, &v170);
    if (!(arg0->flags & 0x30000)) {
        elapsed = arg0->time;
        if (elapsed > 0.0f) {
            temp_v0 = temp_s5->attachment->duration;
            var_f21 = D_800C4C90_de;
            if (temp_v0 != 0) {
                temp_f0 = (f32) temp_v0;
                if (elapsed < temp_f0) {
                    var_f21 = elapsed / temp_f0;
                }
            }
            v1D0 = arg0->unk174;
            if (arg0->unk1AC < 0.0f) {
                v160.x = 0;
                v160.z = 0;
                v160.y = D_800C9D84;
                func_80272018_de(&v1C0, &v160, &v1D0);
                func_80271F9C_de(&v1E0, &v1C0, func_802B7130_de(arg0->unk19C) * -arg0->unk1AC * var_f21);
                func_80271F34_de(&v150, &v150, &v1E0);
            }
            if (arg0->unk1B0 < 0.0f) {
                v160.x = 0;
                v160.z = 0;
                v160.y = D_800C9D88;
                func_80272018_de(&v1B0, &v160, &v1D0);
                func_80272018_de(&v1C0, &v1B0, &v1D0);
                func_80271F9C_de(&v1E0, &v1C0, func_802B7130_de(arg0->unk1A0) * -arg0->unk1B0 * var_f21);
                func_80271F34_de(&v150, &v150, &v1E0);
            }
        }
    }
    if (arg0->desc->renderKind != 0) {
        if (arg0->unk1D0 == -7) {
            func_80272E3C_de(m10.m, arg0->rot.x + D_800C9D8C, arg0->rot.y, arg0->rot.z);
            if ((v170.x == 0.0f) && (v170.y == 0.0f) && (v170.z == 0.0f)) {
                v1A0 = arg0->unk174;
            } else {
                v1A0 = v170;
            }
            func_8027207C_de(&v1A0);
            v160.x = 0;
            v160.z = 0;
            v160.y = D_800C4CA0_de;
            func_80272018_de(&v180, &v160, &v1A0);
            func_80272018_de(&v190, &v180, &v1A0);
            func_802727D8_de(m50.m);
            func_8027207C_de(&v180);
            func_8027207C_de(&v190);
            func_8027207C_de(&v1A0);
            m50.m[0] = v180.x;
            m50.m[1] = v180.y;
            m50.m[2] = v180.z;
            m50.m[4] = v190.x;
            m50.m[5] = v190.y;
            m50.m[6] = v190.z;
            m50.m[8] = v1A0.x;
            m50.m[9] = v1A0.y;
            m50.m[10] = v1A0.z;
            func_8026F620_de(m90.m, m10.m, m50.m);
        } else {
            func_80272E3C_de(m90.m, arg0->rot.x, arg0->rot.y + D_800C4CA4_de, arg0->rot.z);
        }
        func_8028C6D4_de(&D_8011BDC8, (s32) &arg0->inst.pos, &arg0->drawState[D_800CD72C]);
    } else if ((arg0->rot.x == 0.0f) && (arg0->rot.y == 0.0f)) {
        func_80273760_de(m90.m, arg0->rot.z);
    } else {
        func_80273760_de(m90.m, arg0->rot.z);
        temp_v0_2 = arg0->desc->renderKind;
        var_f0_2 = 0.0f;
        if (temp_v0_2 == 0) {
            var_f0_2 = arg0->rot.x;
        }
        var_f0_2 = -var_f0_2;
        var_f1 = 0.0f;
        if (temp_v0_2 == 0) {
            var_f1 = arg0->rot.y;
        }
        func_802733B4_de(m90.m, var_f0_2, -var_f1, 0.0f);
    }
    if (var_f22 != 0.0f) {
        func_802733B4_de(m90.m, 0.0f, var_f22, 0.0f);
        func_80273448_de((char *)m90.m, 0.0f, -var_f22, 0.0f);
    }
    temp_v1 = (s8) ((u8) arg0->unk1D0 + 8);
    arg0->flags = (s32) (arg0->flags & 0xFF7FFFFF);
    switch (temp_v1) {
        case 0: goto sw_0;
        case 2: case 4: case 7: goto sw_2;
        case 3: goto sw_3;
        case 5: goto sw_5;
        case 6: goto sw_6;
        case 8: case 9: case 10: goto sw_done;
        default: goto sw_done;
    }
    do {
    sw_0:
        v150.x += arg0->unk174.x * D_800C4CD4_de;
        v150.y += arg0->unk174.y * D_800C4CD4_de;
        v150.z += arg0->unk174.z * D_800C4CD4_de;
        goto sw_done;
    sw_3:
        if (temp_s5->heightMode != 0) {
            case3_step = D_800C9DC8;
            clamp_upper_height_at(&v150, case3_step);
        }
        goto sw_done;
    sw_5:
        temp_f2_2 = func_80275DD4_de(0, v150.x, v150.z);
        if (temp_s5->flags & 0x400) {
            if (v150.y < (temp_f2_2 + D_800C4CDC_de)) {
                v150.y = temp_f2_2;
                arg0->flags = (s32) (arg0->flags | 0x800000);
            }
        } else {
            temp_f0_2 = temp_f2_2 + D_800C4CE0_de;
            temp_f1 = v150.y;
            if (!(temp_f1 <= temp_f0_2)) {
                temp_f0_2 = temp_f1;
            }
            v150.y = temp_f0_2;
        }
        goto sw_done;
    sw_6:
        if (temp_s5->heightMode != 0) {
            case6_step = D_800C4CE4_de;
            v150.y = ({
                f32 selected_height;
                if (v150.y < (func_8027525C_de(0, v150.x, v150.z) - case6_step)) {
                    selected_height = v150.y;
                } else {
                    selected_height = func_8027525C_de(0, v150.x, v150.z) - case6_step;
                }
                selected_height;
            });
        }
        goto sw_done;
    sw_2:
    sw_4:
    sw_7:
        v150.y = v150.y + var_f22;
        goto sw_done;
    } while (0);
    goto sw_done;
sw_done:
    func_8027254C_de(&v150, 20000.0f);
    if ((temp_s5->flags & 0x80000) && (temp_s5->animMode == 1)) {
        var_f23 = var_f23 * D_800C4CE8_de * (f32) arg0->opacity;
    }
    if (arg0->desc->renderKind != 0) {
        temp_v1_2 = arg0->inst.type;
        temp_f20 = var_f23 * arg0->size.z * D_800C9DDC;
        if ((temp_v1_2 == 0x40B) || (temp_v1_2 == 0x40F) || (temp_v1_2 == 0x41E) || (temp_v1_2 == 0x40B) || (temp_v1_2 == 0x436)) {
            func_8027347C_de(m90.m, D_800C4CF0_de, D_800C4CF0_de, D_800C4CF0_de);
        }
        func_8027347C_de(m90.m, arg0->size.x * temp_f20, arg0->size.y * temp_f20, temp_f20 * D_800C4CF4_de);
        func_80273D6C_de(m90.m);
    } else {
        temp_f20 = var_f23 * arg0->size.z;
        func_8027347C_de(m90.m, arg0->size.x * temp_f20, arg0->size.y * temp_f20, temp_f20 * D_800C4CF8_de);
    }
    temp_v0_3 = func_8027D97C_de(arg0, arg2);
    if (temp_v0_3 != 0) {
        func_8026F620_de(mD0.m, m90.m, temp_v0_3);
    } else {
        func_80272FBC_de(mD0.m, m90.m);
    }
    func_80273448_de((char *)mD0.m, v150.x, v150.y, v150.z);
    if (arg0->flags & 0x20000) {
        temp_a0 = arg0->unk1D1;
        if (temp_a0 != 0) {
            temp_f20_3 = (f32) temp_a0 * D_800C4CFC_de;
            temp_f20_4 = temp_f20_3 * temp_f20_3;
            temp_f21 = temp_f20_4 * D_800C4D00_de;
            func_80272C60_de(m110.m, 0.0f, 0.0f, -66.56f);
            func_80273A98_de(m110.m, temp_f21 * (func_802B7130_de(temp_f20_4 * D_800C9DF4) * D_800C4D08_de));
            func_802738C0_de(m110.m, temp_f21 * func_802B7130_de(temp_f20_4 * D_800C9DFC));
            func_80273448_de((char *)m110.m, 0.0f, 0.0f, 66.56f);
            func_8026F620_de(m10.m, m110.m, mD0.m);
            func_80272828_de(m10.m);
            var_a0 = m10.m;
        } else {
            goto block_81;
        }
    } else {
block_81:
        func_80272828_de(mD0.m);
        var_a0 = mD0.m;
    }
    func_8027027C_de(var_a0, arg1);
}
